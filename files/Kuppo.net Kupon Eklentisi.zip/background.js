importScripts('./browser-polyfill.js');
importScripts('./api-compatibility.js');
importScripts('./crypto-js.min.js');
importScripts('./generate-rsig.js');

chrome.action.onClicked.addListener(function () {
  chrome.tabs.create({ url: 'fullscreen.html' });
});

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

let access_token_global = "";
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background: Mesaj alındı:', request.action);
  
  if (request.action === 'setCookies') {
    const tabId = sender.tab?.id;
    clearDataAndSetCookies(request.cookies, request.token, tabId, request.mgServiceType)
      .then(() => sendResponse({ success: true }))
      .catch((error) => sendResponse({ success: false, error: error.message }));
    return true;
  } else if (request.action === 'setYxCookies') {
    const tabId = sender.tab?.id;
    handleYxLogin(request.data, request.token, tabId)
      .then(() => {
        console.log('✅ handleYxLogin tamamlandı, response gönderiliyor');
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error('❌ handleYxLogin hatası:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  } else if (request.action === 'setTyCookies') {
    const tabId = sender.tab?.id;
    handleTrendyolLogin(request.data, request.token, tabId)
      .then(() => sendResponse({ success: true }))
      .catch((error) => sendResponse({ success: false, error: error.message }));
    return true;
  } else if (request.action === 'GET_ADDRESS_LIST_FROM_CONTENT') {
    // Content script'ten adres listesi talebi
    getAddressListFromStorage()
      .then(addresses => {
        sendResponse({ success: true, addresses: addresses });
      })
      .catch(error => {
        console.error('Adres listesi alınamadı:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  } else if (request.action === 'startExternalTokenProcess') {
    const tabId = sender.tab.id;

    // Token kontrolü
    if (!request.token) {
      chrome.tabs.sendMessage(tabId, {
        action: 'updateLog',
        message: 'Hata: Token bilgisi eksik!',
        type: 'error'
      });
      return true;
    }

    // Token tipine göre işlem yap
    handleExternalToken(request.token, tabId, request.mgServiceType, request.originalToken)
      .then(() => {
        chrome.tabs.sendMessage(tabId, {
          action: 'closeOverlay'
        });
      })
      .catch((error) => {
        chrome.tabs.sendMessage(tabId, {
          action: 'updateLog',
          message: 'Hata: ' + (error.message || 'Bilinmeyen bir hata oluştu'),
          type: 'error'
        });
      });
    return true;
  } else if (request.action === 'proxyRequest') {
    // Bu, CSP sınırlamalarını aşmak için proxy istek işleyicisidir
    handleProxyRequest(request, sendResponse);
    return true; // Asenkron yanıt için true dön
  } else if (request.action === 'GET_ADDRESS_LIST_FROM_CONTENT') { // YENİ EKLENDİ
    console.log('Background.js: Content.js\'den adres listesi isteği alındı.');
    // fullscreen.js'deki getAddressListFromStorage mantığını kullanarak adresleri al
    // Bu fonksiyon async olduğu için Promise kullanıyoruz
    (async () => {
      try {
        // getAddressListFromStorage fonksiyonu fullscreen.js içinde tanımlı,
        // background.js'den doğrudan çağıramayız.
        // Bu yüzden chrome.storage'dan direkt okuma yapacağız.
        const data = await new Promise(resolve => {
          chrome.storage.sync.get('addressList', result => {
            if (chrome.runtime.lastError) {
              console.warn("Background: Sync'ten adres listesi alınırken hata, local'e bakılıyor:", chrome.runtime.lastError.message);
              chrome.storage.local.get('addressList', localResult => {
                if (chrome.runtime.lastError) {
                  console.error("Background: Local'dan da adres listesi alınırken hata:", chrome.runtime.lastError.message);
                  resolve({ addressList: null });
                } else {
                  resolve(localResult);
                }
              });
            } else if (result && result.addressList) {
              resolve(result);
            } else {
              chrome.storage.local.get('addressList', localResult => {
                if (chrome.runtime.lastError) {
                  console.error("Background: Local'dan adres listesi alınırken hata (sync boştu):", chrome.runtime.lastError.message);
                  resolve({ addressList: null });
                } else {
                  resolve(localResult);
                }
              });
            }
          });
        });

        let addresses = [];
        if (data && data.addressList) {
          try {
            addresses = JSON.parse(data.addressList);
            if (!Array.isArray(addresses)) addresses = [];
          } catch (e) {
            console.error('Background.js: Adres listesi parse edilemedi.', e);
            addresses = [];
          }
        }
        console.log('Background.js: Gönderilecek adresler:', addresses);
        sendResponse({ success: true, addresses: addresses });
      } catch (error) {
        console.error('Background.js: Adres listesi alınırken hata:', error);
        sendResponse({ success: false, error: error.message, addresses: [] });
      }
    })();
    return true; // Asenkron yanıt için true dön
  } else if (request.action === 'ysProxyRequest') {
    handleYsProxyRequest(request, sendResponse);
    return true;
  } else if (request.action === 'mgProxyRequest') {
    handleMgProxyRequest(request, sendResponse);
    return true;
  } else if (request.action === 'tyProxyRequest') {
    handleTyProxyRequest(request, sendResponse);
    return true;
  } else if (request.action === 'tyCartItemsRequest') {
    handleTyCartItemsRequest(request, sendResponse);
    return true;
  } 
});

// Güncel tarihi dönen fonksiyon
function getCurrentDateInFormat() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${year}${month}${day}${hours}`;
}

// CSP sınırlamalarını aşmak için proxy istek işleyicisi
async function handleProxyRequest(request, sendResponse) {
  try {
    console.log('Background: Proxy istek alındı', request.url);

    // İstek parametrelerini kontrol et
    if (!request.url) {
      throw new Error('URL eksik');
    }

    // URL'yi düzelt
    let parsedUrl;
    try {
      parsedUrl = new URL(request.url);
    } catch (e) {
      // URL geçerli değilse https:// ekle
      parsedUrl = new URL('https://' + request.url);
    }

    // Orijinal path'i koru, sadece host'u değiştir
    const originalPath = parsedUrl.pathname;
    const originalSearch = parsedUrl.search;

    // Hangi servis için olduğunu belirle (path'den)
    let servicePath = '';
    if (originalPath.includes('/hemen/')) {
      servicePath = '/hemen';
    } else if (originalPath.includes('/yemek/')) {
      servicePath = '/yemek';
    } else {
      // Eğer hemen veya yemek değilse, sanalmarket olarak kabul et (default)
      servicePath = '';
    }

    // rest.migros.com.tr host'unu kullan
    parsedUrl.host = 'rest.migros.com.tr';

    // URL'yi servis tipiyle düzenle - path'i kontrol et ve gerekirse düzelt
    if (!originalPath.startsWith('/rest')) {
      // /rest eklemek gerekiyor
      const newPath = `/rest${servicePath}${originalPath.replace(/^\/*(hemen|yemek)?\/*/, '/')}`;
      parsedUrl.pathname = newPath;
    }

    const fullUrl = parsedUrl.toString();
    console.log('Background: Tam URL:', fullUrl);

    // Cookie rule'ı ayarla
    await setupCookieRule(fullUrl);

    // Fetch isteğini oluştur
    const fetchOptions = {
      method: request.method || 'GET',
      headers: request.headers || {},
      // Body varsa ekle
      ...(request.body ? { body: request.body } : {})
    };

    // İsteği göster
    console.log('Background: İstek gönderiliyor -', fetchOptions.method, fullUrl);
    console.log('Background: İstek başlıkları:', JSON.stringify(fetchOptions.headers));

    // Fetch ile istek gönder
    const response = await fetch(fullUrl, fetchOptions);

    // Yanıt başlıklarını işle
    const headers = {};
    response.headers.forEach((value, key) => {
      headers[key.toLowerCase()] = value;
    });

    // Başlıkları logla
    console.log('Background: Yanıt headers alındı:', Object.keys(headers).length, 'adet');

    // Yanıt içeriğini al
    const data = await response.text();

    console.log('Background: Yanıt alındı -', response.status, data.length + ' byte');

    // En az boş bir headers objesi gönderildiğinden emin ol
    const safeHeaders = headers || {};

    // Yanıtı döndür
    sendResponse({
      success: true,
      status: response.status,
      statusText: response.statusText,
      headers: safeHeaders,
      data: data
    });

    return true;
  } catch (error) {
    console.error('Background: Proxy istek hatası:', error);
    sendResponse({
      success: false,
      error: error.message || 'Bilinmeyen hata',
      // Boş hata durumunda da en azından boş bir headers objesi gönder
      headers: {}
    });
    return true;
  }
}

// Cookie rule ayarla
async function setupCookieRule(targetUrl) {
  try {
    // Tüm Migros cookie'lerini al
    const cookies = await new Promise(resolve => {
      chrome.cookies.getAll({ domain: 'migros.com.tr' }, resolve);
    });

    console.log(`${cookies.length} Migros cookie'si bulundu`);

    // Cookie string oluştur
    const cookieString = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    // Eski kuralı kaldır
    await RequestHeaderManager.updateSessionRules({
      removeRuleIds: [9876]
    }).catch(() => {/* İlk çalıştırmada hata olabilir, görmezden gel */ });

    // Yeni kural ekle
    await RequestHeaderManager.updateSessionRules({
      addRules: [{
        id: 9876,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Cookie", operation: "set", value: cookieString }
          ]
        },
        condition: {
          urlFilter: "rest.migros.com.tr",
          resourceTypes: ["xmlhttprequest"]
        }
      }]
    });

    console.log('Cookie rule başarıyla ayarlandı');
    return true;
  } catch (error) {
    console.error('Cookie rule ayarlanamadı:', error);
    return false;
  }
}

// YS sayfasına direkt yönlendirme fonksiyonu (artık temizleme işlemi clearSiteData ile yapılıyor)
function redirectToYsWithCleanStorage(url = "https://www.yemeksepeti.com", tabId = null, checkRefreshToken = false, refreshTokenData = null) {
  console.log('🔄 redirectToYsWithCleanStorage çağrıldı:', { url, tabId, checkRefreshToken });
  return new Promise((resolve, reject) => {
    const targetUrl = url || "https://www.yemeksepeti.com";

    // Belirli bir tabId varsa o tab üzerinde işlem yap
    if (tabId) {
      console.log('📍 Mevcut tab güncelleniyor:', tabId);
      chrome.tabs.update(tabId, { url: targetUrl }, (tab) => {
        console.log('✅ Tab güncellendi:', tab?.id);
        // Refresh token kontrolü yapılacaksa
        if (checkRefreshToken && refreshTokenData) {
          setupRefreshTokenCheck(tab.id, refreshTokenData.refreshToken, refreshTokenData.token);
        }
        resolve();
      });
    } else {
      // Yeni tab aç
      console.log('🆕 Yeni tab açılıyor:', targetUrl);
      chrome.tabs.create({ url: targetUrl }, (tab) => {
        console.log('✅ Yeni tab oluşturuldu:', tab?.id);
        // Refresh token kontrolü yapılacaksa
        if (checkRefreshToken && refreshTokenData) {
          setupRefreshTokenCheck(tab.id, refreshTokenData.refreshToken, refreshTokenData.token);
        }
        resolve();
      });
    }
  });
}

// Add a separate function to add the overlay first
function addCleanupOverlay(tabId, callback) {
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: () => {
      // Add fullscreen overlay message
      const overlay = document.createElement('div');
      overlay.id = 'ys-cleanup-overlay';
      overlay.style.position = 'fixed';
      overlay.style.top = '0';
      overlay.style.left = '0';
      overlay.style.width = '100%';
      overlay.style.height = '100%';
      overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
      overlay.style.zIndex = '999999';
      overlay.style.display = 'flex';
      overlay.style.flexDirection = 'column';
      overlay.style.justifyContent = 'center';
      overlay.style.alignItems = 'center';
      overlay.style.color = 'white';
      overlay.style.fontFamily = 'Arial, sans-serif';
      overlay.style.padding = '20px';
      overlay.style.boxSizing = 'border-box';
      overlay.style.textAlign = 'center';

      const messageEl = document.createElement('h2');
      messageEl.textContent = 'Gerekli işlemler yapılıyor...';
      messageEl.style.marginBottom = '20px';
      messageEl.style.fontSize = 'clamp(16px, 5vw, 24px)';
      messageEl.style.maxWidth = '100%';
      messageEl.style.wordWrap = 'break-word';

      const spinnerEl = document.createElement('div');
      spinnerEl.style.width = 'clamp(30px, 8vw, 40px)';
      spinnerEl.style.height = 'clamp(30px, 8vw, 40px)';
      spinnerEl.style.border = '4px solid rgba(255, 255, 255, 0.3)';
      spinnerEl.style.borderTop = '4px solid white';
      spinnerEl.style.borderRadius = '50%';
      spinnerEl.style.animation = 'ys-cleanup-spin 1s linear infinite';

      const style = document.createElement('style');
      style.textContent = `
        @keyframes ys-cleanup-spin { 
          0% { transform: rotate(0deg); } 
          100% { transform: rotate(360deg); } 
        }
        
        @media (max-width: 480px) {
          #ys-cleanup-overlay {
            padding: 15px;
          }
        }
      `;

      document.head.appendChild(style);
      overlay.appendChild(messageEl);
      overlay.appendChild(spinnerEl);
      document.body.appendChild(overlay);
    }
  }).then(() => {
    // Wait a brief moment to ensure overlay is visible
    setTimeout(() => {
      if (callback) callback();
    }, 300);
  }).catch(error => {
    console.error("Overlay script execution error:", error);
    // Try again when page is loaded
    chrome.tabs.onUpdated.addListener(function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        addCleanupOverlay(tabId, callback);
      }
    });
  });
}

// Refresh token kontrolü için ayrı bir fonksiyon
function setupRefreshTokenCheck(tabId, refreshToken, token) {
  chrome.tabs.onUpdated.addListener(function refreshTokenListener(id, info) {
    if (id === tabId && info.status === 'complete') {
      chrome.tabs.onUpdated.removeListener(refreshTokenListener);
      checkAndUpdateRefreshToken(refreshToken, token);
    }
  });
}

// Chrome browsingData API ile site verilerini temizle - Paralel optimizasyon + Timer
async function clearSiteData(domain) {
  const origin = `https://${domain}`;
  const totalStartTime = performance.now();

  try {
    // IndexedDB temizleme fonksiyonu (fallback ile)
    const clearIndexedDB = async () => {
      const startTime = performance.now();
      try {
        await BrowsingDataManager.remove({
          origins: [origin]
        }, {
          "indexedDB": true
        });
        const duration = performance.now() - startTime;
        console.log(`🗄️ IndexedDB temizlendi (${domain}): ${duration.toFixed(2)}ms`);
        return true;
      } catch (indexedDBError) {
        console.warn(`IndexedDB origin bazlı temizleme hatası:`, indexedDBError);
        // Fallback: Global IndexedDB temizleme
        try {
          await BrowsingDataManager.remove({}, {
            "indexedDB": true
          });
          const duration = performance.now() - startTime;
          console.log(`🗄️ IndexedDB global temizlendi (${domain}): ${duration.toFixed(2)}ms`);
          return true;
        } catch (globalIndexedDBError) {
          console.error(`IndexedDB global temizleme hatası:`, globalIndexedDBError);
          return false;
        }
      }
    };

    // Global temizleme fonksiyonu
    const clearGlobalData = async () => {
      const startTime = performance.now();
      try {
        await BrowsingDataManager.remove({}, {
          "serviceWorkers": true
        });
        const duration = performance.now() - startTime;
        console.log(`🔧 Global veriler temizlendi (${domain}): ${duration.toFixed(2)}ms`);
        return true;
      } catch (globalError) {
        console.warn(`Global veri temizleme hatası (normal):`, globalError);
        return false;
      }
    };

    // Origin bazlı temizleme wrapper'ı
    const clearOriginData = async () => {
      const startTime = performance.now();
      try {
        await BrowsingDataManager.remove({
          origins: [origin]
        }, {
          "cache": false,
          "cacheStorage": false,
          "cookies": true,
          "downloads": false,
          "history": false,
          "localStorage": true,
          "passwords": false
        });
        const duration = performance.now() - startTime;
        console.log(`🌐 Origin verileri temizlendi (${domain}): ${duration.toFixed(2)}ms`);
        return true;
      } catch (error) {
        console.error(`Origin temizleme hatası (${domain}):`, error);
        return false;
      }
    };

    // Tüm temizleme işlemlerini paralel olarak çalıştır
    const [originResult, indexedDBResult, globalResult] = await Promise.allSettled([
      clearOriginData(),
      clearIndexedDB(),
      clearGlobalData()
    ]);

    // Sonuçları kontrol et
    const originSuccess = originResult.status === 'fulfilled' && originResult.value;
    const indexedDBSuccess = indexedDBResult.status === 'fulfilled' && indexedDBResult.value;
    const globalSuccess = globalResult.status === 'fulfilled' && globalResult.value;

    const totalDuration = performance.now() - totalStartTime;
    console.log(`⏱️ TOPLAM ${domain} temizleme süresi: ${totalDuration.toFixed(2)}ms (Origin: ${originSuccess}, IndexedDB: ${indexedDBSuccess}, Global: ${globalSuccess})`);

    return originSuccess; // Ana işlemin başarılı olması yeterli
  } catch (error) {
    console.error(`Site verileri temizlenirken hata: ${domain}`, error);
    return false;
  }
}

function executeCleanupScript(tabId, callback) {
  // Önce chrome.browsingData API ile temizlemeyi dene
  clearSiteData("www.yemeksepeti.com").then(success => {
    if (success) {
      console.log("YS site verileri API ile temizlendi");
      // API ile temizleme başarılıysa sayfayı yenile
      chrome.tabs.reload(tabId, () => {
        if (callback) callback();
      });
    } else {
      // API ile temizleme başarısızsa, eski script injection yöntemini kullan
      console.log("API temizleme başarısız, script injection kullanılıyor");
      fallbackToScriptCleanup(tabId, callback);
    }
  }).catch(error => {
    console.error("browsingData API hatası, fallback kullanılıyor:", error);
    // API kullanılamıyorsa eski yöntemi kullan
    fallbackToScriptCleanup(tabId, callback);
  });
}

// Fallback: Script injection ile localStorage ve IndexedDB temizleme
function fallbackToScriptCleanup(tabId, callback) {
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: () => {
      // Yemeksepeti'nin tüm localStorage ve IndexedDB'sini temizle
      try {
        // 1. localStorage temizle
        const allKeys = [];
        for (let i = 0; i < localStorage.length; i++) {
          allKeys.push(localStorage.key(i));
        }
        allKeys.forEach(key => localStorage.removeItem(key));
        console.log("YS localStorage temizlendi! Temizlenen key sayısı:", allKeys.length);

        // 2. sessionStorage temizle
        sessionStorage.clear();
        console.log("YS sessionStorage temizlendi!");

        // 3. IndexedDB temizle
        if (window.indexedDB) {
          // Tüm IndexedDB veritabanlarını listeleme (modern tarayıcılarda)
          if (indexedDB.databases) {
            indexedDB.databases().then(databases => {
              databases.forEach(db => {
                if (db.name) {
                  const deleteReq = indexedDB.deleteDatabase(db.name);
                  deleteReq.onsuccess = () => console.log(`IndexedDB silindi: ${db.name}`);
                  deleteReq.onerror = () => console.error(`IndexedDB silme hatası: ${db.name}`);
                }
              });
            }).catch(e => console.error("IndexedDB listeleme hatası:", e));
          } else {
            // Fallback: Bilinen veritabanı isimlerini dene
            const commonDBNames = ['localforage', 'keyval-store', 'workbox-expiration', 'workbox-precache'];
            commonDBNames.forEach(dbName => {
              const deleteReq = indexedDB.deleteDatabase(dbName);
              deleteReq.onsuccess = () => console.log(`IndexedDB silindi: ${dbName}`);
            });
          }
        }

        // Sayfayı yenile
        setTimeout(() => { location.reload(); }, 1200);
      } catch (e) {
        console.error("Storage temizleme hatası:", e);
        setTimeout(() => { location.reload(); }, 1200);
      }
    }
  }).then(() => {
    if (callback) callback();
  }).catch(error => {
    console.error("Script çalıştırma hatası:", error);

    // Script çalıştırılamadıysa, sayfanın tamamen yüklenmesini bekleyin ve tekrar deneyin
    chrome.tabs.onUpdated.addListener(function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);

        chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: () => {
            try {
              // İkinci deneme - Basit temizlik
              localStorage.clear();
              sessionStorage.clear();
              console.log("YS storage (ikinci deneme) temizlendi!");

              // IndexedDB için ikinci deneme
              if (window.indexedDB && indexedDB.databases) {
                indexedDB.databases().then(databases => {
                  databases.forEach(db => {
                    if (db.name) indexedDB.deleteDatabase(db.name);
                  });
                });
              }

              setTimeout(() => { location.reload(); }, 1200);
            } catch (e) {
              console.error("İkinci storage temizleme hatası:", e);
              setTimeout(() => { location.reload(); }, 1200);
            }
          }
        }).then(() => {
          if (callback) callback();
        });
      }
    });
  });
}

async function handleExternalToken(token, tabId, mgServiceType = null, originalToken = null) {
  try {
    await sendLogMessage("Token doğrulanıyor...", "info", tabId);

    try {
      // Eski cihaz bilgilerini logla
      console.log("Eski cihaz bilgileri:", deviceInfo);

      // Token tipine göre cihaz bilgilerini güncelle
      if (token.startsWith('yx-')) {
        // YX token'ları için device bilgileri token response'ından alınacak
        console.log("YX token tespit edildi, device bilgileri token response'ından alınacak");
      } else {
        // Diğer token tipleri için varsayılan cihaz bilgilerini oluştur
        deviceInfo = generateDeviceIdentifiers();

        // Yeni cihaz bilgilerini logla
        console.log("Yeni cihaz bilgileri:", deviceInfo);

        // Local storage'a kaydet
        await chrome.storage.local.set({ 'deviceInfo': deviceInfo });

        // Mesaj gönder - önce konsola logla
        console.log("Cihaz bilgileri yenilendi mesajı gönderiliyor...");
        await sendLogMessage("Cihaz bilgileri yenilendi: " + deviceInfo.manufacturer + " " + deviceInfo.model, "info", tabId);
      }
    } catch (devError) {
      console.error("Cihaz bilgilerini yenilemede hata:", devError);
      await sendLogMessage("Cihaz bilgilerini yenilemede hata: " + devError.message, "warning", tabId);
    }

    // Token'ı geçmişe ekle (orijinal token varsa onu kaydet)
    const tokenForHistory = originalToken || token;
    const storageData = await chrome.storage.local.get('tokenHistory');
    const history = storageData.tokenHistory || [];
    const timestamp = new Date().toLocaleString();

    // Aynı token varsa listeden çıkar
    const filteredHistory = history.filter(item => item.token !== tokenForHistory);

    // Yeni tokeni başa ekle
    filteredHistory.unshift({ token: tokenForHistory, timestamp });

    // Maksimum 50 kayıt tut
    const limitedHistory = filteredHistory.slice(0, 50);

    await chrome.storage.local.set({ tokenHistory: limitedHistory });

    // Token tipini kontrol et
    if (token.startsWith('ys-')) {
      // Bayi sistemi token işlemi
      await sendLogMessage("İkincil giriş yöntemiyle giriş yapılıyor...", "info", tabId);
      const response = await fetch(`http://bayisistemi.online/site/NDMyNDIz/getCookie.php?token=${token.replace("ys-", '')}`);
      const data = await response.json();

      if (data.status) {
        await clearDataAndSetCookies(data.data, token, tabId);
        await sendLogMessage('Giriş başarılı.', 'success', tabId);
      } else {
        throw new Error('Geçersiz token veya giriş başarısız');
      }
    } else if (token.startsWith('ty-')) {
      // Trendyol token işlemi
      await sendLogMessage("Trendyol giriş yöntemi kullanılıyor...", "info", tabId);
      const response = await fetch(`https://admin.kuppo.net/getCookie.php?token=${token}&all=1`);
      const data = await response.json();

      if (data.status) {
        await handleTrendyolLogin(data.data, token, tabId);
        await sendLogMessage('Trendyol giriş başarılı.', 'success', tabId);
      } else {
        throw new Error('Geçersiz token veya giriş başarısız');
      }
    } else if (token.startsWith('uber-')) {
      // Uber token işlemi
      await sendLogMessage("Uber giriş yöntemi kullanılıyor...", "info", tabId);
      try {
        const response = await fetch(`https://admin.kuppo.net/getCookie.php?token=${token}&all=1`);
        const data = await response.json();

        // Uber yanıt yapısı kontrolü (data içinde cookie array)
        if (data.status && data.data && Array.isArray(data.data)) {
          await handleUberLogin(data.data, token, tabId);
          await sendLogMessage('Uber giriş başarılı.', 'success', tabId);
        } else {
          const errMsg = data.message || 'Geçersiz token veya veri bulunamadı';
          await showAlert(tabId, "Uber Giriş Hatası: " + errMsg);
          throw new Error(errMsg);
        }
      } catch (error) {
        await showAlert(tabId, "Uber Token Hatası: " + error.message);
        throw error;
      }
    } else if (token.startsWith('yx-')) {
      // YX token işlemi
      await sendLogMessage("Alternatif giriş yöntemi kullanılıyor...", "info", tabId);
      const response = await fetch(`https://admin.kuppo.net/getData.php?token=${token}`);
      const data = await response.json();

      if (data.status) {
        // Token response'ından device bilgilerini güncelle
        try {
          await updateDeviceInfoFromResponse(data, tabId);
        } catch (devError) {
          console.error("YX token: Cihaz bilgisi güncelleme hatası:", devError);
        }

        await handleYxLogin(data, token, tabId);
        await sendLogMessage('Alternatif giriş başarılı.', 'success', tabId);
      } else {
        throw new Error('Geçersiz token veya giriş başarısız');
      }
    } else {
      // Normal token işlemi
      await sendLogMessage("Standart giriş yapılıyor...", "info", tabId);
      const response = await fetch(`https://admin.kuppo.net/getCookie.php?all=1&token=${token}`);
      const data = await response.json();

      if (data.status) {
        // Normal token için de device bilgilerini güncelle (eğer response'da varsa)
        try {
          if (data.device_info || data.device_brand || data.device_model || data.device_id) {
            await updateDeviceInfoFromResponse(data, tabId);
          }
        } catch (devError) {
          console.error("Normal token: Cihaz bilgisi güncelleme hatası:", devError);
        }

        await clearDataAndSetCookies(data.data, token, tabId, mgServiceType);
        await sendLogMessage('Giriş başarılı.', 'success', tabId);
      } else {
        throw new Error('Geçersiz token');
      }
    }
  } catch (error) {
    console.error('Token işlemi sırasında hata:', error);
    await sendLogMessage('Hata: ' + error.message, 'error', tabId);
    
    // Uber tokenı ise alert ile göster
    if (token && typeof token === 'string' && token.startsWith('uber-')) {
      await showAlert(tabId, "Uber Doğrulama Hatası: " + error.message);
    }
    
    throw error;
  }
}

// Uber giriş işlemi
async function handleUberLogin(cookies, token, tabId) {
  const targetUrl = "https://www.uber.com/tr/tr/start-riding/";
  const updateNameUrl = "https://account.uber.com/update-display-name";

  try {
    await sendLogMessage("Uber oturumu hazırlanıyor...", "info", tabId);

    // 1. Diğer Uber sekmelerini kapat
    try {
      const allTabs = await chrome.tabs.query({});
      const otherUberTabs = allTabs.filter(tab =>
        tab.url && tab.url.toLowerCase().includes('uber') && tab.id !== tabId
      );
      await Promise.all(otherUberTabs.map(tab => chrome.tabs.remove(tab.id).catch(() => { })));
    } catch (e) {
      console.warn("Sekme temizleme hatası:", e);
    }

    // 2. Sekmeyi Uber'e yönlendir ve yüklenmesini bekle
    if (tabId) {
      await chrome.tabs.update(tabId, { url: targetUrl });
      await waitForPageLoad(tabId);
    } else {
      const newTab = await chrome.tabs.create({ url: targetUrl });
      tabId = newTab.id;
      await waitForPageLoad(tabId);
    }


    // 4. Mevcut Uber cookielerini temizle
    await sendLogMessage("Sistem temizleniyor...", "info", tabId);
    const allCookies = await chrome.cookies.getAll({});
    await Promise.all(allCookies.map(async (cookie) => {
      try {
        // Sadece uber.com içeren domainleri temizle
        if (cookie.domain.toLowerCase().includes('uber.com')) {
          const url = "http" + (cookie.secure ? "s" : "") + "://" +
            (cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain) +
            cookie.path;
          await chrome.cookies.remove({ url: url, name: cookie.name });
        }
      } catch (e) { }
    }));

    // 5. Yeni Uber cookielerini setle
    await sendLogMessage("Yeni oturum açılıyor...", "info", tabId);
    await setUberCookies(cookies);

    // 6. Son yönlendirme - Önce isim güncelleme sayfasına
    await sendLogMessage("Giriş başarılı, isim güncelleniyor...", "success", tabId);

    // İsim güncelleme sayfasını aç
    console.log('📍 Uber: Tab oluşturuluyor:', updateNameUrl);
    try {
      const newTab = await chrome.tabs.create({ url: updateNameUrl });
      console.log('✅ Uber: Tab oluşturuldu:', newTab?.id);
      // Tab oluşturulduktan sonra işlemleri yap
      const tab = newTab;
    } catch (error) {
      console.error("Uber tab oluşturma hatası:", error);
      await sendLogMessage("Uber tab oluşturma hatası: " + error.message, "error", tabId);
    }

  } catch (error) {
    console.error("Uber giriş hatası:", error);
    await sendLogMessage("Uber giriş hatası: " + error.message, "error", tabId);
    await showAlert(tabId, "Uber Giriş Hatası: " + error.message);
    throw error;
  }
}

// Sayfa yüklenmesini bekleme yardımcısı
function waitForPageLoad(tabId) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => resolve(), 10000);

    function listener(updatedTabId, info) {
      if (updatedTabId === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        clearTimeout(timeout);
        setTimeout(resolve, 500);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// Uber cookielerini set et (Snippet mantığıyla)
async function setUberCookies(cookies) {
  const nowInSeconds = Math.floor(Date.now() / 1000);

  for (const cookie of cookies) {
    try {
      const domain = cookie.domain || '.uber.com';
      const path = cookie.path || '/';
      const domainForUrl = domain.startsWith('.') ? domain.substring(1) : domain;

      // Uber domaini ise https zorunlu
      const isUber = domain.includes('uber');
      const protocol = isUber ? 'https' : (cookie.secure ? 'https' : 'http');
      const cookieUrl = `${protocol}://${domainForUrl}${path}`;

      const cookieData = {
        url: cookieUrl,
        name: cookie.name,
        value: cookie.value,
        domain: domain,
        path: path,
        secure: isUber ? true : (cookie.secure || false)
      };

      if (cookie.httpOnly !== undefined) {
        cookieData.httpOnly = cookie.httpOnly;
      }

      // SameSite map
      if (cookie.sameSite) {
        const sameSiteMap = {
          'None': 'no_restriction',
          'Lax': 'lax',
          'Strict': 'strict',
          'Unspecified': 'unspecified'
        };
        cookieData.sameSite = sameSiteMap[cookie.sameSite] || 'no_restriction';
      } else {
        cookieData.sameSite = 'no_restriction';
      }

      // Expiration logic
      if (cookie.expires && cookie.expires > 0 && cookie.expires !== -1) {
        if (cookie.expires < nowInSeconds) {
          // Süresi geçmişse 1 yıl ekle (Snippet mantığı)
          cookieData.expirationDate = nowInSeconds + (8760 * 60 * 60);
        } else {
          cookieData.expirationDate = cookie.expires;
        }
      } else if (cookie.expires === -1 || cookie.session === true) {
        // Session ise 1 saatlik ömür (Snippet mantığı)
        cookieData.expirationDate = nowInSeconds + (60 * 60);
      }

      await chrome.cookies.set(cookieData);
    } catch (e) {
      console.warn(`Cookie set error: ${cookie.name}`, e);
    }
  }
}

async function clearDataAndSetCookies(cookies, token, tabId, mgServiceType = null) {
  try {
    await sendLogMessage("Cookie temizleme işlemi başlatılıyor...", "info", tabId);

    // Hangi servis için işlem yapıldığını belirle
    let serviceType = 'ys'; // Varsayılan

    if (cookies.some(cookie => cookie.name === "remember-me")) {
      serviceType = 'mg'; // Migros işlemi

      // mgServiceType storage'a kaydet veya temizle
      if (mgServiceType) {
        await chrome.storage.local.set({ 'mgServiceType': mgServiceType });
        console.log('MG Servis Tipi kaydedildi:', mgServiceType);
      } else {
        // Normal token (12 haneli) ise eski mgServiceType'ı temizle
        await chrome.storage.local.remove('mgServiceType');
        console.log('MG Servis Tipi temizlendi (normal token)');
      }
    } else {
      // YS token ise mgServiceType'ı temizle
      await chrome.storage.local.remove('mgServiceType');
    }

    // Cihaz bilgilerini kontrol et - Migros için her zaman rastgele oluştur
    try {
      if (serviceType === 'mg') {
        // Migros için device bilgileri setMigros fonksiyonunda oluşturulacak
        console.log("clearDataAndSetCookies: Migros için device bilgileri setMigros'ta oluşturulacak");
      } else if (!deviceInfo || !deviceInfo.manufacturer) {
        // Diğer servisler için sadece eksikse oluştur
        console.log("clearDataAndSetCookies: Cihaz bilgileri eksik, yenileniyor");
        deviceInfo = generateDeviceIdentifiers();
        await chrome.storage.local.set({ 'deviceInfo': deviceInfo });
        console.log("Yeni cihaz bilgileri ayarlandı:", deviceInfo);
        await sendLogMessage("Yeni cihaz kimliği: " + deviceInfo.manufacturer + " " + deviceInfo.model, "info", tabId);
      } else {
        console.log("clearDataAndSetCookies: Mevcut cihaz bilgileri kullanılıyor:", deviceInfo);
      }
    } catch (devError) {
      console.error("Cihaz bilgisi kontrol hatası:", devError);
    }

    // Önce mevcut verileri temizle - SADECE ilgili servisin verilerini temizle
    if (serviceType === 'mg') {
      // Migros için browsingData API kullan
      try {
        await clearSiteData("migros.com.tr");
        console.log("Migros site verileri API ile temizlendi");
      } catch (error) {
        console.error("Migros browsingData API hatası, manuel temizleme yapılıyor:", error);
        // Fallback: Manuel cookie temizleme
        await new Promise((resolve) => {
          chrome.cookies.getAll({}, function (all_cookies) {
            let processed = 0;
            const total = all_cookies.length;

            if (total === 0) {
              resolve();
              return;
            }

            all_cookies.forEach((cookie) => {
              removeCookie(cookie, serviceType);
              processed++;
              if (processed === total) {
                resolve();
              }
            });
          });
        });
      }
    } else if (serviceType === 'ys') {
      // YemekSepeti için browsingData API kullan
      try {
        await Promise.all([
          clearSiteData("www.yemeksepeti.com"),
          clearSiteData("tr.fd-api.com")
        ]);
        console.log("YemekSepeti site verileri API ile temizlendi");
      } catch (error) {
        console.error("YemekSepeti browsingData API hatası, manuel temizleme yapılıyor:", error);
        // Fallback: Manuel cookie temizleme
        await new Promise((resolve) => {
          chrome.cookies.getAll({}, function (all_cookies) {
            let processed = 0;
            const total = all_cookies.length;

            if (total === 0) {
              resolve();
              return;
            }

            all_cookies.forEach((cookie) => {
              removeCookie(cookie, serviceType);
              processed++;
              if (processed === total) {
                resolve();
              }
            });
          });
        });
      }
    } else {
      // Diğer servisler için manuel cookie temizleme
      await new Promise((resolve) => {
        chrome.cookies.getAll({}, function (all_cookies) {
          let processed = 0;
          const total = all_cookies.length;

          if (total === 0) {
            resolve();
            return;
          }

          all_cookies.forEach((cookie) => {
            removeCookie(cookie, serviceType); // Servis tipini belirt
            processed++;
            if (processed === total) {
              resolve();
            }
          });
        });
      });
    }

    await sendLogMessage("Cookieler temizlendi.", "info", tabId);

    // Token boş değilse devam et
    if (!token) {
      throw new Error("Token bilgisi eksik!");
    }

    await setCookies(cookies || [], token, tabId);
    return true;
  } catch (error) {
    console.error("Cookie işlemi sırasında hata:", error);
    await sendLogMessage("Hata: " + error.message, "error", tabId);
    throw error;
  }
}

async function getTrFdApiCookies() {
  return new Promise((resolve) => {
    chrome.cookies.getAll({ domain: "www.yemeksepeti.com" }, (cookies) => {
      const cookieString = cookies.map(cookie => {
        if (cookie.name == "_pxhd" || cookie.name == "__cf_bm") {
          return `${cookie.name}=${cookie.value}`;
        }

      }).join('; ');
      resolve(cookieString);
    });
  });
}

async function updateCookieRule() {
  const cookieString = await getTrFdApiCookies();

  try {
    await RequestHeaderManager.updateDynamicRules({
      removeRuleIds: [6755], // Önceki kuralı kaldır
      addRules: [{
        "id": 6755,
        "priority": 1,
        "action": {
          "type": "modifyHeaders",
          "requestHeaders": [
            { "header": "Cookie", "operation": "set", "value": cookieString }
          ]
        },
        "condition": {
          "urlFilter": "|https://tr.fd-api.com/*",
          "resourceTypes": ["xmlhttprequest"]
        }
      }]
    });
    console.log("Cookie rule updated successfully");
  } catch (error) {
    console.error("Error updating cookie rule:", error);
    throw error;
  }
}




chrome.cookies.onChanged.addListener((changeInfo) => {
  if (changeInfo.cookie.domain.includes("www.yemeksepeti.com")) {
    updateCookieRule().catch(console.error);
  }
});

const removeCookie = function (cookie, serviceType = null) {
  try {
    // Eğer serviceType belirtilmişse, sadece o servise ait çerezleri temizle
    if (serviceType === 'ys') {
      // Sadece Yemeksepeti çerezlerini temizle
      if (cookie.domain.includes("yemeksepeti") || cookie.domain.includes("tr.fd-api")) {
        var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
        chrome.cookies.remove({ "url": url, "name": cookie.name });
      }
    } else if (serviceType === 'mg') {
      // Sadece Migros çerezlerini temizle
      if (cookie.domain.includes("migros")) {
        var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
        chrome.cookies.remove({ "url": url, "name": cookie.name });
      }
    } else if (serviceType === 'ty') {
      // Sadece Trendyol çerezlerini temizle
      if (cookie.domain.includes("trendyol") || cookie.domain.includes("tgoapis") || cookie.domain.includes("tgoyemek")) {
        var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
        chrome.cookies.remove({ "url": url, "name": cookie.name });
      }
    } else {
      // Geriye dönük uyumluluk için: serviceType belirtilmemişse eski davranışı koru
      if (cookie.domain.includes("yemeksepeti") || cookie.domain.includes("migros") || cookie.domain.includes("tr.fd-api") || cookie.domain.includes("trendyol") || cookie.domain.includes("tgoapis") || cookie.domain.includes("tgoyemek")) {
        var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
        chrome.cookies.remove({ "url": url, "name": cookie.name });
      }
    }
  } catch (error) {
    return;
  }
};

function randomByteC(byteCount) {
  const array = new Uint8Array(byteCount);
  window.crypto.getRandomValues(array);
  return btoa(String.fromCharCode.apply(null, array)).toLowerCase();
}


// Trendyol çerezlerini temizle
async function clearTrendyolCookies() {
  // Önce browsingData API ile temizlemeyi dene
  try {
    await Promise.all([
      clearSiteData("tgoyemek.com"),
      clearSiteData("trendyol.com"),
      clearSiteData("tgoapps.com")
    ]);
    console.log("Trendyol site verileri API ile temizlendi");
    return;
  } catch (error) {
    console.error("Trendyol browsingData API hatası, manuel temizleme yapılıyor:", error);
  }

  // Fallback: Manuel çerez temizleme
  return new Promise((resolve) => {
    chrome.cookies.getAll({}, function (all_cookies) {
      let processed = 0;
      const total = all_cookies.length;

      if (total === 0) {
        resolve();
        return;
      }

      all_cookies.forEach((cookie) => {
        removeCookie(cookie, 'ty'); // Sadece Trendyol çerezlerini temizle
        processed++;
        if (processed === total) {
          resolve();
        }
      });
    });
  });
}

// Yeni Trendyol giriş işlemi - CSRF token ile ve cache sistemi
async function performTrendyolLogin(data, tabId, token = null) {
  try {
    // Token varsa önce cache kontrol et
    if (token && token.startsWith('ty-')) {
      const cachedData = await getTrendyolCachedLogin(token);
      if (cachedData) {
        await sendLogMessage("Cache'den giriş bilgileri kullanılıyor...", "info", tabId);
        await setTrendyolCookiesFromCache(cachedData, data, tabId);
        return true;
      }
    }

    await sendLogMessage("Trendyol cookieleri temizleniyor...", "info", tabId);

    // 0. Önce tgoyemek.com'a ait tüm cookieleri temizle
    await new Promise((resolve) => {
      chrome.cookies.getAll({ domain: "tgoyemek.com" }, function (cookies) {
        let processed = 0;
        const total = cookies.length;

        if (total === 0) {
          resolve();
          return;
        }

        cookies.forEach((cookie) => {
          const url = "https://tgoyemek.com" + cookie.path;
          chrome.cookies.remove({
            url: url,
            name: cookie.name
          }, () => {
            processed++;
            if (processed === total) {
              resolve();
            }
          });
        });
      });
    });

    await sendLogMessage("CSRF token alınıyor...", "info", tabId);

    // 1. CSRF token al
    const csrfResponse = await fetch('https://tgoyemek.com/api/auth/csrf', {
      method: 'GET',
      headers: {
        'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
        'sec-ch-ua-mobile': '?0',
        'accept': '*/*',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'tr',
        'priority': 'u=1, i'
      }
    });

    if (!csrfResponse.ok) {
      throw new Error(`CSRF token alınamadı: ${csrfResponse.status}`);
    }

    const csrfData = await csrfResponse.json();
    const csrfToken = csrfData.csrfToken;

    if (!csrfToken) {
      throw new Error('CSRF token response\'ında bulunamadı');
    }

    console.log('CSRF token alındı:', csrfToken);

    // 2. CSRF token'i cookie olarak set et
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "tgo-csrf-token",
      value: csrfToken,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: true,
      sameSite: "lax",
      path: "/"
    });

    await sendLogMessage("CSRF token ayarlandı, giriş yapılıyor...", "info", tabId);

    // 3. Email ve şifreyi al (plain text olarak)
    const email = data.email;
    const password = data.password;

    // 3.5. iOS/Orion için webRequest listener ekle (set-cookie header'ını yakalamak için)
    let capturedTgoToken = null;
    const requestId = Date.now().toString();
    
    const responseListener = (details) => {
      if (details.url.includes('/api/auth/login')) {
        const setCookieHeaders = details.responseHeaders?.filter(h => 
          h.name.toLowerCase() === 'set-cookie'
        );
        
        if (setCookieHeaders) {
          for (const header of setCookieHeaders) {
            const match = header.value.match(/tgo-token=([^;]+)/);
            if (match) {
              capturedTgoToken = match[1];
              console.log('webRequest ile tgo-token yakalandı:', capturedTgoToken.substring(0, 20) + '...');
              break;
            }
          }
        }
      }
    };
    
    // webRequest API varsa listener ekle
    if (chrome.webRequest && chrome.webRequest.onResponseStarted) {
      chrome.webRequest.onResponseStarted.addListener(
        responseListener,
        { urls: ['https://tgoyemek.com/api/auth/login'] },
        ['responseHeaders']
      );
    }

    // 4. Login isteğini gönder
    const loginResponse = await fetch('https://tgoyemek.com/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=UTF-8',
        'sec-ch-ua-platform': '"Windows"',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
        'sec-ch-ua-mobile': '?0',
        'accept': '*/*',
        'origin': 'https://tgoyemek.com',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'referer': 'https://tgoyemek.com/giris?callbackUrl=%2F',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
        'priority': 'u=1, i',
        'Cookie': `tgo-csrf-token=${csrfToken}`
      },
      body: JSON.stringify({
        username: email,
        password: password,
        csrfToken: csrfToken
      })
    });

    if (!loginResponse.ok) {
      throw new Error(`Giriş başarısız: ${loginResponse.status}`);
    }

    const loginData = await loginResponse.json();

    // Listener'ı kaldır
    if (chrome.webRequest && chrome.webRequest.onResponseStarted) {
      try {
        chrome.webRequest.onResponseStarted.removeListener(responseListener);
      } catch (e) {
        console.log('Listener kaldırılamadı:', e);
      }
    }

    // 5. Response headers'ından set-cookie'leri al
    let tgoToken = null;

    // Önce webRequest ile yakalanan token'ı kontrol et (iOS/Orion için)
    if (capturedTgoToken) {
      tgoToken = capturedTgoToken;
      console.log('webRequest ile yakalanan tgo-token kullanılıyor:', tgoToken.substring(0, 20) + '...');
    }

    // Eğer webRequest'ten alamadıysak, fetch headers'dan almaya çalış
    if (!tgoToken) {
      const setCookieHeaders = loginResponse.headers.get('set-cookie');

      if (setCookieHeaders) {
        const tgoTokenMatch = setCookieHeaders.match(/tgo-token=([^;]+)/);
        if (tgoTokenMatch) {
          tgoToken = tgoTokenMatch[1];
          console.log('Fetch header\'dan tgo-token alındı:', tgoToken.substring(0, 20) + '...');
        }
      }
    }

    // Eğer header'dan alamadıysak, cookie'den almayı dene (iOS/Orion için gerekli)
    if (!tgoToken) {
      console.log('Header\'dan tgo-token alınamadı, cookie\'den deneniyor...');
      
      // iOS/Orion için retry mekanizması - cookie'nin set edilmesi zaman alabilir
      const maxRetries = 5;
      const retryDelay = 1000; // 1 saniye
      
      for (let i = 0; i < maxRetries; i++) {
        await sleep(retryDelay);
        
        const tgoTokenCookie = await new Promise(resolve => {
          chrome.cookies.get({ url: 'https://tgoyemek.com', name: 'tgo-token' }, cookie => {
            resolve(cookie);
          });
        });

        if (tgoTokenCookie && tgoTokenCookie.value) {
          tgoToken = tgoTokenCookie.value;
          console.log(`Cookie\'den tgo-token alındı (deneme ${i + 1}/${maxRetries}):`, tgoToken.substring(0, 20) + '...');
          break;
        }
        
        console.log(`tgo-token bulunamadı, tekrar deneniyor... (${i + 1}/${maxRetries})`);
      }
    }

    if (!tgoToken) {
      // Son bir deneme: Tüm cookieleri listele ve kontrol et
      console.log('Son deneme: Tüm tgoyemek.com cookieleri kontrol ediliyor...');
      const allCookies = await new Promise(resolve => {
        chrome.cookies.getAll({ domain: 'tgoyemek.com' }, cookies => {
          resolve(cookies);
        });
      });
      
      console.log('Bulunan cookieler:', allCookies.map(c => c.name).join(', '));
      
      throw new Error('tgo-token ne header\'da ne de cookie\'de bulunamadı. Hata oluştu, IP adresinizi yenileyip tekrar deneyin');
    }

    // 6. tgo-token cookie'sini manuel olarak set et (response'daki cookie zaten set edilmiş olmalı ama emin olmak için)
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "tgo-token",
      value: tgoToken,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: true,
      sameSite: "lax",
      path: "/"
    });

    // 7. Eski access_token cookie'sini de ayarla (backward compatibility)
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "access_token",
      value: tgoToken,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: false
    });

    // 7. Email ve telefon bilgilerini de sakla
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "user_email",
      value: email,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: false
    });

    if (data.phone_number) {
      await chrome.cookies.set({
        url: "https://tgoyemek.com",
        name: "user_phone",
        value: data.phone_number,
        domain: "tgoyemek.com",
        secure: true,
        httpOnly: false
      });
    }

    // 8. Trendyol API başlıklarını ayarla (payment API'leri dahil)
    await setupTrendyolHeaders(data.access_token);

    // 9. Başarılı giriş sonrası cache'e kaydet
    if (token && token.startsWith('ty-')) {
      await saveTrendyolLoginToCache(token, tgoToken, email, data.phone_number, data.access_token, csrfToken);
    }

    await sendLogMessage("Trendyol giriş başarıyla tamamlandı.", "success", tabId);
    return true;
  } catch (error) {
    await sendLogMessage("Trendyol giriş hatası: " + error.message, "error", tabId);
    throw error;
  }
}

// Trendyol cache fonksiyonları
async function getTrendyolCachedLogin(token) {
  try {
    const cacheKey = `trendyol_cache_${token}`;
    const storageData = await chrome.storage.local.get(cacheKey);

    if (storageData[cacheKey]) {
      const cachedData = storageData[cacheKey];
      const now = Date.now();
      const cacheAge = now - cachedData.timestamp;
      const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 gün

      if (cacheAge < maxAge) {
        console.log('Trendyol cache bulundu ve geçerli:', token);
        return cachedData;
      } else {
        console.log('Trendyol cache eskimiş, temizleniyor:', token);
        await chrome.storage.local.remove(cacheKey);
      }
    }

    return null;
  } catch (error) {
    console.error('Trendyol cache kontrol hatası:', error);
    return null;
  }
}

async function saveTrendyolLoginToCache(token, tgoToken, email, phoneNumber, accessToken, csrfToken) {
  try {
    const cacheKey = `trendyol_cache_${token}`;
    const cacheData = {
      tgoToken,
      email,
      phoneNumber,
      accessToken,
      csrfToken,
      timestamp: Date.now()
    };

    await chrome.storage.local.set({ [cacheKey]: cacheData });
    console.log('Trendyol giriş cache\'e kaydedildi:', token);
  } catch (error) {
    console.error('Trendyol cache kaydetme hatası:', error);
  }
}

async function setTrendyolCookiesFromCache(cachedData, data, tabId) {
  try {
    await sendLogMessage("Cache'den çerezler ayarlanıyor...", "info", tabId);

    // tgo-token cookie'sini set et
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "tgo-token",
      value: cachedData.tgoToken,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: true,
      sameSite: "lax",
      path: "/"
    });

    // tgo-token cookie'sini set et
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "tgo-csrf-token",
      value: cachedData.csrfToken,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: true,
      sameSite: "lax",
      path: "/"
    });

    // Eski access_token cookie'sini de ayarla (backward compatibility)
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "access_token",
      value: cachedData.tgoToken,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: false
    });

    // Email ve telefon bilgilerini de sakla
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "user_email",
      value: cachedData.email,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: false
    });

    if (cachedData.phoneNumber) {
      await chrome.cookies.set({
        url: "https://tgoyemek.com",
        name: "user_phone",
        value: cachedData.phoneNumber,
        domain: "tgoyemek.com",
        secure: true,
        httpOnly: false
      });
    }

    // Trendyol API başlıklarını ayarla
    await setupTrendyolHeaders(cachedData.accessToken);

    await sendLogMessage("Cache'den giriş başarıyla tamamlandı.", "success", tabId);
  } catch (error) {
    await sendLogMessage("Cache'den çerez ayarlama hatası: " + error.message, "error", tabId);
    throw error;
  }
}

// Trendyol çerezlerini ayarla (eski yöntem - backward compatibility)
async function setTrendyolCookies(data, tabId) {
  try {
    await sendLogMessage("Trendyol çerezleri ayarlanıyor...", "info", tabId);

    // Access token'ı çerez olarak ayarla
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "access_token",
      value: data.access_token,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: false
    });

    // Email ve telefon bilgilerini de sakla
    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "user_email",
      value: data.email,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: false
    });

    await chrome.cookies.set({
      url: "https://tgoyemek.com",
      name: "user_phone",
      value: data.phone_number,
      domain: "tgoyemek.com",
      secure: true,
      httpOnly: false
    });

    // Trendyol API başlıklarını ayarla (payment API'leri dahil)
    await setupTrendyolHeaders(data.access_token);

    await sendLogMessage("Trendyol çerezleri ayarlandı.", "success", tabId);
    return true;
  } catch (error) {
    await sendLogMessage("Trendyol çerez hatası: " + error.message, "error", tabId);
    throw error;
  }
}

// Trendyol API başlıklarını ayarla
async function setupTrendyolHeaders(accessToken) {
  try {
    await clearAllRules();
    // Cihaz bilgilerini al
    const device = getOrCreateDeviceInfo();
    
    // Trendyol API için rules oluştur (sadece kullandığımız endpoint'ler için)
    const apiRules = [
      // Addresses endpoint
      {
        id: 7003,
        priority: 100,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "sec-ch-ua", operation: "remove" },
            { header: "sec-ch-ua-mobile", operation: "remove" },
            { header: "sec-ch-ua-platform", operation: "remove" },
            { header: "Sec-Fetch-Dest", operation: "remove" },
            { header: "Sec-Fetch-Mode", operation: "remove" },
            { header: "Sec-Fetch-Site", operation: "remove" },
            { header: "Sec-Fetch-Storage-Access", operation: "remove" },
            { header: "Referer", operation: "remove" },
            { header: "Origin", operation: "remove" },
            { header: "Accept", operation: "set", value: "*/*" },
            { header: "User-Agent", operation: "set", value: "Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164" }
          ]
        },
        condition: {
          urlFilter: "api.tgoapis.com/localcommerce-member-zeususer-service/addresses",
          resourceTypes: ["xmlhttprequest"]
        }
      },
      // Shipping endpoint
      {
        id: 7004,
        priority: 100,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "sec-ch-ua", operation: "remove" },
            { header: "sec-ch-ua-mobile", operation: "remove" },
            { header: "sec-ch-ua-platform", operation: "remove" },
            { header: "Sec-Fetch-Dest", operation: "remove" },
            { header: "Sec-Fetch-Mode", operation: "remove" },
            { header: "Sec-Fetch-Site", operation: "remove" },
            { header: "Sec-Fetch-Storage-Access", operation: "remove" },
            { header: "Referer", operation: "remove" },
            { header: "Origin", operation: "remove" },
            { header: "Accept", operation: "set", value: "*/*" },
            { header: "User-Agent", operation: "set", value: "Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164" }
          ]
        },
        condition: {
          urlFilter: "api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/*",
          resourceTypes: ["xmlhttprequest"]
        }
      },
      // Cart endpoint
      {
        id: 7005,
        priority: 100,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "sec-ch-ua", operation: "remove" },
            { header: "sec-ch-ua-mobile", operation: "remove" },
            { header: "sec-ch-ua-platform", operation: "remove" },
            { header: "Sec-Fetch-Dest", operation: "remove" },
            { header: "Sec-Fetch-Mode", operation: "remove" },
            { header: "Sec-Fetch-Site", operation: "remove" },
            { header: "Sec-Fetch-Storage-Access", operation: "remove" },
            { header: "Referer", operation: "remove" },
            { header: "Origin", operation: "remove" },
            { header: "Accept", operation: "set", value: "*/*" },
            { header: "User-Agent", operation: "set", value: "Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164" }
          ]
        },
        condition: {
          urlFilter: "api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts",
          resourceTypes: ["xmlhttprequest"]
        }
      },
      // Coupon code endpoint (mobile)
      {
        id: 7006,
        priority: 100,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "sec-ch-ua", operation: "remove" },
            { header: "sec-ch-ua-mobile", operation: "remove" },
            { header: "sec-ch-ua-platform", operation: "remove" },
            { header: "Sec-Fetch-Dest", operation: "remove" },
            { header: "Sec-Fetch-Mode", operation: "remove" },
            { header: "Sec-Fetch-Site", operation: "remove" },
            { header: "Sec-Fetch-Storage-Access", operation: "remove" },
            { header: "Referer", operation: "remove" },
            { header: "Origin", operation: "remove" },
            { header: "Accept", operation: "set", value: "*/*" },
            { header: "User-Agent", operation: "set", value: "Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164" }
          ]
        },
        condition: {
          urlFilter: "api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/code-promotions",
          resourceTypes: ["xmlhttprequest"]
        }
      },
      // Coupon code endpoint (web)
      {
        id: 7007,
        priority: 100,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "sec-ch-ua", operation: "remove" },
            { header: "sec-ch-ua-mobile", operation: "remove" },
            { header: "sec-ch-ua-platform", operation: "remove" },
            { header: "Sec-Fetch-Dest", operation: "remove" },
            { header: "Sec-Fetch-Mode", operation: "remove" },
            { header: "Sec-Fetch-Site", operation: "remove" },
            { header: "Sec-Fetch-Storage-Access", operation: "remove" },
            { header: "Referer", operation: "remove" },
            { header: "Origin", operation: "remove" },
            { header: "Accept", operation: "set", value: "*/*" },
            { header: "User-Agent", operation: "set", value: "Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164" }
          ]
        },
        condition: {
          urlFilter: "api.tgoapis.com/web-checkout-apicheckout-santral/carts/code-promotions",
          resourceTypes: ["xmlhttprequest"]
        }
      },
    ];
    
    // Rules'ları ekle
    await RequestHeaderManager.updateSessionRules({
      addRules: apiRules
    });
    
    console.log('Trendyol API rules başarıyla eklendi');
    return true;
    
    // Payment header'larını oluştur
    const paymentHeaders = generateTrendyolPaymentHeaders();

    // Trendyol payment API kuralları
    const rules = [
      {
        id: 7001,
        priority: 100,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            // Önce web başlıklarını kaldır
            { header: "sec-ch-ua", operation: "remove" },
            { header: "sec-ch-ua-mobile", operation: "remove" },
            { header: "sec-ch-ua-platform", operation: "remove" },
            { header: "Sec-Fetch-Dest", operation: "remove" },
            { header: "Sec-Fetch-Mode", operation: "remove" },
            { header: "Sec-Fetch-Site", operation: "remove" },
            { header: "Referer", operation: "remove" },
            { header: "Origin", operation: "remove" },
            // Sonra mobil başlıkları ekle
            { header: "Authorization", operation: "set", value: `Bearer ${accessToken}` },
            { header: "Content-Type", operation: "set", value: "application/json" },
            { header: "Pid", operation: "set", value: paymentHeaders.pid },
            { header: "Traceparent", operation: "set", value: `00-${paymentHeaders.traceId}-${paymentHeaders.spanId}-01` },
            { header: "Tracestate", operation: "set", value: `@nr=0-2---${paymentHeaders.spanId}----${paymentHeaders.timestamp}` },
            {
              header: "Newrelic", operation: "set", value: JSON.stringify({
                "v": [0, 2],
                "d": {
                  "ty": "Mobile",
                  "ac": "",
                  "ap": "",
                  "tr": paymentHeaders.traceId,
                  "id": paymentHeaders.spanId,
                  "ti": paymentHeaders.timestamp,
                  "tk": ""
                }
              })
            },
            { header: "Deviceid", operation: "set", value: "00000000-0000-0000-0000-000000000000" },
            { header: "X-Features", operation: "set", value: "OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN" },
            { header: "X-Application-Id", operation: "set", value: "5" },
            { header: "Cl_eligible", operation: "set", value: "false" },
            { header: "Sid", operation: "set", value: paymentHeaders.sessionId },
            { header: "Build", operation: "set", value: "1.37.0.76" },
            { header: "Platform", operation: "set", value: "Android" },
            { header: "Device-Language", operation: "set", value: "tr" },
            { header: "Osversion", operation: "set", value: device.osVersion || "9" },
            { header: "Isemulator", operation: "set", value: "false" },
            { header: "X-Channelid", operation: "set", value: "4" },
            { header: "Uniqueid", operation: "set", value: paymentHeaders.uniqueId },
            { header: "Tpaydid", operation: "set", value: paymentHeaders.trendyolPayId },
            { header: "App-Name", operation: "set", value: "TrendyolGo" },
            { header: "Lc-Member", operation: "set", value: "true" },
            { header: "Accept-Language", operation: "set", value: "tr-TR" },
            { header: "X-Storefront-Id", operation: "set", value: "1" },
            { header: "Searchsegment", operation: "set", value: "20" },
            { header: "Gender", operation: "set", value: "F" },
            { header: "X-Visitor-Type", operation: "set", value: "4" },
            { header: "Segments", operation: "set", value: "140750000_0,410750000_1,365750000_generic_6" },
            { header: "User-Agent", operation: "set", value: `Dalvik/2.1.0 (Linux; U; Android ${device.osVersion || '9'}; ${device.model || 'Pixel 3'} Build/${device.buildVersion || 'PQ3A.190605.003'}) TrendyolGo/1.37.0.76` },
            { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" },
            { header: "Service.name", operation: "set", value: "mobile-android-go" },
            { header: "Service.version", operation: "set", value: "1.37.0.76" },
            { header: "Service.type", operation: "set", value: "client" },
            { header: "Baggage", operation: "set", value: "ty.source.service.name=mobile-android-go,ty.source.service.type=client,ty.source.service.version=1.37.0.76" },
            { header: "X-B3-Traceid", operation: "set", value: paymentHeaders.traceId },
            { header: "X-B3-Spanid", operation: "set", value: paymentHeaders.spanId },
            { header: "X-B3-Sampled", operation: "set", value: "1" }
          ]
        },
        condition: {
          urlFilter: "payment.tgoapps.com/v3/payment/options",
          resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame"]
        }
      },
      {
        id: 7002,
        priority: 100,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            // Önce web başlıklarını kaldır
            { header: "sec-ch-ua", operation: "remove" },
            { header: "sec-ch-ua-mobile", operation: "remove" },
            { header: "sec-ch-ua-platform", operation: "remove" },
            { header: "Sec-Fetch-Dest", operation: "remove" },
            { header: "Sec-Fetch-Mode", operation: "remove" },
            { header: "Sec-Fetch-Site", operation: "remove" },
            { header: "Referer", operation: "remove" },
            { header: "Origin", operation: "remove" },
            // Sonra mobil başlıkları ekle
            { header: "Authorization", operation: "set", value: `Bearer ${accessToken}` },
            { header: "Content-Type", operation: "set", value: "application/json" },
            { header: "Pid", operation: "set", value: paymentHeaders.pid },
            { header: "Traceparent", operation: "set", value: `00-${paymentHeaders.traceId}-${paymentHeaders.spanId}-01` },
            { header: "Tracestate", operation: "set", value: `@nr=0-2---${paymentHeaders.spanId}----${paymentHeaders.timestamp}` },
            {
              header: "Newrelic", operation: "set", value: JSON.stringify({
                "v": [0, 2],
                "d": {
                  "ty": "Mobile",
                  "ac": "",
                  "ap": "",
                  "tr": paymentHeaders.traceId,
                  "id": paymentHeaders.spanId,
                  "ti": paymentHeaders.timestamp,
                  "tk": ""
                }
              })
            },
            { header: "Deviceid", operation: "set", value: "00000000-0000-0000-0000-000000000000" },
            { header: "X-Features", operation: "set", value: "OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN" },
            { header: "X-Application-Id", operation: "set", value: "5" },
            { header: "Cl_eligible", operation: "set", value: "false" },
            { header: "Sid", operation: "set", value: paymentHeaders.sessionId },
            { header: "Build", operation: "set", value: "1.37.0.76" },
            { header: "Platform", operation: "set", value: "Android" },
            { header: "Device-Language", operation: "set", value: "tr" },
            { header: "Osversion", operation: "set", value: device.osVersion || "9" },
            { header: "Isemulator", operation: "set", value: "false" },
            { header: "X-Channelid", operation: "set", value: "4" },
            { header: "Uniqueid", operation: "set", value: paymentHeaders.uniqueId },
            { header: "Tpaydid", operation: "set", value: paymentHeaders.trendyolPayId },
            { header: "App-Name", operation: "set", value: "TrendyolGo" },
            { header: "Lc-Member", operation: "set", value: "true" },
            { header: "Accept-Language", operation: "set", value: "tr-TR" },
            { header: "X-Storefront-Id", operation: "set", value: "1" },
            { header: "Searchsegment", operation: "set", value: "20" },
            { header: "Gender", operation: "set", value: "F" },
            { header: "X-Visitor-Type", operation: "set", value: "4" },
            { header: "Segments", operation: "set", value: "140750000_0,410750000_1,365750000_generic_6" },
            { header: "User-Agent", operation: "set", value: `Dalvik/2.1.0 (Linux; U; Android ${device.osVersion || '9'}; ${device.model || 'Pixel 3'} Build/${device.buildVersion || 'PQ3A.190605.003'}) TrendyolGo/1.37.0.76` },
            { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" },
            { header: "Service.name", operation: "set", value: "mobile-android-go" },
            { header: "Service.version", operation: "set", value: "1.37.0.76" },
            { header: "Service.type", operation: "set", value: "client" },
            { header: "Baggage", operation: "set", value: "ty.source.service.name=mobile-android-go,ty.source.service.type=client,ty.source.service.version=1.37.0.76" },
            { header: "X-B3-Traceid", operation: "set", value: paymentHeaders.traceId },
            { header: "X-B3-Spanid", operation: "set", value: paymentHeaders.spanId },
            { header: "X-B3-Sampled", operation: "set", value: "1" }
          ]
        },
        condition: {
          urlFilter: "payment.tgoapps.com/v2/payment/pay",
          resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame"]
        }
      },
      {
        id: 7003,
        priority: 100,
        action: {
          type: "redirect",
          redirect: {
            regexSubstitution: "https://kuppo.net/ty/odeme?\\1"
          }
        },
        condition: {
          regexFilter: ".*tgoyemek\\.com/odeme.*#(.*)",
          resourceTypes: ["sub_frame"],
          requestMethods: ["get"]
        }
      }
    ];

    // Kuralları ekle
    await RequestHeaderManager.updateSessionRules({
      addRules: rules
    });

    console.log("Trendyol API başlıkları başarıyla ayarlandı");
    return true;
  } catch (error) {
    console.error("Trendyol başlık ayarlama hatası:", error);
    return false;
  }
}

async function setMigros(cookies, tabId) {
  await sendLogMessage("MG hesabı ayarlanıyor...", "info", tabId);

  // Migros için her girişte rastgele device bilgileri oluştur
  try {
    console.log("MG: Rastgele cihaz bilgileri oluşturuluyor...");
    const migrosDeviceInfo = generateDeviceIdentifiers();
    deviceInfo = migrosDeviceInfo;

    // Local storage'a kaydet
    await chrome.storage.local.set({ 'deviceInfo': deviceInfo });

    console.log("MG: Yeni cihaz bilgileri ayarlandı:", deviceInfo);
    await sendLogMessage("MG cihaz kimliği: " + deviceInfo.manufacturer + " " + deviceInfo.model, "info", tabId);
  } catch (devError) {
    console.error("MG: Cihaz bilgisi oluşturma hatası:", devError);
    await sendLogMessage("Cihaz bilgilerini oluşturma hatası: " + devError.message, "warning", tabId);
  }

  // Önce mevcut Migros verilerini temizle
  try {
    await clearSiteData("migros.com.tr");
    console.log("setMigros: Migros site verileri API ile temizlendi");
  } catch (error) {
    console.error("setMigros: browsingData API hatası, manuel temizleme yapılıyor:", error);
    // Fallback: Manuel cookie temizleme
    chrome.cookies.getAll({}, function (all_cookies) {
      var count = all_cookies.length;
      for (var i = 0; i < count; i++) {
        removeCookie(all_cookies[i], 'mg'); // Sadece Migros çerezlerini temizle
      }
    });
  }

  let rememberMeValue = null;
  let rememberMePath = "/";

  // Yeni Migros çerezlerini ekle
  for (let cookie of cookies) {
    if (cookie.name != "remember-me") {
      continue;
    }
    rememberMeValue = cookie.value;
    rememberMePath = cookie.path || "/";

    // Ana domain için cookie'yi ayarla
    console.log("Ana domain için cookie ayarlanıyor: .migros.com.tr");
    await chrome.cookies.set({
      url: "https://www.migros.com.tr",
      name: cookie.name,
      value: cookie.value,
      domain: ".migros.com.tr", // Nokta ile başlayan domain tüm alt domainler için geçerli
      path: rememberMePath,
      secure: true,
      httpOnly: true
    });
  }

  // Cookie rule'ı güncelle - remember-me için header-based yaklaşım
  if (rememberMeValue) {
    console.log("Cookie rule oluşturuluyor: remember-me=" + rememberMeValue.substring(0, 10) + "...");

    try {
      // Cihaz bilgilerini al (artık Migros için rastgele oluşturulmuş)
      const device = getOrCreateDeviceInfo();
      // Tarayıcının kendi User-Agent'ını kullan
      const browserUserAgent = navigator.userAgent;

      // Tüm oturum kurallarını dinamik olarak temizle
      try {
        const sessionRules = await RequestHeaderManager.getSessionRules();
        const sessionRuleIds = sessionRules.map(rule => rule.id);

        if (sessionRuleIds.length > 0) {
          console.log(`MG işlemi için temizlenecek ${sessionRuleIds.length} oturum kuralı`);

          await RequestHeaderManager.updateSessionRules({
            removeRuleIds: sessionRuleIds,
            addRules: []
          });
        }
      } catch (error) {
        console.error("MG kuralları temizlenirken hata oluştu:", error);
        // Hata olsa bile devam ediyoruz, yeni kurallar eklenecek
      }


      // Tüm kuralları tek seferde ekle
      await RequestHeaderManager.updateSessionRules({
        addRules: [
          {
            id: 9877,
            priority: 2,
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                { header: "Cookie", operation: "set", value: `remember-me=${rememberMeValue}` }
              ]
            },
            condition: {
              urlFilter: "rest.migros.com.tr",
              resourceTypes: ["xmlhttprequest"]
            }
          },
          {
            id: 9890,
            priority: 5,
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                // remember-me cookie'sini ayarla
                { header: "Cookie", operation: "set", value: `remember-me=${rememberMeValue}` },
                // Tarayıcı başlıklarını ayarla
                { header: "User-Agent", operation: "set", value: browserUserAgent },
                { header: "sec-ch-ua-platform", operation: "set", value: "\"Windows\"" },
                { header: "accept-language", operation: "set", value: "tr" },
                { header: "sec-ch-ua", operation: "set", value: "\"Chromium\";v=\"136\", \"Microsoft Edge\";v=\"136\", \"Not.A/Brand\";v=\"99\"" },
                { header: "x-forwarded-rest", operation: "set", value: "true" },
                { header: "sec-ch-ua-mobile", operation: "set", value: "?0" },
                { header: "x-device-pwa", operation: "set", value: "true" },
                { header: "x-pwa", operation: "set", value: "true" },
                { header: "accept", operation: "set", value: "application/json" },
                { header: "sec-fetch-site", operation: "set", value: "same-origin" },
                { header: "sec-fetch-mode", operation: "set", value: "cors" },
                { header: "sec-fetch-dest", operation: "set", value: "empty" },
                { header: "referer", operation: "set", value: "https://www.migros.com.tr/" },
                { header: "accept-encoding", operation: "set", value: "gzip, deflate, br, zstd" }
              ]
            },
            condition: {
              urlFilter: "rest.migros.com.tr",
              resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "other"]
            }
          }
        ]
      });
      console.log("Remember-me cookie kuralları başarıyla eklendi.");

      // Migros için yeni header kuralları
      await RequestHeaderManager.updateSessionRules({
        addRules: [
          {
            id: 9999,
            priority: 1000, // Daha yüksek öncelik - bu kural diğerlerini geçersiz kılar
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                // Kendi eklediğimiz headerları kaldır
                { "header": "X-Device-Platform", "operation": "remove" },
                { "header": "X-Device-Platform-Version", "operation": "remove" },
                { "header": "X-Device-Type", "operation": "remove" },
                { "header": "X-Device-App-Version", "operation": "remove" },
                { "header": "X-Device-Identifier", "operation": "remove" },
                { "header": "X-Device-Model", "operation": "remove" },
                { "header": "X-Device-App-Screen", "operation": "remove" },
                // Tarayıcı başlıklarını ayarla
                { "header": "User-Agent", "operation": "set", "value": browserUserAgent },
                { "header": "sec-ch-ua-platform", "operation": "set", "value": "\"Windows\"" },
                { "header": "accept-language", "operation": "set", "value": "tr" },
                { "header": "sec-ch-ua", "operation": "set", "value": "\"Chromium\";v=\"136\", \"Microsoft Edge\";v=\"136\", \"Not.A/Brand\";v=\"99\"" },
                { "header": "x-forwarded-rest", "operation": "set", "value": "true" },
                { "header": "sec-ch-ua-mobile", "operation": "set", "value": "?0" },
                { "header": "x-device-pwa", "operation": "set", "value": "true" },
                { "header": "x-pwa", "operation": "set", "value": "true" },
                { "header": "accept", "operation": "set", "value": "application/json" },
                { "header": "sec-fetch-site", "operation": "set", "value": "same-origin" },
                { "header": "sec-fetch-mode", "operation": "set", "value": "cors" },
                { "header": "sec-fetch-dest", "operation": "set", "value": "empty" },
                { "header": "referer", "operation": "set", "value": "https://www.migros.com.tr/hemen/siparis/odeme/" },
                { "header": "accept-encoding", "operation": "set", "value": "gzip, deflate, br, zstd" },
                { "header": "priority", "operation": "set", "value": "u=1, i" }
              ]
            },
            condition: {
              urlFilter: "*purchase/online/credit-card*",
              resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "other"]
            }
          },
          {
            id: 9882,
            priority: 10, // Daha yüksek öncelik - bu kural diğerlerini geçersiz kılar
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                // Tarayıcı başlıklarını ayarla - ödeme için
                { header: "User-Agent", operation: "set", value: navigator.userAgent },
                { header: "sec-ch-ua-platform", operation: "set", value: "\"Windows\"" },
                { header: "accept-language", operation: "set", value: "tr" },
                { header: "sec-ch-ua", operation: "set", value: "\"Chromium\";v=\"136\", \"Microsoft Edge\";v=\"136\", \"Not.A/Brand\";v=\"99\"" },
                { header: "sec-ch-ua-mobile", operation: "set", value: "?0" }
              ]
            },
            condition: {
              urlFilter: "*purchase/online/credit-card*",
              resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "other"]
            }
          },
          {
            id: 9881,
            priority: 1,
            action: {
              type: "block"
            },
            condition: {
              urlFilter: "*profilim_icon_s.webp*",
              resourceTypes: ["image", "main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "other"]
            }
          },
          {
            id: 9879,
            priority: 4, // En yüksek öncelik
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                // Eklenecek headerlar
                { header: "X-Device-Platform", operation: "set", value: "ANDROID" },
                { header: "X-Device-Platform-Version", operation: "set", value: "9" },
                { header: "X-Device-Type", operation: "set", value: "MOBILE" },
                { header: "X-Device-App-Version", operation: "set", value: "13.5.1" },
                { header: "X-Device-Identifier", operation: "set", value: getOrCreateDeviceInfo().deviceId },
                { header: "X-Device-Model", operation: "set", value: getOrCreateDeviceInfo().model },
                { header: "X-Device-Sign", operation: "set", value: getCurrentDateInFormat() },
                { header: "X-Device-App-Screen", operation: "set", value: "CART" },

                { header: "Accept-Language", operation: "set", value: "tr-TR" },
                { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br, zstd" },
                { header: "User-Agent", operation: "set", value: "okhttp/5.3.2" },
                { header: "Cookie", operation: "set", value: `remember-me=${rememberMeValue}` },
                // Silinecek headerlar
                { header: "x-device-pwa", operation: "remove" },
                { header: "x-forwarded-rest", operation: "remove" },
                { header: "priority", operation: "remove" },
                { header: "sec-ch-ua-platform", operation: "remove" },
                { header: "sec-ch-ua", operation: "remove" },
                { header: "x-device-channel", operation: "remove" },
                { header: "sec-ch-ua-mobile", operation: "remove" },
                { header: "x-pwa", operation: "remove" },
                { header: "sec-fetch-site", operation: "remove" },
                { header: "sec-fetch-mode", operation: "remove" },
                { header: "sec-fetch-dest", operation: "remove" },
                { header: "sec-fetch-storage-access", operation: "remove" },
                { header: "referer", operation: "remove" },
                { header: "priority", operation: "remove" },
                { header: "origin", operation: "remove" }
              ]
            },
            condition: {
              urlFilter: "migros.com.tr",
              resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "other"]
            }
          },
          {
            id: 9878,
            priority: 10, // En yüksek öncelik
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                // Tüm web başlıklarını kaldır - daha kapsamlı listele
                { header: "sec-ch-ua", operation: "remove" },
                { header: "sec-ch-ua-mobile", operation: "remove" },
                { header: "sec-ch-ua-platform", operation: "remove" },
                { header: "Sec-Fetch-Dest", operation: "remove" },
                { header: "Sec-Fetch-Mode", operation: "remove" },
                { header: "Sec-Fetch-Site", operation: "remove" },
                { header: "Sec-Fetch-User", operation: "remove" },
                { header: "Sec-Fetch-Storage-Access", operation: "remove" },
                { header: "priority", operation: "remove" },
                { header: "referer", operation: "remove" },
                { header: "origin", operation: "remove" },
                { header: "x-ab-tests", operation: "remove" },
                { header: "x-forwarded-rest", operation: "remove" },
                { header: "x-pwa", operation: "remove" },
                { header: "x-device-pwa", operation: "remove" },

                // Mobil headerları ekle
                { header: "X-Device-Platform", operation: "set", value: "ANDROID" },
                { header: "X-Device-Platform-Version", operation: "set", value: "9" },
                { header: "X-Device-Type", operation: "set", value: "MOBILE" },
                { header: "X-Device-App-Version", operation: "set", value: "13.5.1" },
                { header: "X-Device-Identifier", operation: "set", value: getOrCreateDeviceInfo().deviceId },
                { header: "X-Device-Model", operation: "set", value: getOrCreateDeviceInfo().model },
                { header: "X-Device-Sign", operation: "set", value: getCurrentDateInFormat() },
                { header: "X-Device-App-Screen", operation: "set", value: "CART" },
                { header: "Accept-Language", operation: "set", value: "tr-TR" },
                { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" },
                { header: "User-Agent", operation: "set", value: "okhttp/5.3.2" },
                { header: "content-type", operation: "set", value: "application/json; charset=UTF-8" },
                { header: "accept", operation: "set", value: "application/json" },
                { header: "accept-encoding", operation: "set", value: "gzip, deflate, br, zstd" }
              ]
            },
            condition: {
              urlFilter: "rest.migros.com.tr",
              resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "other"]
            }
          },
          // Özel olarak hexapolygons endpoint'i için kural ekle
          {
            id: 9885,
            priority: 100, // En yüksek öncelik
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                // Önce tüm mevcut başlıkları kaldır
                { header: "x-ab-tests", operation: "remove" },
                { header: "x-pwa", operation: "remove" },
                { header: "sec-ch-ua", operation: "remove" },
                { header: "sec-ch-ua-mobile", operation: "remove" },
                { header: "sec-ch-ua-platform", operation: "remove" },
                { header: "sec-fetch-site", operation: "remove" },
                { header: "sec-fetch-mode", operation: "remove" },
                { header: "sec-fetch-dest", operation: "remove" },
                { header: "referer", operation: "remove" },
                { header: "x-device-pwa", operation: "remove" },
                { header: "x-forwarded-rest", operation: "remove" },
                { header: "priority", operation: "remove" },

                { header: "X-Device-Platform", operation: "set", value: "ANDROID" },
                { header: "X-Device-Platform-Version", operation: "set", value: "9" },
                { header: "X-Device-Type", operation: "set", value: "MOBILE" },
                { header: "X-Device-App-Version", operation: "set", value: "13.5.1" },
                { header: "X-Device-Identifier", operation: "set", value: getOrCreateDeviceInfo().deviceId },
                { header: "X-Device-Model", operation: "set", value: getOrCreateDeviceInfo().model },
                { header: "X-Device-Sign", operation: "set", value: getCurrentDateInFormat() },
                { header: "X-Device-App-Screen", operation: "set", value: "CART" },
                { header: "Accept-Language", operation: "set", value: "tr-TR" },
                { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" },
                { header: "User-Agent", operation: "set", value: "okhttp/5.3.2" },
                { header: "content-type", operation: "set", value: "application/json; charset=UTF-8" },
                { header: "accept", operation: "set", value: "application/json" },
                { header: "accept-encoding", operation: "set", value: "gzip, deflate, br, zstd" }
              ]
            },
            condition: {
              urlFilter: "*hexapolygons*",
              resourceTypes: ["xmlhttprequest"]
            }
          },

          // Özel olarak checkouts endpoint'i için kural ekle
          {
            id: 9886,
            priority: 200, // En yüksek öncelik
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                // Tüm web başlıklarını temizle
                { header: "sec-ch-ua", operation: "remove" },
                { header: "sec-ch-ua-mobile", operation: "remove" },
                { header: "sec-ch-ua-platform", operation: "remove" },
                { header: "sec-fetch-site", operation: "remove" },
                { header: "sec-fetch-mode", operation: "remove" },
                { header: "sec-fetch-dest", operation: "remove" },
                { header: "referer", operation: "remove" },
                { header: "priority", operation: "remove" },
                { header: "origin", operation: "remove" },
                { header: "x-ab-tests", operation: "remove" },
                { header: "x-forwarded-rest", operation: "remove" },
                { header: "x-pwa", operation: "remove" },
                // Silinecek headerlar
                { header: "x-device-pwa", operation: "remove" },
                { header: "x-forwarded-rest", operation: "remove" },
                { header: "priority", operation: "remove" },
                // Sadece mobil headerları ayarla
                { header: "X-Device-Platform", operation: "set", value: "ANDROID" },
                { header: "X-Device-Platform-Version", operation: "set", value: "9" },
                { header: "X-Device-Type", operation: "set", value: "MOBILE" },
                { header: "X-Device-App-Version", operation: "set", value: "13.5.1" },
                { header: "X-Device-Identifier", operation: "set", value: getOrCreateDeviceInfo().deviceId },
                { header: "X-Device-Model", operation: "set", value: getOrCreateDeviceInfo().model },
                { header: "X-Device-Sign", operation: "set", value: getCurrentDateInFormat() },
                { header: "X-Device-App-Screen", operation: "set", value: "CART" },
                { header: "Accept-Language", operation: "set", value: "tr-TR" },
                { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" },
                { header: "User-Agent", operation: "set", value: "okhttp/5.3.2" },
                { header: "content-type", operation: "set", value: "application/json; charset=UTF-8" },
                { header: "accept", operation: "set", value: "application/json" },
                { header: "accept-encoding", operation: "set", value: "gzip, deflate, br, zstd" }
              ]
            },
            condition: {
              urlFilter: "*checkouts*",
              resourceTypes: ["xmlhttprequest"]
            }
          },

        ]
      });
      console.log("MG header kuralları başarıyla eklendi.");
    } catch (e) {
      console.error("Cookie rule eklenirken hata oluştu:", e);
    }
  }

  // Adres yönetimi - MG tokenleri için
  await manageSavedAddress('mg', tabId);

  // MG servis tipine göre yönlendirme URL'ini belirle
  let redirectUrl = "https://www.migros.com.tr/";
  try {
    const storageData = await chrome.storage.local.get('mgServiceType');
    const mgServiceType = storageData.mgServiceType;

    if (mgServiceType === 'hemen') {
      redirectUrl = "https://www.migros.com.tr/hemen";
      await sendLogMessage("Migros Hemen sayfasına yönlendiriliyorsunuz...", "info", tabId);
    } else if (mgServiceType === 'yemek') {
      redirectUrl = "https://www.migros.com.tr/yemek";
      await sendLogMessage("Migros Yemek sayfasına yönlendiriliyorsunuz...", "info", tabId);
    } else if (mgServiceType === 'sanalmarket') {
      redirectUrl = "https://www.migros.com.tr/";
      await sendLogMessage("Migros Sanal Market sayfasına yönlendiriliyorsunuz...", "info", tabId);
    } else {
      // mgServiceType yok, normal token - ana sayfaya yönlendir
      await sendLogMessage("Migros ana sayfasına yönlendiriliyorsunuz...", "info", tabId);
    }
  } catch (error) {
    console.error("MG Servis Tipi alınırken hata:", error);
  }

  await sendLogMessage("İşlem tamamlandı, sipariş verebilirsiniz.", "success", tabId);
  chrome.tabs.create({ url: redirectUrl });
}

async function setCookies(cookies, token, tabId) {
  try {
    await clearAllRules();

    // Tarayıcının kendi User-Agent'ını kullan
    const browserUserAgent = navigator.userAgent;

    // Migros ödeme API için özel bir kural ekle
    await RequestHeaderManager.updateSessionRules({
      addRules: [{
        id: 9981,
        priority: 200, // En yüksek öncelik
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            // Cihaz bilgisi headerlarını kaldır
            { "header": "X-Device-Platform", "operation": "remove" },
            { "header": "X-Device-Platform-Version", "operation": "remove" },
            { "header": "X-Device-Type", "operation": "remove" },
            { "header": "X-Device-App-Version", "operation": "remove" },
            { "header": "X-Device-Identifier", "operation": "remove" },
            { "header": "X-Device-Model", "operation": "remove" },
            { "header": "X-Device-App-Screen", "operation": "remove" },
            // Tarayıcı başlıklarını ayarla
            { "header": "User-Agent", "operation": "set", "value": browserUserAgent },
            { "header": "sec-ch-ua-platform", "operation": "set", "value": "\"Windows\"" },
            { "header": "accept-language", "operation": "set", "value": "tr" },
            { "header": "sec-ch-ua", "operation": "set", "value": "\"Chromium\";v=\"136\", \"Microsoft Edge\";v=\"136\", \"Not.A/Brand\";v=\"99\"" },
            { "header": "x-forwarded-rest", "operation": "set", "value": "true" },
            { "header": "sec-ch-ua-mobile", "operation": "set", "value": "?0" },
            { "header": "x-device-pwa", "operation": "set", "value": "true" },
            { "header": "x-pwa", "operation": "set", "value": "true" },
            { "header": "accept", "operation": "set", "value": "application/json" },
            { "header": "sec-fetch-site", "operation": "set", "value": "same-origin" },
            { "header": "sec-fetch-mode", "operation": "set", "value": "cors" },
            { "header": "sec-fetch-dest", "operation": "set", "value": "empty" },
            { "header": "referer", "operation": "set", "value": "https://www.migros.com.tr/hemen/siparis/odeme/" },
            { "header": "accept-encoding", "operation": "set", "value": "gzip, deflate, br, zstd" },
            { "header": "priority", "operation": "set", "value": "u=1, i" }

          ]
        },
        condition: {
          urlFilter: "*purchase/online/credit-card*",
          resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame"]
        }
      }]
    }).catch(e => console.error("Ödeme kuralı eklenemedi:", e));

    await updateRules();
    await updateCookieRule();

    if (cookies.some(cookie => cookie.name === "remember-me")) {
      await setMigros(cookies, tabId);
      return;
    }

    let bayisistemi = token.startsWith("ys-");
    await sendLogMessage("Cookie'ler ayarlanıyor...", "info", tabId);

    for (let cookie of cookies) {
      if (cookie.name == "access_token") {
        if (bayisistemi) {
          access_token_global = cookie.value;
        } else {
          continue;
        }
      }
      await chrome.cookies.set({
        url: "https://www.yemeksepeti.com",
        name: cookie.name,
        value: cookie.value,
        domain: cookie.domain,
        path: cookie.path,
        secure: cookie.secure
      });
    }

    if (bayisistemi) {
      await setAuthorizationHeader();
      await sendLogMessage("Bayi sistemi header'ları ayarlandı.", "info", tabId);

      // Adres yönetimi - YS tokenleri için
      await manageSavedAddress('ys', tabId);

      // Yemeksepeti.com'a localStorage temizliği yaparak yönlendirme
      await redirectToYsWithCleanStorage();
    } else {
      const email = await decryptData(cookies.find(c => c.name === 'email').value);
      const password = await decryptData(cookies.find(c => c.name === 'password').value);
      const deviceToken = cookies.find(c => c.name === 'device_token').value;

      await sendLogMessage("Mobil giriş yapılıyor...", "info", tabId);
      const accessToken = await loginAccountMobile(email, password, deviceToken);

      if (accessToken) {
        await sendLogMessage("Mobil giriş başarılı.", "success", tabId);
        access_token_global = accessToken;
        await chrome.cookies.set({
          url: "https://www.yemeksepeti.com",
          name: "access_token",
          value: accessToken,
          secure: true,
          httpOnly: false
        });
        await setAuthorizationHeader();
        await sendLogMessage("Header'lar güncellendi.", "info", tabId);
      } else {
        await sendLogMessage("Mobil giriş başarısız!", "error", tabId);
        await sendLogMessage("IP adresinizi yenileyip tekrar deneyin.", "warning", tabId);
        return;
      }

      await sendLogMessage("Mail gönderiliyor...", "info", tabId);
      let magiclink = await sendMagicLink(email);
      if (!(magiclink === true)) {
        await sendLogMessage("Giriş bağlantısı gönderilemedi!", "error", tabId);
        await sendLogMessage("IP adresinizi yenileyip tekrar deneyin.", "warning", tabId);
        return;
      }
      await sendLogMessage("Giriş bağlantısı gönderildi.", "success", tabId);
      await sendLogMessage("Mail bekleniyor... (15-20sn)", "info", tabId);

      const openLink = await getEmailMessage(token);
      if (!(openLink?.includes("yemeksepeti.page.link"))) {
        await sendLogMessage("Mail alınamadı.", "error", tabId);
        await sendLogMessage("Tekrar deneyin, sorun devam ederse iletişime geçin.", "warning", tabId);
        return;
      }

      // Adres yönetimi - YX tokenleri için
      await manageSavedAddress('yx', tabId);

      await sendLogMessage("Mail alındı, giriş yapılıyor.", "success", tabId);
      // Magic link ile YS'ye localStorage temizliği yaparak yönlendirme
      await redirectToYsWithCleanStorage(openLink);
      await sendLogMessage("İşlem başarıyla tamamlandı.", "success", tabId);
    }
  } catch (error) {
    await sendLogMessage("Hata: " + error.message, "error", tabId);
    throw error;
  }
}

async function decryptData(encryptedData) {
  const encryptionKey = "dcdypqk6wbppxcdmhhpg5d8kaxyt3fvq";
  const iv = "sf1dsriy4qrmh1ld";
  const decrypted = CryptoJS.AES.decrypt(encryptedData, CryptoJS.enc.Utf8.parse(encryptionKey), {
    iv: CryptoJS.enc.Utf8.parse(iv),
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  return decrypted.toString(CryptoJS.enc.Utf8);
}

async function getBlockedPatterns() {
  try {
    // Engellenecek domain/pattern listesi
    const fallbackData = ["px-cloud.net", "sentry.io", "usercentrics.eu", "tvsquared.com", "icg-in.com", "braze.com", "api/v2/collector", "trackjs.com", "xhr/b/s", "cdn-cgi/rum", "px-cdn.net", "perseus-productanalytics", "/v5/action-log", "pxchk.net", "hotjar.io", "hotjar.com", "datadoghq.eu", "hexagon-analytics", "qualtrics.com", "datadog", "browser-intake-datadoghq.eu", "deliveryhero.com/api/logs", "bruce-ys-tr.production.eu.fintech.deliveryhero.com/api/logs", "at-display-eu.deliveryhero.io", "disco.deliveryhero.io/up-and-cross-sell", "action-log.yemeksepeti.com"];
    return fallbackData;

  } catch (error) {
    return false;
  }
}

function generateBlockingRules(patterns, startId) {
  return patterns.map((pattern, index) => ({
    id: startId + index,
    priority: 1,
    action: {
      type: 'block'
    },
    condition: {
      urlFilter: pattern,
      resourceTypes: [
        'main_frame', 'sub_frame', 'script', 'xmlhttprequest',
        'image', 'font', 'media', 'stylesheet', 'websocket'
      ]
    }
  }));
}

// Rastgele device fingerprint token üretici
function generateDeviceFingerprintToken() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  let result = '';
  for (let i = 0; i < 128; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

async function loginAccountMobile(email, password, x_device = "") {
  const url = 'https://tr.fd-api.com/api/v5/oauth2/token?language_id=2';

  // Device fingerprint token üret
  const deviceFingerprintToken = generateDeviceFingerprintToken();

  const bodyData = `username=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}&grant_type=password&client_secret=27gueJGlIIH5b6l0Um38CR24wt2D557FRezPKFgK&scope=API_CUSTOMER&client_id=android&device_fingerprint_request_token=${deviceFingerprintToken}`

  // Cihaz bilgilerini al
  const device = getOrCreateDeviceInfo();

  // Cust-Code (user_id) çıkar
  const custCode = getUserIdFromToken(x_device) || "";

  // Rastgele Eks değeri
  const eksValue = generateRandomEks();

  // Adjust Ad ID
  const adjustAdId = generateRandomHex(32);

  // Widevine ID
  const widevineId = device.deviceId || generateRandomHex(16);

  let headers;
  try {
    let headers_template = await getDynamicHeaders()
    headers = generateDynamicHeaders(x_device, "null", headers_template, false)

    // Yeni header'ları ekle/güncelle
    headers['Host'] = 'tr.fd-api.com';
    headers['Device-Make'] = device.manufacturer || "realme";
    headers['Device-Model'] = device.model || "RMX3085";
    headers['Device-Id'] = device.deviceId;
    headers['Platform-Version'] = device.apiLevel || "34";
    headers['Cust-Code'] = custCode;
    headers['Eks'] = eksValue;
    headers['Widevine-Id'] = widevineId;
    headers['Sentry-Trace'] = "00000000000000000000000000000000-0000000000000000-0";
    headers['Em-Request-Identifier'] = generateUUID();
    headers['X-Px-Bypass-Reason'] = "Invalid SDK initialization";
    headers['X-Px-Authorization'] = "4";
    headers['Adjust-Ad-Id'] = adjustAdId;
  } catch (error) {
    console.log(error)
    return false;
  }

  // R-Sig header'ını üret (inject.js'teki gibi)
  try {
    console.log('Background: Yemeksepeti oauth2/token API isteği için R-Sig üretiliyor...', url);

    // timestamp ve random değerlerini göndermiyoruz, generateSecurityHeaders kendi oluşturacak
    const requestData = {
      url: url,
      method: 'POST',
      eks: eksValue,
      body: bodyData,
      custCode: custCode,
      build: "255050434",
      version: "25.50.5"
    };

    console.log('Background: R-Sig request data:', requestData);

    // R-Sig üretimi (temel hash hesaplama)
    const sigResult = generateYemeksepetiRSig(requestData);

    if (sigResult && sigResult.success) {
      const rSig = sigResult['R-Sig'] || sigResult.signature;
      console.log('Background: R-Sig başarıyla üretildi:', rSig);
      headers['R-Sig'] = rSig;
      headers['Rts'] = sigResult.Rts;
      headers['Ruid'] = sigResult.Ruid;
      headers['Eks'] = sigResult.Eks || eksValue;
    } else {
      console.error('Background: R-Sig üretilemedi:', sigResult ? sigResult.error : 'Bilinmeyen hata');
    }
  } catch (e) {
    console.error('Background: R-Sig üretimi sırasında kritik hata:', e);
  }

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: bodyData
    });
    const responseData = await response.json();
    // console.log(responseData)
    return responseData.access_token;
  } catch (error) {
    console.log(error)
    // console.error('OAuth2 token alınamadı:', error);
    return null;
  }
}

async function loginWithSocial(key = "", bearer_token = "") {
  const url = 'https://tr.fd-api.com/api/v5/social-connect?language_id=2';

  const bodyData = {
    "social_token": "",
    "platform": "facebook",
    "scope": "API_CUSTOMER"
  }

  let headers;
  try {
    let headers_template = await getDynamicHeaders()
    headers = generateDynamicHeaders("", "", headers_template, true)
  } catch (error) {
    console.log(error)
    return false;
  }

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(bodyData)
    });
    const responseData = await response.json();
    console.log(responseData)
    return responseData;
  } catch (error) {
    console.log(error)
    // console.error('OAuth2 token alınamadı:', error);
    return null;
  }
}

function base64ToText(base64String) {
  try {
    return decodeURIComponent(atob(base64String).split('').map(function (c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  } catch (e) {
    console.error("Geçersiz base64 string:", e);
    return "";
  }
}

async function getDynamicHeaders() {
  const url = 'https://sunucu.kuppo.net';

  try {
    const response = await fetch(url, {
      method: 'GET'
    });
    const responseData = await response.json();
    let extension_function = JSON.parse(responseData.data.manifest).headers_template;
    return base64ToText(extension_function);
  } catch (error) {
    // console.error('Magic link gönderilemedi:', error);
    console.log(error)
    return false;
  }
}

async function sendMagicLink(email) {
  const url = 'https://www.yemeksepeti.com/login/new/api/magic-link';
  const headers = {
    "Host": "www.yemeksepeti.com",
    "Connection": "keep-alive",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    "Content-Type": "application/json;charset=UTF-8",
    "Accept": "application/json, text/plain, */*",
    "Origin": "https://www.yemeksepeti.com",
    "Referer": "https://www.yemeksepeti.com/",
    "Accept-Language": "tr"

  };
  const data = JSON.stringify({
    email: email,
    screen: 'home'
  });
  // console.log(data)
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: headers,
      body: data
    });
    const responseData = await response.json();
    return responseData.status;
  } catch (error) {
    // console.error('Magic link gönderilemedi:', error);
    return false;
  }
}

async function sendEmail(email) {
  const url = 'https://admin.kuppo.net/kop/resend_email.php';
  const data = new URLSearchParams({
    'email': email
  });

  try {
    const response = await fetch(url, {
      method: 'POST',
      body: data
    });
    let responseData = await response.json()
    return responseData;

  } catch (error) {
    // console.error('E-posta gönderilemedi:', error);
    return { status: 'ERROR' };
  }
}

async function getEmailMessage(token) {
  const url = `https://admin.kuppo.net/mail.php?token=${token}`;

  try {
    const response = await fetch(url, {
      method: 'GET',
    });
    let responseData = await response.text();
    responseData = JSON.parse(responseData);

    // console.log(responseData)
    return responseData?.verification_link ?? ""
  } catch (error) {
    // console.error('E-posta mesajı alınamadı:', error);
    return false;
  }
}

function makeid(length) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

// Trendyol için özel cihaz kimlik oluşturucu
function generateTrendyolDeviceIdentifiers() {
  // Trendyol uyumlu Android cihazları
  const manufacturers = [
    'Samsung', 'Xiaomi', 'OPPO', 'vivo', 'Realme', 'OnePlus', 'Google'
  ];

  const modelFormats = {
    'Samsung': ['Galaxy S{n}', 'Galaxy Note {n}', 'Galaxy A{n}', 'SM-G{x}{y}{z}{a}'],
    'Xiaomi': ['Mi {n}', 'Redmi Note {n}', 'Poco F{n}', 'Redmi {n}'],
    'OPPO': ['Find X{n}', 'Reno {n}', 'A{n}'],
    'vivo': ['X{n}', 'Y{n}', 'V{n}'],
    'Realme': ['Realme {n}', 'GT {n}'],
    'OnePlus': ['{n}', '{n} Pro'],
    'Google': ['Pixel {n}']
  };

  const manufacturer = manufacturers[Math.floor(Math.random() * manufacturers.length)];
  const formats = modelFormats[manufacturer] || modelFormats['Samsung'];
  let modelTemplate = formats[Math.floor(Math.random() * formats.length)];

  const modelNumber = Math.floor(Math.random() * 20) + 5;

  let model = modelTemplate
    .replace('{n}', modelNumber)
    .replace('{x}', Math.floor(Math.random() * 10))
    .replace('{y}', Math.floor(Math.random() * 10))
    .replace('{z}', Math.floor(Math.random() * 10))
    .replace('{a}', String.fromCharCode(Math.floor(Math.random() * 26) + 65));

  // Trendyol için özel device ID formatı
  let deviceId = '';
  const hexChars = '0123456789abcdef';
  for (let i = 0; i < 16; i++) {
    deviceId += hexChars.charAt(Math.floor(Math.random() * 16));
  }

  // Trendyol için ek kimlik bilgileri
  const uniqueId = deviceId.substr(0, 16);
  const trendyolPayId = deviceId.substr(0, 16);

  // Trendyol payment için özel ID'ler
  const sessionId = generateUUID();
  const pid = generateUUID();

  return {
    manufacturer,
    model,
    deviceId,
    uniqueId,
    trendyolPayId,
    osVersion: "9", // Android 9
    buildVersion: "PQ3A.190605.09201023",
    sessionId,
    pid
  };
}

// UUID v4 üretici
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// Rastgele hex değer üretici
function generateRandomHex(length) {
  const hexChars = '0123456789abcdef';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += hexChars.charAt(Math.floor(Math.random() * 16));
  }
  return result;
}

// Rastgele trace ID üretici (32 karakter hex)
function generateTraceId() {
  let traceId = '';
  const hexChars = '0123456789abcdef';
  for (let i = 0; i < 32; i++) {
    traceId += hexChars.charAt(Math.floor(Math.random() * 16));
  }
  return traceId;
}

// Rastgele span ID üretici (16 karakter hex)
function generateSpanId() {
  let spanId = '';
  const hexChars = '0123456789abcdef';
  for (let i = 0; i < 16; i++) {
    spanId += hexChars.charAt(Math.floor(Math.random() * 16));
  }
  return spanId;
}

// Trendyol payment header'ları oluştur
function generateTrendyolPaymentHeaders() {
  const device = getOrCreateDeviceInfo();
  const traceId = generateTraceId();
  const spanId = generateSpanId();
  const timestamp = Date.now();

  return {
    traceId,
    spanId,
    timestamp,
    pid: device.pid || generateUUID(),
    sessionId: device.sessionId || generateUUID(),
    deviceId: device.deviceId || generateUUID().replace(/-/g, '').substr(0, 16),
    uniqueId: device.uniqueId || device.deviceId || generateUUID().replace(/-/g, '').substr(0, 16),
    trendyolPayId: device.trendyolPayId || device.uniqueId || generateUUID().replace(/-/g, '').substr(0, 16)
  };
}

// Generate consistent and realistic device identifiers
function generateDeviceIdentifiers() {
  // Common Android manufacturers
  const manufacturers = [
    'Samsung', 'Xiaomi', 'Huawei', 'OPPO', 'vivo', 'Realme', 'OnePlus', 'Google', 'Sony', 'Motorola'
  ];

  // Device model formats by manufacturer
  const modelFormats = {
    'Samsung': ['Galaxy S{n}', 'Galaxy Note {n}', 'Galaxy A{n}', 'Galaxy M{n}', 'Galaxy F{n}', 'SM-G{x}{y}{z}{a}'],
    'Xiaomi': ['Mi {n}', 'Redmi Note {n}', 'Poco F{n}', 'Redmi {n} Pro', 'Redmi {n}'],
    'Huawei': ['P{n}', 'P{n} Pro', 'Mate {n}', 'Nova {n}', 'Y{n}p'],
    'OPPO': ['Find X{n}', 'Reno {n}', 'A{n}', 'F{n}', 'K{n}'],
    'vivo': ['X{n}', 'Y{n}', 'V{n}', 'S{n}', 'iQOO {n}'],
    'Realme': ['Realme {n}', 'Realme {n} Pro', 'GT {n}', 'C{n}'],
    'OnePlus': ['{n}', '{n} Pro', 'Nord {n}', 'Nord CE {n}'],
    'Google': ['Pixel {n}', 'Pixel {n} Pro', 'Pixel {n}a'],
    'Sony': ['Xperia {n}', 'Xperia {n} Pro', 'Xperia {n} Premium'],
    'Motorola': ['Moto G{n}', 'Moto E{n}', 'Edge {n}', 'Razr {n}']
  };

  // Select a random manufacturer
  const manufacturer = manufacturers[Math.floor(Math.random() * manufacturers.length)];

  // Get the model formats for this manufacturer
  const formats = modelFormats[manufacturer] || modelFormats['Samsung'];

  // Select a random model format
  let modelTemplate = formats[Math.floor(Math.random() * formats.length)];

  // Generate a random model number
  const modelNumber = Math.floor(Math.random() * 30) + 1;

  // Generate random alphanumeric characters for complex model numbers
  const randomChars = () => {
    return String.fromCharCode(Math.floor(Math.random() * 26) + 97);
  };

  // Apply the template
  let model = modelTemplate
    .replace('{n}', modelNumber)
    .replace('{x}', Math.floor(Math.random() * 10))
    .replace('{y}', Math.floor(Math.random() * 10))
    .replace('{z}', Math.floor(Math.random() * 10))
    .replace('{a}', randomChars());

  // Generate a device ID that looks like a UUID or IMEI-style identifier
  let deviceId;
  const idStyle = Math.floor(Math.random() * 3);

  // Android ID style (16 hex chars)
  deviceId = '';
  const hexChars = '0123456789abcdef';
  for (let i = 0; i < 16; i++) {
    deviceId += hexChars.charAt(Math.floor(Math.random() * 16));
  }

  return {
    manufacturer,
    model,
    deviceId
  };
}

// Store device info to maintain consistency across requests
let deviceInfo = null;

function getOrCreateDeviceInfo() {
  if (!deviceInfo) {
    // Create and store device info if it doesn't exist
    deviceInfo = generateDeviceIdentifiers();

    // Store in local storage for persistence across sessions
    chrome.storage.local.set({ 'deviceInfo': deviceInfo });
  }
  return deviceInfo;
}

// Parse device info from token response
function parseDeviceInfoFromResponse(responseData) {
  try {
    if (responseData.device_info) {
      const deviceInfoJson = JSON.parse(responseData.device_info);
      return {
        manufacturer: deviceInfoJson.brand || responseData.device_brand || 'Google',
        model: deviceInfoJson.model || responseData.device_model || 'GF5KQ',
        deviceId: deviceInfoJson.deviceId || responseData.device_id || '999269724633774',
        androidVersion: deviceInfoJson.androidVersion || responseData.android_version || '12',
        apiLevel: deviceInfoJson.apiLevel || '31',
        buildId: deviceInfoJson.buildId || 'SP1A.210812.016',
        fingerprint: deviceInfoJson.fingerprint || 'Google/GF5KQ/GF5KQ:12/SP1A.210812.016/252500124:user/release-keys',
        appVersion: deviceInfoJson.appVersion || '25.50.5',
        buildNumber: deviceInfoJson.buildNumber || '255050434',
        performanceClass: deviceInfoJson.performanceClass || 'medium'
      };
    } else {
      // Fallback to individual fields if device_info JSON is not available
      return {
        manufacturer: responseData.device_brand || 'Google',
        model: responseData.device_model || 'GF5KQ',
        deviceId: responseData.device_id || '999269724633774',
        androidVersion: responseData.android_version || '12',
        apiLevel: '31',
        buildId: 'SP1A.210812.016',
        fingerprint: 'Google/GF5KQ/GF5KQ:12/SP1A.210812.016/252500124:user/release-keys',
        appVersion: '25.50.5',
        buildNumber: '255050434',
        performanceClass: 'medium'
      };
    }
  } catch (error) {
    console.error('Device info parse hatası:', error);
    // Return default device info if parsing fails
    return generateDeviceIdentifiers();
  }
}

// Update device info from token response
async function updateDeviceInfoFromResponse(responseData, tabId) {
  try {
    const newDeviceInfo = parseDeviceInfoFromResponse(responseData);
    deviceInfo = newDeviceInfo;

    // Store in local storage
    await chrome.storage.local.set({ 'deviceInfo': deviceInfo });

    console.log("Token'dan alınan cihaz bilgileri ayarlandı:", deviceInfo);
    if (tabId) {
      await sendLogMessage(`Cihaz bilgileri güncellendi: ${deviceInfo.manufacturer} ${deviceInfo.model}`, "info", tabId);
    }

    return deviceInfo;
  } catch (error) {
    console.error('Device info güncelleme hatası:', error);
    if (tabId) {
      await sendLogMessage("Cihaz bilgilerini güncelleme hatası: " + error.message, "warning", tabId);
    }
    return deviceInfo || generateDeviceIdentifiers();
  }
}

// Load device info from storage when extension starts
chrome.storage.local.get('deviceInfo', function (result) {
  if (result.deviceInfo) {
    deviceInfo = result.deviceInfo;
  } else {
    // Create new device info if not found in storage
    deviceInfo = generateDeviceIdentifiers();
    chrome.storage.local.set({ 'deviceInfo': deviceInfo });
  }
});

const targetSites = [
  { site: 'tr.fd-api.com', endpoint: '/api/v5/cart/calculate' }
]; // Hedef siteleri ve endpointleri buraya ekleyin
const customUserAgent = 'Android-app-25.50.5(255050434)'; // İstediğiniz User-Agent'ı buraya yazın

function setAuthorizationHeader() {
  return new Promise((resolve, reject) => {
    chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'access_token' }, function (accessToken) {
      const token = accessToken?.value;
      if (token) {
        const updatePromises = [
          RequestHeaderManager.updateDynamicRules({
            addRules: [{
              "id": 3333,
              "priority": 1,
              "action": {
                "type": "modifyHeaders",
                "requestHeaders": [
                  { "header": "Authorization", "operation": "set", "value": `Bearer ${token}` }
                ]
              },
              "condition": {
                "urlFilter": "|https://tr.fd-api.com/api/v6/incentives-wallet/vouchers*",
                "resourceTypes": ["xmlhttprequest"]
              }
            }]
          }),
          RequestHeaderManager.updateDynamicRules({
            addRules: [{
              "id": 4444,
              "priority": 1,
              "action": {
                "type": "modifyHeaders",
                "requestHeaders": [
                  { "header": "Authorization", "operation": "set", "value": `Bearer ${token}` }
                ]
              },
              "condition": {
                "urlFilter": "|https://tr.fd-api.com/api/v5/cart/calculate*",
                "resourceTypes": ["xmlhttprequest"]
              }
            }]
          }),
          RequestHeaderManager.updateDynamicRules({
            addRules: [{
              "id": 5555,
              "priority": 1,
              "action": {
                "type": "modifyHeaders",
                "requestHeaders": [
                  { "header": "Authorization", "operation": "set", "value": `Bearer ${token}` }
                ]
              },
              "condition": {
                "urlFilter": "|https://tr.fd-api.com/api/v5/cart/checkout",
                "resourceTypes": ["xmlhttprequest"]
              }
            }]
          })
        ];

        Promise.all(updatePromises)
          .then(() => {
            // console.log('Authorization header rules updated successfully');
            resolve();
          })
          .catch((error) => {
            console.error('Error updating authorization header rules:', error);
            reject(error);
          });
      } else {
        // No access token found
        reject(new Error('Access token not found'));
      }
    });
  });
}

// JWT decode için basit fonksiyon
function jwtDecode(token) {
  if (!token || token === "null") return null;
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const payload = atob(parts[1]);
    return JSON.parse(payload);
  } catch (error) {
    console.error('JWT decode hatası:', error);
    return null;
  }
}

// JWT token'dan user_id çıkar
function getUserIdFromToken(token) {
  try {
    if (!token || token === "null") return "";
    const decoded = jwtDecode(token);
    return decoded?.user_id || "";
  } catch (error) {
    return "";
  }
}

// Rastgele Eks değeri üret
function generateRandomEks() {
  const a = ["abc", "aaa", "cvc", "cbc", "csc", "asd", "amg", "aq3", "mnp", "gig"];
  const b = ["abc", "aaa", "cvc", "cbc", "csc", "asd", "amg", "aq3", "mnp", "gig"];
  return a[Math.floor(Math.random() * a.length)] + b[Math.floor(Math.random() * b.length)];
}

function updateRules() {
  console.log('🔧 updateRules() fonksiyonu başlatıldı');
  return new Promise(async (resolve, reject) => {
    try {
      const rules = [];
      let ruleId = 1;

      console.log('📝 Kurallar oluşturuluyor...');
      
      // Get consistent device info
      const device = getOrCreateDeviceInfo();

    // Access token'ı al
    console.log('🍪 Access token alınıyor...');
    const accessTokenCookie = await new Promise(resolve => {
      chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'access_token' }, resolve);
    });
    const accessToken = accessTokenCookie?.value || access_token_global || "";
    console.log('✅ Access token alındı:', accessToken ? 'Var' : 'Yok');

    // Cust-Code (user_id) çıkar
    console.log('👤 User ID çıkarılıyor...');
    const custCode = getUserIdFromToken(accessToken);
    console.log('✅ User ID:', custCode || 'Yok');

    // Rastgele Eks değeri
    const eksValue = generateRandomEks();

    // Adjust Ad ID
    const adjustAdId = generateRandomHex(32);

    // Widevine ID (cihaz ID'sine benzer)
    const widevineId = device.deviceId || generateRandomHex(16);

    console.log('🔄 targetSites döngüsü başlıyor, site sayısı:', targetSites.length);
    targetSites.forEach(({ site, endpoint }) => {
      const urlFilter = `|https://${site}${endpoint}`;

      rules.push({
        "id": ruleId++,
        "priority": 1,
        "action": {
          "type": "redirect",
          "redirect": {
            "transform": {
              "queryTransform": {
                "addOrReplaceParams": [{ "key": "platform", "value": "android_native_app" }]
              }
            }
          }
        },
        "condition": {
          "urlFilter": "|https://tr.fd-api.com/api/v6/incentives-wallet/vouchers",
          "resourceTypes": ["xmlhttprequest"]
        }
      });

      rules.push({
        "id": ruleId++,
        "priority": 1,
        "action": {
          "type": "modifyHeaders",
          "requestHeaders": [
            // Tüm web başlıklarını kaldır
            { "header": "sec-ch-ua", "operation": "remove" },
            { "header": "sec-ch-ua-mobile", "operation": "remove" },
            { "header": "sec-ch-ua-platform", "operation": "remove" },
            { "header": "sec-fetch-dest", "operation": "remove" },
            { "header": "sec-fetch-mode", "operation": "remove" },
            { "header": "sec-fetch-site", "operation": "remove" },
            { "header": "sec-ch-ua-arch", "operation": "remove" },
            { "header": "sec-ch-ua-bitness", "operation": "remove" },
            { "header": "sec-ch-ua-full-version", "operation": "remove" },
            { "header": "sec-ch-ua-full-version-list", "operation": "remove" },
            { "header": "sec-ch-ua-model", "operation": "remove" },
            { "header": "sec-ch-ua-wow64", "operation": "remove" },
            { "header": "sec-ch-ua-platform-version", "operation": "remove" },
            { "header": "sec-ch-ua-ua", "operation": "remove" },
            { "header": "sec-ch-ua-form-factor", "operation": "remove" },
            { "header": "sec-ch-ua-viewport-width", "operation": "remove" },
            { "header": "sec-ch-ua-dpr", "operation": "remove" },
            { "header": "sec-ch-ua-resolution", "operation": "remove" },
            { "header": "sec-fetch-user", "operation": "remove" },
            { "header": "sec-fetch-storage-access", "operation": "remove" },
            { "header": "priority", "operation": "remove" },
            { "header": "referer", "operation": "remove" },
            { "header": "x-requested-with", "operation": "remove" },
            { "header": "x-caller-platform", "operation": "remove" },
            { "header": "perseus-session-id", "operation": "remove" },
            { "header": "perseus-client-id", "operation": "remove" },
            { "header": "dps-session-id", "operation": "remove" },
            { "header": "Origin", "operation": "remove" },
            { "header": "Sec-Fetch-Storage-Access", "operation": "remove" },
            { "header": "Sec-Fetch-User", "operation": "remove" },
            { "header": "Sec-Fetch-Dest", "operation": "remove" },

            // Yeni header'ları ayarla
            // NOT: oauth2/token endpoint'inde background.js'deki loginAccountMobile fonksiyonu R-Sig üretiyor
            { "header": "Host", "operation": "set", "value": "tr.fd-api.com" },
            { "header": "X-Pd-Language-Id", "operation": "set", "value": "2" },
            { "header": "Api-Client-Version", "operation": "set", "value": "5.0" },
            { "header": "Device-Make", "operation": "set", "value": device.manufacturer },
            { "header": "Device-Model", "operation": "set", "value": device.model },
            { "header": "Device-Id", "operation": "set", "value": device.deviceId },
            { "header": "App-Name", "operation": "set", "value": "com.inovel.app.yemeksepeti" },
            { "header": "App-Flavor", "operation": "set", "value": "yemeksepeti" },
            { "header": "Build-Type", "operation": "set", "value": "release" },
            { "header": "Platform", "operation": "set", "value": "android" },
            { "header": "Platform-Version", "operation": "set", "value": device.apiLevel || "34" },
            { "header": "Android-Mobile-Service-Provider", "operation": "set", "value": "gms" },
            { "header": "Build-Number", "operation": "set", "value": "255050434" },
            { "header": "App-Build", "operation": "set", "value": "255050434" },
            { "header": "App-Version", "operation": "set", "value": "25.50.5" },
            // Eks, Cust-Code kaldırıldı - background.js loginAccountMobile fonksiyonunda dinamik olarak ekleniyor
            { "header": "Widevine-Id", "operation": "set", "value": widevineId },
            { "header": "Sentry-Trace", "operation": "set", "value": "00000000000000000000000000000000-0000000000000000-0" },
            { "header": "Em-Request-Identifier", "operation": "set", "value": generateUUID() },
            { "header": "X-Px-Bypass-Reason", "operation": "set", "value": "Invalid SDK initialization" },
            { "header": "X-Px-Authorization", "operation": "set", "value": "4" },
            { "header": "Adjust-Ad-Id", "operation": "set", "value": adjustAdId },
            { "header": "X-Fp-Api-Key", "operation": "set", "value": "android" },
            { "header": "User-Agent", "operation": "set", "value": customUserAgent },
            { "header": "Accept-Encoding", "operation": "set", "value": "gzip, deflate, br" }
          ]
        },
        "condition": {
          "urlFilter": "|https://tr.fd-api.com/api/v5/oauth2/token",
          "requestMethods": ["post"]
        }
      });

      rules.push({
        "id": ruleId++,
        "priority": 1,
        "action": {
          "type": "modifyHeaders",
          "requestHeaders": [
            // Tüm web başlıklarını kaldır
            { "header": "sec-ch-ua", "operation": "remove" },
            { "header": "sec-ch-ua-mobile", "operation": "remove" },
            { "header": "sec-ch-ua-platform", "operation": "remove" },
            { "header": "sec-fetch-dest", "operation": "remove" },
            { "header": "sec-fetch-mode", "operation": "remove" },
            { "header": "sec-fetch-site", "operation": "remove" },
            { "header": "sec-ch-ua-arch", "operation": "remove" },
            { "header": "sec-ch-ua-bitness", "operation": "remove" },
            { "header": "sec-ch-ua-full-version", "operation": "remove" },
            { "header": "sec-ch-ua-full-version-list", "operation": "remove" },
            { "header": "sec-ch-ua-model", "operation": "remove" },
            { "header": "sec-ch-ua-wow64", "operation": "remove" },
            { "header": "sec-ch-ua-platform-version", "operation": "remove" },
            { "header": "sec-ch-ua-ua", "operation": "remove" },
            { "header": "sec-ch-ua-form-factor", "operation": "remove" },
            { "header": "sec-ch-ua-viewport-width", "operation": "remove" },
            { "header": "sec-ch-ua-dpr", "operation": "remove" },
            { "header": "sec-ch-ua-resolution", "operation": "remove" },
            { "header": "sec-fetch-user", "operation": "remove" },
            { "header": "sec-fetch-storage-access", "operation": "remove" },
            { "header": "priority", "operation": "remove" },
            { "header": "referer", "operation": "remove" },
            { "header": "x-requested-with", "operation": "remove" },
            { "header": "x-caller-platform", "operation": "remove" },
            { "header": "perseus-session-id", "operation": "remove" },
            { "header": "perseus-client-id", "operation": "remove" },
            { "header": "dps-session-id", "operation": "remove" },
            { "header": "Origin", "operation": "remove" },
            { "header": "Sec-Fetch-Storage-Access", "operation": "remove" },
            { "header": "Sec-Fetch-User", "operation": "remove" },
            { "header": "Sec-Fetch-Dest", "operation": "remove" },

            // Yeni header'ları ayarla
            // NOT: Eks, Cust-Code, R-Sig, Rts, Ruid header'ları interceptor tarafından dinamik olarak ekleniyor
            { "header": "Host", "operation": "set", "value": "tr.fd-api.com" },
            { "header": "X-Pd-Language-Id", "operation": "set", "value": "2" },
            { "header": "X-Reorder-Origin", "operation": "set", "value": "" },
            { "header": "Api-Client-Version", "operation": "set", "value": "5.0" },
            { "header": "Device-Make", "operation": "set", "value": device.manufacturer },
            { "header": "Device-Model", "operation": "set", "value": device.model },
            { "header": "Device-Id", "operation": "set", "value": device.deviceId },
            { "header": "App-Name", "operation": "set", "value": "com.inovel.app.yemeksepeti" },
            { "header": "App-Flavor", "operation": "set", "value": "yemeksepeti" },
            { "header": "Build-Type", "operation": "set", "value": "release" },
            { "header": "Platform", "operation": "set", "value": "android" },
            { "header": "Platform-Version", "operation": "set", "value": device.apiLevel || "34" },
            { "header": "Android-Mobile-Service-Provider", "operation": "set", "value": "gms" },
            { "header": "Build-Number", "operation": "set", "value": "255050434" },
            { "header": "App-Build", "operation": "set", "value": "255050434" },
            { "header": "App-Version", "operation": "set", "value": "25.50.5" },
            // Eks, Cust-Code kaldırıldı - interceptor tarafından dinamik olarak ekleniyor
            { "header": "Widevine-Id", "operation": "set", "value": widevineId },
            { "header": "Sentry-Trace", "operation": "set", "value": "00000000000000000000000000000000-0000000000000000-0" },
            { "header": "Em-Request-Identifier", "operation": "set", "value": generateUUID() },
            { "header": "X-Px-Bypass-Reason", "operation": "set", "value": "Invalid SDK initialization" },
            { "header": "X-Px-Authorization", "operation": "set", "value": "4" },
            { "header": "Adjust-Ad-Id", "operation": "set", "value": adjustAdId },
            { "header": "X-Fp-Api-Key", "operation": "set", "value": "android" },
            { "header": "User-Agent", "operation": "set", "value": customUserAgent },
            { "header": "Accept-Encoding", "operation": "set", "value": "gzip, deflate, br" }
          ]
        },
        "condition": {
          "urlFilter": "|https://tr.fd-api.com/api/v5/cart/checkout",
          "requestMethods": ["post"]
        }
      });

      rules.push({
        "id": ruleId++,
        "priority": 1,
        "action": {
          "type": "modifyHeaders",
          "requestHeaders": [
            // Tüm web başlıklarını kaldır
            { "header": "sec-ch-ua", "operation": "remove" },
            { "header": "sec-ch-ua-mobile", "operation": "remove" },
            { "header": "sec-ch-ua-platform", "operation": "remove" },
            { "header": "sec-fetch-dest", "operation": "remove" },
            { "header": "sec-fetch-mode", "operation": "remove" },
            { "header": "sec-fetch-site", "operation": "remove" },
            { "header": "sec-ch-ua-arch", "operation": "remove" },
            { "header": "sec-ch-ua-bitness", "operation": "remove" },
            { "header": "sec-ch-ua-full-version", "operation": "remove" },
            { "header": "sec-ch-ua-full-version-list", "operation": "remove" },
            { "header": "sec-ch-ua-model", "operation": "remove" },
            { "header": "sec-ch-ua-wow64", "operation": "remove" },
            { "header": "sec-ch-ua-platform-version", "operation": "remove" },
            { "header": "sec-ch-ua-ua", "operation": "remove" },
            { "header": "sec-ch-ua-form-factor", "operation": "remove" },
            { "header": "sec-ch-ua-viewport-width", "operation": "remove" },
            { "header": "sec-ch-ua-dpr", "operation": "remove" },
            { "header": "sec-ch-ua-resolution", "operation": "remove" },
            { "header": "sec-fetch-user", "operation": "remove" },
            { "header": "sec-fetch-storage-access", "operation": "remove" },
            { "header": "priority", "operation": "remove" },
            { "header": "referer", "operation": "remove" },
            { "header": "x-requested-with", "operation": "remove" },
            { "header": "x-caller-platform", "operation": "remove" },
            { "header": "perseus-session-id", "operation": "remove" },
            { "header": "perseus-client-id", "operation": "remove" },
            { "header": "dps-session-id", "operation": "remove" },
            { "header": "Sec-Fetch-Storage-Access", "operation": "remove" },
            { "header": "Sec-Fetch-User", "operation": "remove" },
            { "header": "Sec-Fetch-Dest", "operation": "remove" },

            // Yeni header'ları ayarla
            // NOT: Eks, Cust-Code, R-Sig, Rts, Ruid header'ları interceptor tarafından dinamik olarak ekleniyor
            { "header": "Host", "operation": "set", "value": "tr.fd-api.com" },
            { "header": "X-Pd-Language-Id", "operation": "set", "value": "2" },
            { "header": "X-Reorder-Origin", "operation": "set", "value": "" },
            { "header": "Api-Client-Version", "operation": "set", "value": "5.0" },
            { "header": "Device-Make", "operation": "set", "value": device.manufacturer },
            { "header": "Device-Model", "operation": "set", "value": device.model },
            { "header": "Device-Id", "operation": "set", "value": device.deviceId },
            { "header": "App-Name", "operation": "set", "value": "com.inovel.app.yemeksepeti" },
            { "header": "App-Flavor", "operation": "set", "value": "yemeksepeti" },
            { "header": "Build-Type", "operation": "set", "value": "release" },
            { "header": "Platform", "operation": "set", "value": "android" },
            { "header": "Platform-Version", "operation": "set", "value": device.apiLevel || "34" },
            { "header": "Android-Mobile-Service-Provider", "operation": "set", "value": "gms" },
            { "header": "Build-Number", "operation": "set", "value": "255050434" },
            { "header": "App-Build", "operation": "set", "value": "255050434" },
            { "header": "App-Version", "operation": "set", "value": "25.50.5" },
            // Eks, Cust-Code kaldırıldı - interceptor tarafından dinamik olarak ekleniyor
            { "header": "Widevine-Id", "operation": "set", "value": widevineId },
            { "header": "Sentry-Trace", "operation": "set", "value": "00000000000000000000000000000000-0000000000000000-0" },
            { "header": "Em-Request-Identifier", "operation": "set", "value": generateUUID() },
            { "header": "X-Px-Bypass-Reason", "operation": "set", "value": "Invalid SDK initialization" },
            { "header": "X-Px-Authorization", "operation": "set", "value": "4" },
            { "header": "Adjust-Ad-Id", "operation": "set", "value": adjustAdId },
            { "header": "X-Fp-Api-Key", "operation": "set", "value": "android" },
            { "header": "User-Agent", "operation": "set", "value": customUserAgent },
            { "header": "Accept-Encoding", "operation": "set", "value": "gzip, deflate, br" }
          ]
        },
        "condition": {
          "urlFilter": "|https://tr.fd-api.com/api/v5/purchase/intent",
          "requestMethods": ["post", "put", "get"]
        }
      });

      rules.push({
        "id": ruleId++,
        "priority": 1,
        "action": {
          "type": "modifyHeaders",
          "requestHeaders": [
            // Tüm web başlıklarını kaldır
            { "header": "sec-ch-ua", "operation": "remove" },
            { "header": "sec-ch-ua-mobile", "operation": "remove" },
            { "header": "sec-ch-ua-platform", "operation": "remove" },
            { "header": "sec-fetch-dest", "operation": "remove" },
            { "header": "sec-fetch-mode", "operation": "remove" },
            { "header": "sec-fetch-site", "operation": "remove" },
            { "header": "sec-ch-ua-arch", "operation": "remove" },
            { "header": "sec-ch-ua-bitness", "operation": "remove" },
            { "header": "sec-ch-ua-full-version", "operation": "remove" },
            { "header": "sec-ch-ua-full-version-list", "operation": "remove" },
            { "header": "sec-ch-ua-model", "operation": "remove" },
            { "header": "sec-ch-ua-wow64", "operation": "remove" },
            { "header": "sec-ch-ua-platform-version", "operation": "remove" },
            { "header": "sec-ch-ua-ua", "operation": "remove" },
            { "header": "sec-ch-ua-form-factor", "operation": "remove" },
            { "header": "sec-ch-ua-viewport-width", "operation": "remove" },
            { "header": "sec-ch-ua-dpr", "operation": "remove" },
            { "header": "sec-ch-ua-resolution", "operation": "remove" },
            { "header": "sec-fetch-user", "operation": "remove" },
            { "header": "sec-fetch-storage-access", "operation": "remove" },
            { "header": "priority", "operation": "remove" },
            { "header": "referer", "operation": "remove" },
            { "header": "x-requested-with", "operation": "remove" },
            { "header": "x-caller-platform", "operation": "remove" },
            { "header": "perseus-session-id", "operation": "remove" },
            { "header": "perseus-client-id", "operation": "remove" },
            { "header": "dps-session-id", "operation": "remove" },
            { "header": "Sec-Fetch-Storage-Access", "operation": "remove" },
            { "header": "Sec-Fetch-User", "operation": "remove" },
            { "header": "Sec-Fetch-Dest", "operation": "remove" },

            // Yeni header'ları ayarla
            // NOT: Eks, Cust-Code, R-Sig, Rts, Ruid header'ları interceptor tarafından dinamik olarak ekleniyor
            { "header": "Host", "operation": "set", "value": "tr.fd-api.com" },
            { "header": "X-Pd-Language-Id", "operation": "set", "value": "2" },
            { "header": "X-Reorder-Origin", "operation": "set", "value": "" },
            { "header": "Api-Client-Version", "operation": "set", "value": "5.0" },
            { "header": "Device-Make", "operation": "set", "value": device.manufacturer },
            { "header": "Device-Model", "operation": "set", "value": device.model },
            { "header": "Device-Id", "operation": "set", "value": device.deviceId },
            { "header": "App-Name", "operation": "set", "value": "com.inovel.app.yemeksepeti" },
            { "header": "App-Flavor", "operation": "set", "value": "yemeksepeti" },
            { "header": "Build-Type", "operation": "set", "value": "release" },
            { "header": "Platform", "operation": "set", "value": "android" },
            { "header": "Platform-Version", "operation": "set", "value": device.apiLevel || "34" },
            { "header": "Android-Mobile-Service-Provider", "operation": "set", "value": "gms" },
            { "header": "Build-Number", "operation": "set", "value": "255050434" },
            { "header": "App-Build", "operation": "set", "value": "255050434" },
            { "header": "App-Version", "operation": "set", "value": "25.50.5" },
            // Eks, Cust-Code kaldırıldı - interceptor tarafından dinamik olarak ekleniyor
            { "header": "Widevine-Id", "operation": "set", "value": widevineId },
            { "header": "Sentry-Trace", "operation": "set", "value": "00000000000000000000000000000000-0000000000000000-0" },
            { "header": "Em-Request-Identifier", "operation": "set", "value": generateUUID() },
            { "header": "X-Px-Bypass-Reason", "operation": "set", "value": "Invalid SDK initialization" },
            { "header": "X-Px-Authorization", "operation": "set", "value": "4" },
            { "header": "Adjust-Ad-Id", "operation": "set", "value": adjustAdId },
            { "header": "X-Fp-Api-Key", "operation": "set", "value": "android" },
            { "header": "User-Agent", "operation": "set", "value": customUserAgent },
            { "header": "Accept-Encoding", "operation": "set", "value": "gzip, deflate, br" }
          ]
        },
        "condition": {
          "urlFilter": "|https://tr.fd-api.com/api/v5/cart/calculate",
          "requestMethods": ["post", "get", "options"]
        }
      });
    });
    console.log('✅ targetSites döngüsü tamamlandı, şu ana kadar oluşturulan kural sayısı:', rules.length);

    // Add the new blocking rules
    console.log('🚫 Blocking patterns alınıyor...');
    try {
      const patterns = await getBlockedPatterns();
      console.log('✅ Blocking patterns alındı:', patterns ? patterns.length : 0);
      if (patterns && patterns.length > 0) {
        // Start blocking rules from a high ID to avoid conflicts
        const blockingRules = generateBlockingRules(patterns, 20000);
        rules.push(...blockingRules);
        console.log(`${blockingRules.length} blocking rules generated and added.`);
      }
    } catch (error) {
      console.error("Failed to generate blocking rules:", error);
    }

      console.log(`📊 Toplam ${rules.length} kural oluşturuldu, RequestHeaderManager'a gönderiliyor...`);
      
      await RequestHeaderManager.updateDynamicRules({
        addRules: rules
      });
      
      console.log('✅ Kurallar başarıyla güncellendi.');
      resolve();
    } catch (error) {
      console.error('❌ updateRules hatası:', error);
      reject(error);
    }
  });
}

function generateDynamicHeaders(x_device, bearer_token, headers, content_type_json = false) {
  // Get the consistent device info (now includes token response data)
  const device = getOrCreateDeviceInfo();

  // Use device info from token response if available, otherwise use defaults
  const appVersions = [device.appVersion || '25.50.5'];
  const buildNumbers = [device.buildNumber || '255050434'];
  const platformVersions = [device.apiLevel || '34'];

  // Cust-Code (user_id) çıkar - x_device veya bearer_token'dan
  const custCode = getUserIdFromToken(x_device) || getUserIdFromToken(bearer_token) || "";

  // Rastgele Eks değeri
  const eksValue = generateRandomEks();

  // Adjust Ad ID
  const adjustAdId = generateRandomHex(32);

  // Widevine ID
  const widevineId = device.deviceId || generateRandomHex(16);

  const randomChoice = (arr) => arr[Math.floor(Math.random() * arr.length)];

  let dynamicValues = {
    '{xDevice}': x_device,
    '{deviceMake}': device.manufacturer || "realme",
    '{deviceModel}': device.model || "RMX3085",
    '{deviceId}': device.deviceId,
    '{appVersion}': randomChoice(appVersions),
    '{buildNumber}': randomChoice(buildNumbers),
    '{platformVersion}': randomChoice(platformVersions),
    '{sentryTrace}': "00000000000000000000000000000000-0000000000000000-0",
    '{baggage}': `sentry-environment=production,sentry-public_key=${makeid(16)},sentry-release=com.inovel.app.yemeksepeti%40${randomChoice(appVersions)}%2B${randomChoice(buildNumbers)},sentry-sampled=false,sentry-trace_id=${makeid(16)},sentry-transaction=sm_UserHomeContainerComposeActivity`,
    '{eks}': eksValue,
    '{custCode}': custCode,
    '{widevineId}': widevineId,
    '{adjustAdId}': adjustAdId,
    '{emRequestIdentifier}': generateUUID(),
    '{performanceClass}': device.performanceClass || randomChoice(['low', 'medium', 'high']),
    '{bearerToken}': bearer_token,
    '{contentType}': content_type_json ? "application/json" : 'application/x-www-form-urlencoded'
  };

  for (let [key, value] of Object.entries(dynamicValues)) {
    headers = headers.replace(new RegExp(key, 'g'), value);
  }

  return JSON.parse(headers);
}

// Tüm kuralları dinamik olarak temizleyen geliştirilmiş fonksiyon
function clearAllRules() {
  return new Promise(async (resolve, reject) => {
    try {
      console.log("Temizleme işlemi başlatılıyor...");

      // İlk olarak tüm dinamik kuralları çek ve temizle
      const dynamicRules = await RequestHeaderManager.getDynamicRules();
      const dynamicRuleIds = dynamicRules.map(rule => rule.id);

      if (dynamicRuleIds.length > 0) {
        console.log(`Temizlenecek ${dynamicRuleIds.length} dinamik kural:`, dynamicRuleIds);

        await RequestHeaderManager.updateDynamicRules({
          removeRuleIds: dynamicRuleIds,
          addRules: []
        });
        console.log("Dinamik kurallar temizlendi");
      } else {
        console.log("Temizlenecek dinamik kural bulunamadı");
      }

      // Sonra tüm oturum kurallarını çek ve temizle
      const sessionRules = await RequestHeaderManager.getSessionRules();
      const sessionRuleIds = sessionRules.map(rule => rule.id);

      if (sessionRuleIds.length > 0) {
        console.log(`Temizlenecek ${sessionRuleIds.length} oturum kuralı:`, sessionRuleIds);

        // Trendyol payment kurallarını da dahil et (güvenlik için ID'leri de ekle)
        const trendyolPaymentRuleIds = [7001, 7002];
        const allRuleIds = [...new Set([...sessionRuleIds, ...trendyolPaymentRuleIds])];

        await RequestHeaderManager.updateSessionRules({
          removeRuleIds: allRuleIds,
          addRules: []
        });
        console.log("Oturum kuralları temizlendi");
      } else {
        console.log("Temizlenecek oturum kuralı bulunamadı");
      }

      console.log("Tüm kurallar başarıyla temizlendi");
      resolve();
    } catch (error) {
      console.error("Kural temizleme hatası:", error);
      // Hata olsa bile devam et
      resolve();
    }
  });
}

async function handleTrendyolLogin(data, token, tabId) {
  try {
    await sendLogMessage("Trendyol giriş işlemi başlatılıyor...", "info", tabId);

    // Token'ı storage'a kaydet (proxy istekleri için)
    await chrome.storage.local.set({ 'tyToken': data.access_token });
    console.log('Trendyol token storage\'a kaydedildi:', token);

    // Önce tüm mevcut kuralları temizle
    await clearAllRules();

    // Trendyol için rastgele cihaz bilgileri oluştur
    try {
      console.log("Trendyol: Rastgele cihaz bilgileri oluşturuluyor...");
      const trendyolDeviceInfo = generateTrendyolDeviceIdentifiers();
      deviceInfo = trendyolDeviceInfo;

      // Local storage'a kaydet
      await chrome.storage.local.set({ 'deviceInfo': deviceInfo });

      console.log("Trendyol: Yeni cihaz bilgileri ayarlandı:", deviceInfo);
      await sendLogMessage("Trendyol cihaz kimliği: " + deviceInfo.manufacturer + " " + deviceInfo.model, "info", tabId);
    } catch (devError) {
      console.error("Trendyol: Cihaz bilgisi oluşturma hatası:", devError);
      await sendLogMessage("Cihaz bilgilerini oluşturma hatası: " + devError.message, "warning", tabId);
    }

    // Önce mevcut Trendyol verilerini temizle
    try {
      await Promise.all([
        clearSiteData("tgoyemek.com"),
        clearSiteData("trendyol.com"),
        clearSiteData("tgoapps.com")
      ]);
      console.log("Trendyol giriş: Site verileri API ile temizlendi");
      await sendLogMessage("Site verileri temizlendi.", "info", tabId);
    } catch (error) {
      console.error("Trendyol browsingData API hatası, manuel temizleme yapılıyor:", error);
      // Fallback: clearTrendyolCookies kullan
      await clearTrendyolCookies();
      await sendLogMessage("Çerezler temizlendi.", "info", tabId);
    }

    // Yeni giriş yöntemini kullan
    await performTrendyolLogin(data, tabId, token);

    // Adres yönetimi - Trendyol tokenleri için
    await manageSavedAddress('ty', tabId);

    // Trendyol sayfasını aç
    chrome.tabs.create({ url: "https://tgoyemek.com" });
    await sendLogMessage("İşlem başarıyla tamamlandı.", "success", tabId);

  } catch (error) {
    await sendLogMessage("Hata: " + error.message, "error", tabId);
    throw error;
  }
}

async function handleYxLogin(data, token, tabId) {
  try {
    await sendLogMessage("YX giriş işlemi başlatılıyor...", "info", tabId);

    // YX giriş işleminde token response'ından gelen cihaz bilgilerini kullan
    try {
      console.log("handleYxLogin: Token'dan cihaz bilgilerini alıyor");
      await updateDeviceInfoFromResponse(data, tabId);
    } catch (devError) {
      console.error("YX giriş: Cihaz bilgisi yenilemede hata:", devError);
      await sendLogMessage("Cihaz bilgilerini güncelleme hatası: " + devError.message, "warning", tabId);
    }

    // Önce mevcut verileri temizle - SADECE YemekSepeti verilerini
    try {
      await Promise.all([
        clearSiteData("www.yemeksepeti.com"),
        clearSiteData("tr.fd-api.com")
      ]);
      console.log("YX giriş: YemekSepeti site verileri API ile temizlendi");
      await sendLogMessage("Site verileri temizlendi.", "info", tabId);
    } catch (error) {
      console.error("YX giriş: browsingData API hatası, manuel temizleme yapılıyor:", error);
      // Fallback: Manuel cookie temizleme
      chrome.cookies.getAll({}, function (all_cookies) {
        var count = all_cookies.length;
        for (var i = 0; i < count; i++) {
          removeCookie(all_cookies[i], 'ys'); // Sadece YS çerezlerini temizle
        }
      });
      await sendLogMessage("Cookieler temizlendi.", "info", tabId);
    }

    // Rules'ları temizle ve yeniden ayarla
    await clearAllRules();
    console.log('🔄 updateRules() çağrılıyor...');
    await updateRules();
    console.log('✅ updateRules() tamamlandı');
    console.log('🔄 updateCookieRule() çağrılıyor...');
    await updateCookieRule();
    console.log('✅ updateCookieRule() tamamlandı');

    console.log('🌐 Ara sunucudan token alınıyor...');
    await sendLogMessage("Ara sunucudan giriş yapılıyor (5 dakikaya kadar sürebilir)...", "info", tabId);
    
    console.log('📡 Fetch başlatılıyor: https://kuppo.net/api/login/token');
    const response = await fetch('https://kuppo.net/api/login/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ token: token })
    });

    const loginData = await response.json();

    if (!loginData.status || !loginData.data.access_token) {
      throw new Error(loginData.message || "Ara sunucudan giriş başarısız!");
    }

    // accessToken her zaman mobil access token olmalı
    const accessToken = loginData.data.access_token;
    let deviceToken, refreshToken;
    let webAccessToken = null;
    let useWebTokens = false;

    if (loginData.web_tokens && loginData.web_tokens.web_access_token) {
      // Web token'ları varsa bunları kullan
      await sendLogMessage("Web token'ları kullanılıyor...", "info", tabId);
      console.log("YX giriş: Web token'ları tespit edildi, bunlar kullanılacak");

      // Web token'ları için
      webAccessToken = loginData.web_tokens.web_access_token;
      deviceToken = loginData.web_tokens.web_device_token;
      refreshToken = loginData.web_tokens.web_refresh_token;
      useWebTokens = true;
    } else {
      // Normal token'ları kullan
      console.log("YX giriş: Normal token'lar kullanılacak");
      deviceToken = data.device_token;
      refreshToken = data.refresh_token;
    }

    await sendLogMessage("Mobil giriş başarılı.", "success", tabId);
    access_token_global = accessToken;

    // Mobil access token'ı her zaman cookie olarak set et
    await chrome.cookies.set({
      url: "https://www.yemeksepeti.com",
      name: "access_token",
      value: accessToken,
      secure: true,
      httpOnly: false
    });

    const expirationDate = Math.floor(Date.now() / 1000) + (59 * 60); // 59 dakika

    if (webAccessToken) {
      // Web token'ları varsa sadece token cookie'sini set et
      await chrome.cookies.set({
        url: "https://www.yemeksepeti.com",
        name: "token",
        value: webAccessToken,
        secure: true,
        httpOnly: false,
        expirationDate: expirationDate
      });

      await sendLogMessage("Web token'ları başarıyla ayarlandı.", "success", tabId);
    } else {
      // Normal akış: device_token ve refresh_token set et
      await chrome.cookies.set({
        url: "https://www.yemeksepeti.com",
        name: "device_token",
        value: deviceToken,
        secure: true,
        httpOnly: false,
        expirationDate: expirationDate
      });

      await chrome.cookies.set({
        url: "https://www.yemeksepeti.com",
        name: "refresh_token",
        value: refreshToken,
        secure: true,
        httpOnly: false,
        expirationDate: expirationDate
      });
    }

    await sendLogMessage("Token'lar ayarlandı.", "info", tabId);

    // Authorization header'ı güncelle
    await setAuthorizationHeader();
    await sendLogMessage("Header'lar güncellendi.", "info", tabId);

    // Adres yönetimi - YX tokenleri için
    await manageSavedAddress('yx', tabId);

    // Yemeksepeti.com'a localStorage temizliği yaparak yönlendirme
    await sendLogMessage("LocalStorage temizlenecek...", "info", tabId);

    // Yemeksepeti'ye localStorage temizliği yaparak yönlendir
    // Ayrıca refresh token kontrolü için bilgileri gönder
    console.log('🚀 YemekSepeti\'ye yönlendirme başlatılıyor...');
    await redirectToYsWithCleanStorage("https://www.yemeksepeti.com", tabId, true, {
      refreshToken: refreshToken,
      token: token
    });
    console.log('✅ YemekSepeti yönlendirmesi tamamlandı');

    await sendLogMessage("İşlem başarıyla tamamlandı.", "success", tabId);
  } catch (error) {
    await sendLogMessage("Hata: " + error.message, "error", tabId);
    throw error;
  }
}

async function checkAndUpdateRefreshToken(originalRefreshToken, token) {
  chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'refresh_token' }, async function (cookie) {
    if (cookie && cookie.value !== originalRefreshToken) {
      try {
        await fetch(`https://admin.kuppo.net/updateRefreshToken.php`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: `token=${token}&refresh_token=${cookie.value}`
        });
        chrome.runtime.sendMessage({ action: "updateLog", message: "Refresh token güncellendi.", type: "success" });
      } catch (error) {
        chrome.runtime.sendMessage({ action: "updateLog", message: "Refresh token güncellenirken hata oluştu.", type: "error" });
      }
    }
  });
}

// Log mesajı gönderme yardımcı fonksiyonu
async function sendLogMessage(message, type, tabId) {

  // Tab mesajı göndermeyi dene ama await kullanma
  if (tabId) {
    chrome.tabs.sendMessage(tabId, {
      action: 'updateLog',
      message: message,
      type: type
    }, () => {
      // Callback - hata olsa bile devam et
      if (chrome.runtime.lastError) {
        // Sessizce yoksay
      }
    });
  }
}

// Alert gösterme yardımcı fonksiyonu
async function showAlert(tabId, message) {
  try {
    if (!tabId) {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        tabId = tabs[0].id;
      }
    }
    if (tabId) {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: (msg) => { alert(msg); },
        args: [message]
      });
    }
  } catch (error) {
    console.error('Alert gösterilemedi:', error);
  }
}

// Adres Yönetimi Fonksiyonları
async function manageSavedAddress(tokenType, tabId) {
  console.log('📍 manageSavedAddress başlatıldı, tokenType:', tokenType);
  try {
    const savedAddress = await getSavedAddress();
    console.log('✅ Saved address alındı:', savedAddress ? 'Var' : 'Yok');

    // Trendyol için özel kontrol - adres yoksa giriş yapmayacak
    if (tokenType === 'ty') {
      if (!savedAddress || !savedAddress.autoAddAddress) {
        await sendLogMessage("Trendyol girişi için adres ekleme zorunludur!", "error", tabId);
        throw new Error("Trendyol girişi için adres ekleme etkinleştirilmelidir");
      }
      // Trendyol için adres temizleme/ekleme
      return await manageTrendyolAddresses(savedAddress, true, tabId);
    }

    // Adresin olup olmadığına bakılmaksızın, servise göre işlem yapılacak
    // Adres yoksa, sadece mevcut adresleri temizleme işlemi yapılacak
    if (tokenType === 'mg') {
      // Migros için adres temizleme/ekleme
      return await manageMigrosAddresses(savedAddress, savedAddress?.autoAddAddress || false, tabId);
    } else if (tokenType === 'ys' || tokenType === 'yx') {
      // Yemeksepeti için adres temizleme/ekleme
      console.log('🍕 YemekSepeti adres yönetimi başlatılıyor...');
      const result = await manageYemeksepetiAddresses(savedAddress, savedAddress?.autoAddAddress || false, tabId);
      console.log('✅ YemekSepeti adres yönetimi tamamlandı');
      return result;
    }

    console.log('✅ manageSavedAddress tamamlandı (diğer token tipi)');
    return true;
  } catch (error) {
    console.error("❌ manageSavedAddress hatası:", error);
    if (savedAddress && savedAddress.autoAddAddress) {
      await sendLogMessage("Adres yönetimi hatası: " + error.message, "error", tabId);
    }
    console.error("Adres yönetimi hatası:", error);
    return true;
  }
}

// Trendyol adres yönetimi
async function manageTrendyolAddresses(address, shouldAddAddress, tabId) {
  try {
    await sendLogMessage("Trendyol adres yönetimi başlatılıyor...", "info", tabId);

    // Mevcut adresleri listele
    const addresses = await getTrendyolAddresses();

    // Otomatik adres ekleme etkinse ilk adresi güncelle
    if (shouldAddAddress) {
      if (addresses && addresses.length > 0) {
        await sendLogMessage("Mevcut adres güncelleniyor...", "info", tabId);

        // Konum rastgeleleştirme (5 metre çap)
        const randomizedLocation = randomizeLocation(
          parseFloat(address.latitude),
          parseFloat(address.longitude),
          5
        );

        // Rastgeleleştirilmiş konum ile adresi oluştur
        const addressWithRandomLocation = {
          ...address,
          latitude: randomizedLocation.lat,
          longitude: randomizedLocation.lng
        };

        // İlk adresin ID'sini kullanarak güncelle
        await updateTrendyolAddress(addresses[0].id, addressWithRandomLocation, tabId);
        await sendLogMessage("Adres başarıyla güncellendi", "success", tabId);
      } else {
        await sendLogMessage("Güncellenecek adres bulunamadı", "warning", tabId);
      }
    }

    await sendLogMessage("Trendyol adres yönetimi tamamlandı", "success", tabId);
    return true;
  } catch (error) {
    await sendLogMessage("Trendyol adres hatası: " + error.message, "error", tabId);
    console.error("Trendyol adres hatası:", error);
    return false;
  }
}

// Migros adres yönetimi
async function manageMigrosAddresses(address, shouldAddAddress, tabId) {
  try {
    if (shouldAddAddress) {
      await sendLogMessage("MG adres yönetimi başlatılıyor...", "info", tabId);
    }

    // Migros servislerini tanımla (3 farklı servis için)
    const services = [
      "delivery-bff"
    ];

    // Her servis için adres işlemlerini gerçekleştir
    for (const service of services) {

      // Mevcut adresleri listele
      const addresses = await getMigrosAddresses(service);

      // Her mevcut adresi sil
      if (addresses && addresses.length > 0) {
        if (shouldAddAddress) {
          await sendLogMessage(`${addresses.length} adres siliniyor...`, "info", tabId);
        }
        for (const address of addresses) {
          await deleteMigrosAddress(address.addressInfo.id, service, tabId);
          await sleep(1000);
        }
      }

      // Otomatik adres ekleme etkinse yeni adresi ekle
      if (shouldAddAddress) {
        await sendLogMessage(`Yeni adres ekleniyor [${service}]...`, "info", tabId);
        await createMigrosAddress(address, service, tabId);
      }
    }

    // Son kullanılan servisi kullan - hata düzeltmesi
    await getMigrosAddresses("delivery-bff");

    if (shouldAddAddress) {
      await sendLogMessage("MG adres yönetimi tamamlandı", "success", tabId);
    }
    return true;
  } catch (error) {
    if (shouldAddAddress) {
      await sendLogMessage("MG adres hatası: " + error.message, "error", tabId);
    }
    console.error("MG adres hatası:", error);
    return false;
  }
}

// Yemeksepeti adres yönetimi
async function manageYemeksepetiAddresses(address, shouldAddAddress, tabId) {
  console.log('🍕 manageYemeksepetiAddresses çağrıldı, shouldAddAddress:', shouldAddAddress);
  try {
    if (shouldAddAddress) {
      console.log('📍 Adres ekleme aktif, işlem başlatılıyor...');
      await sendLogMessage("Yemeksepeti adres yönetimi başlatılıyor...", "info", tabId);
    }

    // Mevcut adresleri listele
    const addresses = await getYemeksepetiAddresses();

    // Her mevcut adresi sil
    if (addresses && addresses.length > 0) {
      if (shouldAddAddress) {
        await sendLogMessage(`${addresses.length} adres siliniyor...`, "info", tabId);
      }
      for (const address of addresses) {
        await deleteYemeksepetiAddress(address.id, tabId);
      }
      if (shouldAddAddress) {
        await sendLogMessage(`${addresses.length} adres silindi`, "info", tabId);
      }
    }

    // Otomatik adres ekleme etkinse yeni adresi ekle
    if (shouldAddAddress) {
      console.log('➕ Yeni adres ekleniyor...');
      await sendLogMessage("Yeni adres ekleniyor...", "info", tabId);
      await createYemeksepetiAddress(address, tabId);
      await sendLogMessage("Adres başarıyla eklendi", "success", tabId);
      await sendLogMessage("Yemeksepeti adres yönetimi tamamlandı", "success", tabId);
    } else {
      console.log('⏭️ Adres ekleme kapalı, atlıyor...');
    }

    console.log('✅ manageYemeksepetiAddresses tamamlandı');
    return true;
  } catch (error) {
    console.error('❌ manageYemeksepetiAddresses hatası:', error);
    if (shouldAddAddress) {
      await sendLogMessage("Yemeksepeti adres hatası: " + error.message, "error", tabId);
    }
    console.error("Yemeksepeti adres hatası:", error);
    return false;
  }
}

// LocalStorage'dan kayıtlı adresi al
async function getSavedAddress() {
  console.log('📦 getSavedAddress çağrıldı');
  try {
    // chrome.storage.local.get'i await ile kullan
    const data = await chrome.storage.local.get('savedAddress');
    console.log('✅ chrome.storage.local.get tamamlandı, data:', data);
    
    if (data && data.savedAddress) {
      try {
        const activeAddress = JSON.parse(data.savedAddress);
        console.log('✅ Adres parse edildi:', activeAddress);
        // Eğer ID varsa bu yeni format bir adrestir
        if (activeAddress.id) {
          return activeAddress;
        } else {
          // Eski format adres, ancak kullanılabilir
          return activeAddress;
        }
      } catch (e) {
        console.error('❌ Adres parse hatası:', e);
        return await getAddressFromAddressList();
      }
    } else {
      console.log('⚠️ savedAddress bulunamadı, adres listesinden alınıyor...');
      // savedAddress yoksa adres listesinden ilk adresi almayı dene
      return await getAddressFromAddressList();
    }
  } catch (error) {
    console.error('❌ getSavedAddress hatası:', error);
    return null;
  }
}

// Storage'dan adres listesini al
async function getAddressListFromStorage() {
  try {
    // Önce sync storage'dan dene
    const syncData = await chrome.storage.sync.get('addressList');
    if (syncData && syncData.addressList) {
      try {
        const addresses = JSON.parse(syncData.addressList);
        if (Array.isArray(addresses) && addresses.length > 0) {
          return addresses;
        }
      } catch (e) {
        console.error('Sync adres listesi parse hatası:', e);
      }
    }

    // Sync'te yoksa local'den dene
    const localData = await chrome.storage.local.get('addressList');
    if (localData && localData.addressList) {
      try {
        const addresses = JSON.parse(localData.addressList);
        if (Array.isArray(addresses) && addresses.length > 0) {
          return addresses;
        }
      } catch (e) {
        console.error('Local adres listesi parse hatası:', e);
      }
    }

    return [];
  } catch (error) {
    console.error('getAddressListFromStorage hatası:', error);
    return [];
  }
}

// Adres listesinden otomatik ekleme özelliği açık olan ilk adresi veya ilk adresi al
async function getAddressFromAddressList() {
  console.log('📋 getAddressFromAddressList çağrıldı');
  try {
    // Önce sync storage'dan adres listesini almayı dene
    const syncData = await chrome.storage.sync.get('addressList');
    console.log('✅ chrome.storage.sync.get tamamlandı, syncData:', syncData);
    
    if (syncData && syncData.addressList) {
      try {
        const addresses = JSON.parse(syncData.addressList);
        console.log('✅ Sync adres listesi parse edildi, adres sayısı:', addresses.length);
        if (Array.isArray(addresses) && addresses.length > 0) {
          // Önce otomatik ekleme özelliği açık olan bir adres ara
          const autoAddress = addresses.find(addr => addr.autoAddAddress === true);
          if (autoAddress) {
            console.log('✅ Auto-add adresi bulundu');
            return autoAddress;
          }
          // Yoksa ilk adresi döndür
          console.log('✅ İlk adres döndürülüyor');
          return addresses[0];
        }
      } catch (e) {
        console.error('❌ Sync adres listesi parse hatası:', e);
      }
    }

    // Sync'te yoksa local'den dene
    console.log('⚠️ Sync\'te adres bulunamadı, local\'e bakılıyor...');
    const localData = await chrome.storage.local.get('addressList');
    console.log('✅ chrome.storage.local.get tamamlandı, localData:', localData);
    
    if (localData && localData.addressList) {
      try {
        const addresses = JSON.parse(localData.addressList);
        console.log('✅ Local adres listesi parse edildi, adres sayısı:', addresses.length);
        if (Array.isArray(addresses) && addresses.length > 0) {
          // Önce otomatik ekleme özelliği açık olan bir adres ara
          const autoAddress = addresses.find(addr => addr.autoAddAddress === true);
          if (autoAddress) {
            console.log('✅ Auto-add adresi bulundu (local)');
            return autoAddress;
          }
          // Yoksa ilk adresi döndür
          console.log('✅ İlk adres döndürülüyor (local)');
          return addresses[0];
        }
      } catch (e) {
        console.error('❌ Local adres listesi parse hatası:', e);
      }
    }
    
    // Hiçbir yerde adres bulunamadı
    console.log('⚠️ Hiçbir yerde adres bulunamadı');
    return null;
  } catch (error) {
    console.error('❌ getAddressFromAddressList hatası:', error);
    return null;
  }
}

// Migros adresleri listeleme
async function getMigrosAddresses(service) {
  try {
    // Cihaz bilgilerini al
    const device = getOrCreateDeviceInfo();

    // Tarayıcının kendi User-Agent'ını kullan
    const browserUserAgent = navigator.userAgent;

    // Ödeme sayfası API'si için kontrol
    const isPaymentRequest = service.includes('credit-card') || service.includes('purchase/online');

    // Mobil API başlıklarını ayarla - ödeme sayfası değilse
    const headers = isPaymentRequest ? {
      'Accept-Language': 'tr-TR',
      'User-Agent': browserUserAgent // Tarayıcının gerçek User-Agent'ı
    } : {
      'X-Device-Platform': 'ANDROID',
      'X-Device-Platform-Version': '9',
      'X-Device-Type': 'MOBILE',
      'X-Device-App-Version': '13.5.1',
      'X-Device-Sign': getCurrentDateInFormat(),
      'Accept-Language': 'tr-TR',
      'Accept-Encoding': 'gzip, deflate, br',
      'User-Agent': 'okhttp/5.3.2',
      'X-Device-Identifier': device.deviceId,
      'X-Device-Model': device.model,
    }

    // Get remember-me cookie
    const rememberMeCookie = await new Promise(resolve => {
      chrome.cookies.get({ url: 'https://www.migros.com.tr', name: 'remember-me' }, cookie => {
        resolve(cookie);
      });
    });

    if (rememberMeCookie) {
      // Add remember-me cookie to request header
      headers['Cookie'] = `remember-me=${rememberMeCookie.value}`;
    }

    // Her servis için farklı endpoint kullan
    let endpoint = `/delivery-addresses`;
    if (service === 'delivery-bff/hemen') {
      endpoint = `/hemen/delivery-addresses`;
    } else if (service === 'delivery-bff/yemek') {
      endpoint = `/yemek/delivery-addresses`;
    }

    const response = await fetch(`https://rest.migros.com.tr${endpoint}`, {
      method: 'GET',
      headers: headers
    });

    if (!response.ok) {
      throw new Error(`Migros adresleri alınamadı: ${response.status}`);
    }

    const data = await response.json();
    return data?.data;
  } catch (error) {
    console.error(`Migros adresleri alınamadı (${service}):`, error);
    return [];
  }
}

// Migros adres silme
async function deleteMigrosAddress(addressId, service, tabId) {
  try {
    // Cihaz bilgilerini al
    const device = getOrCreateDeviceInfo();

    // Tarayıcının kendi User-Agent'ını kullan
    const browserUserAgent = navigator.userAgent;

    // Ödeme sayfası API'si için kontrol
    const isPaymentRequest = service.includes('credit-card') || service.includes('purchase/online');

    // Mobil API başlıklarını ayarla - ödeme sayfası değilse
    const headers = isPaymentRequest ? {
      'Accept-Language': 'tr-TR',
      'User-Agent': browserUserAgent // Tarayıcının gerçek User-Agent'ı
    } : {
      'X-Device-Platform': 'ANDROID',
      'X-Device-Platform-Version': '9',
      'X-Device-Type': 'MOBILE',
      'X-Device-App-Version': '13.5.1',
      'X-Device-Sign': getCurrentDateInFormat(),
      'User-Agent': 'okhttp/5.3.2',
      'X-Device-Identifier': device.deviceId,
      'X-Device-Model': device.model,
    };

    // Get remember-me cookie
    const rememberMeCookie = await new Promise(resolve => {
      chrome.cookies.get({ url: 'https://www.migros.com.tr', name: 'remember-me' }, cookie => {
        resolve(cookie);
      });
    });

    if (rememberMeCookie) {
      // Add remember-me cookie to request header
      headers['Cookie'] = `remember-me=${rememberMeCookie.value}`;
    }

    // Her servis için farklı endpoint kullan
    let endpoint = `/v2/addresses/${addressId}`;
    if (service === 'delivery-bff/hemen') {
      endpoint = `/hemen/v2/addresses/${addressId}`;
    } else if (service === 'delivery-bff/yemek') {
      endpoint = `/yemek/v2/addresses/${addressId}`;
    }

    const response = await fetch(`https://rest.migros.com.tr${endpoint}`, {
      method: 'DELETE',
      headers: headers
    });

    if (!response.ok) {
      throw new Error(`Adres silme hatası: ${response.status}`);
    }

    return true;
  } catch (error) {
    console.error(`MG adres silme hatası (${service}, ${addressId}):`, error);
    await sendLogMessage(`Adres silinemedi (${addressId}): ${error.message}`, "warning", tabId);
    return false;
  }
}

// Konum rastgeleleştirme fonksiyonu (metre cinsinden)
function randomizeLocation(lat, lng, radiusMeters) {
  // 1 derece ≈ 111,320 metre
  const earthRadiusKm = 6371;
  const degreeToMeter = 111320;

  // Rastgele açı (0-360 derece)
  const angle = Math.random() * 2 * Math.PI;

  // Rastgele mesafe (0 - radiusMeters)
  const distance = Math.random() * radiusMeters;

  // Delta lat ve lng hesapla
  const deltaLat = (distance * Math.cos(angle)) / degreeToMeter;
  const deltaLng = (distance * Math.sin(angle)) / (degreeToMeter * Math.cos(lat * Math.PI / 180));

  return {
    lat: lat + deltaLat,
    lng: lng + deltaLng
  };
}

// Helper function for inserting random Unicode blank spaces into text
function addRandomBlankSpaces(text, enableRandomSpaces = true) {
  if (!text || !enableRandomSpaces) return text;

  const unicodeBlank = "⠀ "; // Braille pattern blank character
  let spacesAdded = 0;
  const maxSpaces = 2; // Limit random spaces to 2

  // Split by spaces to get individual words
  let words = text.split(' ');

  // If it's a single word/number, maybe add blanks at beginning or end
  if (words.length === 1) {
    const position = Math.floor(Math.random() * 3); // 0: beginning, 1: end, 2: both

    if ((position === 0 || position === 2) && spacesAdded < maxSpaces) {
      words[0] = unicodeBlank + words[0]; // Just one blank at beginning
      spacesAdded++;
    }

    if ((position === 1 || position === 2) && spacesAdded < maxSpaces) {
      words[0] = words[0] + " ⠀"; // Just one blank at end
      spacesAdded++;
    }

    return words[0];
  }

  // For multiple words, replace spaces with blank unicode characters
  let result = "";
  for (let i = 0; i < words.length; i++) {
    result += words[i];

    if (i < words.length - 1) {
      // Add just one blank unicode character between words
      result += unicodeBlank;
    }
  }

  // 30% chance to add a blank at the beginning
  if (Math.random() < 0.3 && spacesAdded < maxSpaces) {
    result = unicodeBlank + result; // Just one blank at beginning
    spacesAdded++;
  }

  // 30% chance to add a blank at the end
  if (Math.random() < 0.3 && spacesAdded < maxSpaces) {
    result = result + " ⠀"; // Just one blank at end
    spacesAdded++;
  }

  return result;
}

// Trendyol için özel boşluk ekleme fonksiyonu (normal boşluk karakterleri)
function addRandomSpacesForTrendyol(text, useRandomSpaces) {
  if (!text || !useRandomSpaces) return text;

  // Normal boşluk karakteri kullan (Unicode boşluk değil)
  const normalSpace = " ";
  let spacesAdded = 0;
  const maxSpaces = 2; // Maksimum 2 boşluk

  // Kelimeleri ayır
  let words = text.split(' ');

  // Tek kelime ise başına veya sonuna boşluk ekle
  if (words.length === 1) {
    const position = Math.floor(Math.random() * 3); // 0: başta, 1: sonda, 2: ikisi de

    if ((position === 0 || position === 2) && spacesAdded < maxSpaces) {
      words[0] = normalSpace + words[0];
      spacesAdded++;
    }

    if ((position === 1 || position === 2) && spacesAdded < maxSpaces) {
      words[0] = words[0] + normalSpace;
      spacesAdded++;
    }

    return words[0];
  }

  // Çoklu kelimeler için aralara boşluk ekle
  let result = "";
  for (let i = 0; i < words.length; i++) {
    result += words[i];

    if (i < words.length - 1) {
      result += normalSpace; // Kelimeler arasına normal boşluk
    }
  }

  // %30 ihtimalle başa boşluk ekle
  if (Math.random() < 0.3 && spacesAdded < maxSpaces) {
    result = normalSpace + result;
    spacesAdded++;
  }

  // %30 ihtimalle sona boşluk ekle
  if (Math.random() < 0.3 && spacesAdded < maxSpaces) {
    result = result + normalSpace;
    spacesAdded++;
  }

  return result;
}

// Migros adres oluşturma
async function createMigrosAddress(address, service, tabId) {
  try {
    // RequestId oluştur
    const requestId = Date.now().toString() + Math.floor(Math.random() * 1000000000).toString();

    // Tarayıcının kendi User-Agent'ını kullan
    const browserUserAgent = navigator.userAgent;

    // Ödeme sayfası API'si için kontrol
    const isPaymentRequest = service.includes('credit-card') || service.includes('purchase/online');

    // For Migros, always disable random spaces as they get stripped by their API
    const useRandomSpaces = false;

    // Process address fields without random spaces for Migros
    const processedNeighborhood = address.neighborhood || "";
    const processedStreet = address.street || "";
    const processedBuilding = address.building || "yok";
    const processedFloor = address.floor || "yok";
    const processedApartment = address.apartment || "yok";

    // Create a real name field for the address description
    const realNameInfo = `Ad Soyad: ${address.fullname || ""}`;

    // Migros API'si için uygun ID'leri kontrol et
    const cityId = parseInt(address.cityId) || 0;
    const townId = parseInt(address.townId) || 0;
    const districtId = parseInt(address.districtId) || 0;

    // ID'lerin doğru formatta olduğundan emin ol
    if (!cityId) {
      console.error("Geçerli şehir ID'si bulunamadı, varsayılan kullanılacak");
      await sendLogMessage("Uyarı: Geçerli şehir ID'si bulunamadı, varsayılan kullanılacak", "warning", tabId);
    }

    if (!townId) {
      console.error("Geçerli ilçe ID'si bulunamadı, varsayılan kullanılacak");
      await sendLogMessage("Uyarı: Geçerli ilçe ID'si bulunamadı, varsayılan kullanılacak", "warning", tabId);
    }

    if (!districtId) {
      console.error("Geçerli mahalle ID'si bulunamadı, varsayılan kullanılacak");
      await sendLogMessage("Uyarı: Geçerli mahalle ID'si bulunamadı, varsayılan kullanılacak", "warning", tabId);
    }

    // Check if clean address mode is enabled
    const useCleanAddress = address.hasOwnProperty('useCleanAddress') ? address.useCleanAddress : false;

    // Adres verisini oluştur - use the IDs from the map data if available
    const addressData = {
      name: address.fullname || "Ev",
      districtId: districtId, // Use the ID from Migros API
      firstName: useCleanAddress ? address.fullname?.split(' ')[0] || "" : address.phone ? `Tel: ${address.phone}` : "",
      lastName: useCleanAddress ? address.fullname?.split(' ').slice(1).join(' ') || "" : "bu numaradan arayın",
      townId: townId, // Use the ID from Migros API
      cityId: cityId, // Use the ID from Migros API
      streetName: processedStreet,
      floorNumber: processedFloor,
      doorNumber: processedApartment,
      buildingNumber: processedBuilding,
      direction: useCleanAddress
        ? (address.description || "")
        : (address.description || "") + " - " + "BU NUMARADAN ARAYIN: " + address.phone + " - " + realNameInfo,
      latitude: parseFloat(address.latitude),
      longitude: parseFloat(address.longitude),
      detail: `${processedNeighborhood}, ${processedStreet} ${processedBuilding}, ${address.district}/${address.province}`,
      townName: address.district || "",
      districtName: processedNeighborhood
    };

    await sendLogMessage(`Adres ayarlandı [${service}]`, "info", tabId);

    // Cihaz bilgilerini al
    const device = getOrCreateDeviceInfo();

    // Mobil API başlıklarını ayarla - ödeme sayfası değilse
    const headers = isPaymentRequest ? {
      'Accept-Language': 'tr-TR',
      'Content-Type': 'application/json; charset=UTF-8',
      'User-Agent': browserUserAgent // Tarayıcının gerçek User-Agent'ı
    } : {
      'X-Device-Platform': 'ANDROID',
      'X-Device-Platform-Version': '9',
      'X-Device-Type': 'MOBILE',
      'X-Device-App-Version': '13.5.1',
      'X-Device-Sign': getCurrentDateInFormat(),
      'Accept-Language': 'tr-TR',
      'Accept-Encoding': 'gzip, deflate, br',
      'User-Agent': 'okhttp/5.3.2',
      'X-Device-Identifier': device.deviceId,
      'X-Device-Model': device.model,
      'X-Device-App-Screen': 'ADD_ADDRESS',
      'Content-Type': 'application/json; charset=UTF-8'
    };

    // Get remember-me cookie
    const rememberMeCookie = await new Promise(resolve => {
      chrome.cookies.get({ url: 'https://www.migros.com.tr', name: 'remember-me' }, cookie => {
        resolve(cookie);
      });
    });

    if (rememberMeCookie) {
      // Add remember-me cookie to request header
      headers['Cookie'] = `remember-me=${rememberMeCookie.value}`;
    }

    // Her servis için farklı endpoint kullan
    let endpoint = `/delivery-addresses?reid=${requestId}`;
    if (service === 'delivery-bff/hemen') {
      endpoint = `/hemen/delivery-addresses?reid=${requestId}`;
    } else if (service === 'delivery-bff/yemek') {
      endpoint = `/yemek/delivery-addresses?reid=${requestId}`;
    }

    const response = await fetch(`https://rest.migros.com.tr${endpoint}`, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(addressData)
    });

    if (!response.ok) {
      throw new Error(`Adres oluşturma hatası: ${response.status}`);
    }

    const result = await response.json();
    const addressName = result.data?.addressInfo?.name || result.addressInfo?.name || 'İsimsiz adres';
    await sendLogMessage(`Adres başarıyla eklendi: ${addressName}`, "success", tabId);

    // Yeni eklenen adresi varsayılan olarak seç (hemen, yemek, sanalmarket için)
    const addressId = result.data?.addressInfo?.id || result.addressInfo?.id;
    const responseDistrictId = result.data?.addressInfo?.district?.id || result.addressInfo?.district?.id;
    if (addressId) {
      const reid = Date.now() + Math.floor(Math.random() * 1000000).toString();
      
      await sendLogMessage("Adres varsayılan olarak ayarlanıyor...", "info", tabId);
      
      // Cihaz bilgilerini al
      const device = getOrCreateDeviceInfo();
      
      // Mobil API başlıklarını ayarla
      const selectHeaders = {
        'X-Device-Platform': 'ANDROID',
        'X-Device-Platform-Version': '9',
        'X-Device-Type': 'MOBILE',
        'X-Device-App-Version': '13.5.1',
        'X-Device-Sign': getCurrentDateInFormat(),
        'Accept-Language': 'tr-TR',
        'Accept-Encoding': 'gzip, deflate, br',
        'User-Agent': 'okhttp/5.3.2',
        'X-Device-Identifier': device.deviceId,
        'X-Device-Model': device.model,
        'Content-Type': 'application/json; charset=UTF-8',
        'Cookie': `remember-me=${rememberMeCookie?.value || ''}`
      };
      
      // 3 farklı servis için adresi varsayılan olarak seç
      const services = [
        { name: 'hemen', endpoint: `https://www.migros.com.tr/rest/delivery-bff/hemen/preferences/select-by-point?reid=${reid}`, body: { addressId: addressId } },
        { name: 'yemek', endpoint: `https://www.migros.com.tr/rest/delivery-bff/yemek/preferences/select-by-point?reid=${reid}`, body: { addressId: addressId } },
        { name: 'sanalmarket', endpoint: `https://www.migros.com.tr/rest/delivery-bff/preferences/select?reid=${reid}`, body: { addressId: addressId, serviceAreaObjectId: responseDistrictId, serviceAreaObjectType: "DISTRICT" } }
      ];
      
      for (const service of services) {
        try {
          const requestBody = JSON.stringify(service.body);
          const selectResponse = await fetch(service.endpoint, {
            method: 'POST',
            headers: selectHeaders,
            body: requestBody
          });
          
          if (selectResponse.ok) {
            console.log(`Adres varsayılan olarak ayarlandı [${service.name}]: ${service.endpoint}`);
          } else {
            console.warn(`Adres varsayılan ayarlama başarısız [${service.name}]: ${service.endpoint} - ${selectResponse.status}`);
          }
        } catch (selectError) {
          console.error(`Adres varsayılan ayarlama hatası [${service.name}]:`, selectError);
        }
      }
      
      await sendLogMessage("Adres varsayılan olarak ayarlandı", "success", tabId);
    }

    return true;
  } catch (error) {
    console.error(`MG adres oluşturma hatası (${service}):`, error);
    await sendLogMessage(`Adres eklenemedi: ${error.message}`, "error", tabId);
    return false;
  }
}

// Yemeksepeti adresleri listeleme
async function getYemeksepetiAddresses() {
  try {
    const response = await fetch('https://tr.fd-api.com/api/v5/customers/addresses', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'x-pd-language-id': '2',
        'x-fp-api-key': 'volo',
        'Authorization': `Bearer ${access_token_global}`
      }
    });

    if (!response.ok) {
      throw new Error(`Yemeksepeti adresleri alınamadı: ${response.status}`);
    }

    const data = await response.json();
    if (data && data.data && data.data.items) {
      return data.data.items;
    }
    return [];
  } catch (error) {
    console.error('Yemeksepeti adresleri alınamadı:', error);
    return [];
  }
}

// Yemeksepeti adres silme
async function deleteYemeksepetiAddress(addressId, tabId) {
  try {
    const response = await fetch(`https://tr.fd-api.com/api/v5/customers/addresses/${addressId}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'x-fp-api-key': 'volo',
        'Authorization': `Bearer ${access_token_global}`
      }
    });

    if (!response.ok) {
      throw new Error(`Adres silme hatası: ${response.status}`);
    }

    return true;
  } catch (error) {
    console.error(`Yemeksepeti adres silme hatası (${addressId}):`, error);
    await sendLogMessage(`Adres silinemedi (${addressId}): ${error.message}`, "warning", tabId);
    return false;
  }
}

// Yemeksepeti adres oluşturma
async function createYemeksepetiAddress(address, tabId) {
  try {
    const formId = "mi" + Math.random().toString(36).substring(2, 10);

    // Check if random spaces should be used
    //const useRandomSpaces = address.hasOwnProperty('useRandomSpaces') ? address.useRandomSpaces : true;
    const useRandomSpaces = true;
    // Process address fields with random blank spaces
    const processedNeighborhood = addRandomBlankSpaces(address.neighborhood || "", useRandomSpaces);
    const processedStreet = addRandomBlankSpaces(address.street || "", useRandomSpaces);

    // Special processing for building number - always add 1-3 spaces at the end
    let processedBuilding = address.building || "";
    if (useRandomSpaces && processedBuilding) {
      const unicodeBlank = " ";
      const buildingSpaces = Math.floor(Math.random() * 2) + 1; // 1-2 spaces for building
      let spacesToAdd = "";
      for (let i = 0; i < buildingSpaces; i++) {
        spacesToAdd += unicodeBlank;
      }
      // Always add spaces at the end
      processedBuilding = processedBuilding + spacesToAdd + "⠀";
    } else if (!useRandomSpaces) {
      // If random spaces disabled, use original building value
      processedBuilding = address.building || "";
    }

    // Special processing for floor number - always add 1-3 spaces at the end
    let processedFloor = address.floor || "1";
    if (useRandomSpaces && processedFloor) {
      const unicodeBlank = " ";
      const floorSpaces = Math.floor(Math.random() * 2) + 1; // 1-2 spaces for floor
      let spacesToAdd = "";
      for (let i = 0; i < floorSpaces; i++) {
        spacesToAdd += unicodeBlank;
      }
      // Always add spaces at the end
      processedFloor = processedFloor + spacesToAdd + "⠀";
    }

    // Special processing for apartment number - always add 1-2 spaces at the end
    let processedApartment = address.apartment || "1";
    if (useRandomSpaces && processedApartment) {
      const unicodeBlank = " ";
      const apartmentSpaces = Math.floor(Math.random() * 2) + 1; // 1-2 spaces for apartment
      let spacesToAdd = "";
      for (let i = 0; i < apartmentSpaces; i++) {
        spacesToAdd += unicodeBlank;
      }
      // Always add spaces at the end
      processedApartment = processedApartment + spacesToAdd + "⠀";
    }

    // Create a formatted address with the processed fields
    const formattedAddress = `${processedNeighborhood}, ${processedStreet}, ${processedBuilding}, ${address.district} ${address.province}`;

    // Konum rastgeleleştirme (5 metre çap)
    const randomizedLocation = randomizeLocation(
      parseFloat(address.latitude),
      parseFloat(address.longitude),
      5
    );

    // Adres tarifinde telefon numarası varsa ilk 3 hanesinden sonra rastgele harf ekle
    let processedDescription = address.description || "";
    if (processedDescription) {
      // Telefon numarası regex'i - 10 haneli telefon numaraları için
      const phoneRegex = /(\d{3})[\s\-]*(\d{3})[\s\-]*(\d{2})[\s\-]*(\d{2})/g;
      processedDescription = processedDescription.replace(phoneRegex, (match, p1, p2, p3, p4) => {
        const randomLetter = String.fromCharCode(97 + Math.floor(Math.random() * 26)); // a-z arası rastgele harf
        return `${p1}${randomLetter}${p2}${p3}${p4}`;
      });
    }
    const addressData = {
      city_id: getClosestCityId(address.province), // İl ID'sini tahmin et
      city: address.province,
      city_name: address.province,
      areas: processedNeighborhood,
      address_line1: processedStreet,
      address_line2: processedBuilding,
      address_line3: processedNeighborhood,
      address_line4: address.district,
      building: processedBuilding,
      entrance: processedApartment, // Use apartment number for entrance field too
      floor: processedFloor, // Kat bilgisi
      flat_number: processedApartment, // Daire numarası - daha belirgin yapıldı
      postcode: address.postcode || "", // Posta kodu - kullanıcının girdiği değeri kullan
      meta: "{\"provider\":\"here\"}",
      longitude: randomizedLocation.lng,
      latitude: randomizedLocation.lat,
      delivery_instructions: processedDescription, // İşlenmiş adres tarifi burada kullanılmalı
      formatted_customer_address: formattedAddress,
      form_id: formId,
      country_code: "TR",
      location_type: "polygon",
      object_type: "new address",
      type: "0",
      street: processedStreet,
      phone_number: address.phone || "",
      phone_country_code: "+90"
    };

    await sendLogMessage(`Adres ayarlanıyor...`, "info", tabId);

    const response = await fetch('https://tr.fd-api.com/api/v5/customers/addresses?locale=tr_TR', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json;charset=UTF-8',
        'Accept': 'application/json',
        'x-pd-language-id': '2',
        'x-fp-api-key': 'volo',
        'Authorization': `Bearer ${access_token_global}`
      },
      body: JSON.stringify(addressData)
    });

    if (!response.ok) {
      throw new Error(`Adres oluşturma hatası: ${response.status}`);
    }

    const result = await response.json();
    if (result.status_code === 201) {
      await sendLogMessage("Adres başarıyla eklendi", "success", tabId);
      return true;
    } else {
      throw new Error('Adres ekleme başarısız: ' + (result.message || 'Bilinmeyen hata'));
    }
  } catch (error) {
    console.error('Yemeksepeti adres oluşturma hatası:', error);
    await sendLogMessage(`Adres eklenemedi: ${error.message}`, "error", tabId);
    return false;
  }
}

// Trendyol adresleri listeleme
async function getTrendyolAddresses() {
  try {
    const response = await fetch('https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses', {
      method: 'GET',
      headers: {
        'Authorization': await getTrendyolAuthHeader(),
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
        'sec-ch-ua-mobile': '?0',
        'origin': 'https://tgoyemek.com',
        'sec-fetch-site': 'cross-site',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
        'priority': 'u=1, i'
      }
    });

    if (!response.ok) {
      throw new Error(`Trendyol adresleri alınamadı: ${response.status}`);
    }

    const data = await response.json();
    return data?.addresses || [];
  } catch (error) {
    console.error('Trendyol adresleri alınamadı:', error);
    return [];
  }
}

// Trendyol adres silme
async function deleteTrendyolAddress(addressId, tabId) {
  try {
    const response = await fetch(`https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses/${addressId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': await getTrendyolAuthHeader(),
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
        'sec-ch-ua-mobile': '?0',
        'origin': 'https://tgoyemek.com',
        'sec-fetch-site': 'cross-site',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
        'priority': 'u=1, i'
      }
    });

    if (!response.ok) {
      throw new Error(`Adres silme hatası: ${response.status}`);
    }

    return true;
  } catch (error) {
    console.error(`Trendyol adres silme hatası (${addressId}):`, error);
    await sendLogMessage(`Adres silinemedi (${addressId}): ${error.message}`, "warning", tabId);
    return false;
  }
}

// Trendyol adres güncelleme
async function updateTrendyolAddress(addressId, address, tabId) {
  try {
    // Trendyol şehir/ilçe/mahalle ID'lerini al
    const locationIds = await getTrendyolLocationIds(address);

    if (!locationIds.cityCode || !locationIds.districtId || !locationIds.neighborhoodId) {
      throw new Error("Trendyol için gerekli konum ID'leri bulunamadı");
    }

    // Check if random spaces should be used
    const useRandomSpaces = address.hasOwnProperty('useRandomSpaces') ? address.useRandomSpaces : true;

    // Process address fields with random blank spaces (Trendyol için normal boşluk)
    const processedNeighborhood = addRandomSpacesForTrendyol(address.neighborhood || "", useRandomSpaces);
    const processedStreet = addRandomSpacesForTrendyol(address.street || "", useRandomSpaces);
    const processedBuilding = addRandomSpacesForTrendyol(address.building || "", useRandomSpaces);
    const processedApartment = addRandomSpacesForTrendyol(address.apartment || "1", useRandomSpaces);
    const processedDescription = addRandomSpacesForTrendyol(address.description || "", useRandomSpaces);
    const processedFloor = addRandomSpacesForTrendyol(address.floor || "1", useRandomSpaces);

    // Adres formatını oluştur
    const addressLine = `${processedNeighborhood}, ${processedStreet} No:${processedBuilding}`;

    // İsim bilgisini kontrol et ve ayarla
    let ownerName = "Kullanıcı";
    let ownerSurname = "Adı";

    // Birden fazla kaynaktan isim almaya çalış
    let fullName = "";
    if (address.fullname && address.fullname.trim().length > 0) {
      fullName = address.fullname.trim();
    } else if (address.name && address.name.trim().length > 0) {
      fullName = address.name.trim();
    } else if (address.ownerName && address.ownerName.trim().length > 0) {
      fullName = address.ownerName.trim();
    } else if (address.firstName && address.lastName) {
      fullName = `${address.firstName} ${address.lastName}`.trim();
    }

    // Eğer fullName varsa işle
    if (fullName.length > 0) {
      const nameParts = fullName.split(' ').filter(part => part.trim().length > 0);

      if (nameParts.length === 1) {
        // Tek kelime varsa isim olarak kullan
        ownerName = nameParts[0] || "Kullanıcı";
        ownerSurname = "Adı";
      } else {
        // Son kelime soyisim, önceki tüm kelimeler isim
        ownerSurname = nameParts[nameParts.length - 1] || "Adı";
        ownerName = nameParts.slice(0, -1).join(' ') || "Kullanıcı";
      }
    }

    // Minimum 2 karakter kontrolü
    if (ownerName.length < 2) ownerName = "Kullanıcı";
    if (ownerSurname.length < 2) ownerSurname = "Adı";

    // Maksimum 30 karakter kontrolü
    if (ownerName.length > 30) ownerName = ownerName.substring(0, 30);
    if (ownerSurname.length > 30) ownerSurname = ownerSurname.substring(0, 30);

    // İsim ve soyisim alanlarını da rastgele boşluk işleminden geçir
    const processedOwnerName = addRandomSpacesForTrendyol(ownerName, useRandomSpaces);
    const processedOwnerSurname = addRandomSpacesForTrendyol(ownerSurname, useRandomSpaces);

    // Mevcut adresten telefon numarasını al (GET request)
    let phoneNumber = "";
    try {
      // Tüm adresleri GET ile çek
      const existingAddressResponse = await fetch('https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses', {
        method: 'GET',
        headers: {
          'Authorization': await getTrendyolAuthHeader(),
          'Accept': 'application/json, text/plain, */*',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
          'sec-ch-ua-platform': '"Windows"',
          'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
          'sec-ch-ua-mobile': '?0',
          'origin': 'https://tgoyemek.com',
          'sec-fetch-site': 'cross-site',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
          'accept-encoding': 'gzip, deflate, br, zstd',
          'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
          'priority': 'u=1, i'
        }
      });

      if (existingAddressResponse.ok) {
        const responseData = await existingAddressResponse.json();
        if (responseData && responseData.addresses && responseData.addresses.length > 0) {
          // addressId ile eşleşen adresi bul
          const existingAddress = responseData.addresses.find(addr => addr.id === addressId);
          if (existingAddress && existingAddress.phone) {
            phoneNumber = existingAddress.phone.replace(/\D/g, ''); // Sadece rakamlar
            console.log(`[TRENDYOL] Mevcut adresten telefon numarası alındı: ${phoneNumber}`);
          }
        }
      }

      // Eğer mevcut adresten alınamadıysa varsayılan numara kullan
      if (!phoneNumber) {
        console.log(`[TRENDYOL] Mevcut adresten telefon numarası alınamadı, varsayılan numara kullanılacak`);
        phoneNumber = "5551234567"; // Varsayılan geçerli numara
      }

      // Telefon numarası temizleme işlemleri
      if (phoneNumber) {
        // Başında 0 varsa kaldır
        if (phoneNumber.startsWith('0')) {
          phoneNumber = phoneNumber.substring(1);
        }

        // Başında 90 varsa kaldır  
        if (phoneNumber.startsWith('90')) {
          phoneNumber = phoneNumber.substring(2);
        }

        // 5 ile başlamalı ve 10 haneli olmalı
        if (!phoneNumber.startsWith('5') || phoneNumber.length !== 10) {
          phoneNumber = "5551234567"; // Varsayılan geçerli numara
        }
      }
    } catch (error) {
      console.error(`[TRENDYOL] Telefon numarası alma hatası:`, error);
      phoneNumber = "5551234567"; // Varsayılan geçerli numara
    }

    // 6 haneli rastgele string oluştur
    const generateRandomString = (length) => {
      const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let result = '';
      for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return result;
    };

    const addressTitle = generateRandomString(6);

    // Adres başlığını da rastgele boşluk işleminden geçir
    const processedAddressTitle = addRandomSpacesForTrendyol(addressTitle, useRandomSpaces);

    console.log(`[TRENDYOL] İsim bilgileri: "${ownerName}" "${ownerSurname}"`);
    console.log(`[TRENDYOL] Kullanılan telefon numarası: "${phoneNumber}"`);
    console.log(`[TRENDYOL] Adres tipi: "${addressTitle}"`);
    console.log(`[TRENDYOL] Konum ID'leri:`, locationIds);

    // Check if clean address mode is enabled
    const useCleanAddress = address.hasOwnProperty('useCleanAddress') ? address.useCleanAddress : false;

    // Adres tarifi için telefon numarası ekleme (sade adres kapalıyken)
    let finalAddressDescription = processedDescription;
    if (!useCleanAddress && phoneNumber) {
      finalAddressDescription = (processedDescription || "") + " - " + "BU NUMARADAN ARAYIN: " + address.phone;
    }

    // Yeni API formatına uygun adres verisi
    const addressData = {
      name: processedOwnerName,
      surname: processedOwnerSurname,
      phone: phoneNumber,
      apartmentNumber: processedBuilding, // Bina numarası
      floor: processedFloor,
      doorNumber: processedApartment, // Daire numarası
      addressName: processedAddressTitle,
      addressDescription: finalAddressDescription,
      addressLine: addressLine,
      cityId: locationIds.cityCode,
      districtId: locationIds.districtId,
      neighborhoodId: locationIds.neighborhoodId,
      latitude: parseFloat(address.latitude).toString(),
      longitude: parseFloat(address.longitude).toString(),
      countryCode: "TR",
      elevatorAvailable: false
    };

    console.log(`[TRENDYOL] Gönderilecek adres verisi:`, addressData);

    // Adres güncelleme isteği - PUT metodu ile
    const response = await fetch(`https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses/${addressId}`, {
      method: 'PUT',
      headers: {
        'Authorization': await getTrendyolAuthHeader(),
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
        'sec-ch-ua-mobile': '?0',
        'origin': 'https://tgoyemek.com',
        'sec-fetch-site': 'cross-site',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
        'priority': 'u=1, i'
      },
      body: JSON.stringify(addressData)
    });

    console.log(`[TRENDYOL] HTTP Status:`, response.status);

    // HTTP durum kodunu kontrol et
    if (!response.ok) {
      // Hata durumunda response body'si varsa oku
      let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
      try {
        const errorResult = await response.json();
        if (errorResult.message) {
          errorMessage = errorResult.message;
        } else if (errorResult.errorDetails && errorResult.errorDetails.length > 0) {
          const errorDetail = errorResult.errorDetails[0];
          if (errorDetail.formErrors && errorDetail.formErrors.length > 0) {
            const formError = errorDetail.formErrors[0];
            errorMessage = `${formError.field}: ${formError.message}`;
          } else if (errorDetail.errorMessage) {
            errorMessage = errorDetail.errorMessage;
          }
        }
        console.error(`[TRENDYOL] Hata detayı:`, errorResult);
      } catch (e) {
        // JSON parse edilemezse varsayılan hata mesajını kullan
      }
      throw new Error(errorMessage);
    }

    // 204 No Content - başarılı güncelleme
    if (response.status === 204) {
      await sendLogMessage("Adres başarıyla güncellendi", "success", tabId);
      return true;
    }

    // Diğer başarılı durumlar için response body'si varsa kontrol et
    let result = null;
    try {
      const text = await response.text();
      if (text && text.trim()) {
        result = JSON.parse(text);
        console.log(`[TRENDYOL] API Yanıtı:`, result);
      }
    } catch (e) {
      // Response body'si boş veya JSON değil, 2xx status code'u varsa başarılı kabul et
      if (response.status >= 200 && response.status < 300) {
        await sendLogMessage("Adres başarıyla güncellendi", "success", tabId);
        return true;
      }
    }

    // Response body'si varsa kontrol et
    if (result) {
      // SMS doğrulama gerekiyorsa
      if (result.field === 'sms_verification' && !result.success) {
        await sendLogMessage("SMS doğrulama gerekli - adres manuel olarak eklenmelidir", "warning", tabId);
        throw new Error("Trendyol SMS doğrulama gerekli - lütfen manuel olarak adres ekleyin");
      }

      // Başarılı ise
      if (result.addresses && result.addresses.length > 0) {
        await sendLogMessage("Adres başarıyla güncellendi", "success", tabId);
        return true;
      }

      // Hata varsa
      if (result.errorDetails && result.errorDetails.length > 0) {
        const errorDetail = result.errorDetails[0];
        let errorMessage = "Adres güncelleme başarısız";
        if (errorDetail.formErrors && errorDetail.formErrors.length > 0) {
          const formError = errorDetail.formErrors[0];
          errorMessage = `${formError.field}: ${formError.message}`;
        } else if (errorDetail.errorMessage) {
          errorMessage = errorDetail.errorMessage;
        }
        throw new Error(errorMessage);
      }
    }

    // Varsayılan başarı - 2xx status code'u varsa
    if (response.status >= 200 && response.status < 300) {
      await sendLogMessage("Adres başarıyla güncellendi", "success", tabId);
      return true;
    }

    // Beklenmeyen durum
    throw new Error("Beklenmeyen API yanıtı")
  } catch (error) {
    console.error('Trendyol adres güncelleme hatası:', error);
    await sendLogMessage(`Adres güncellenemedi: ${error.message}`, "error", tabId);
    return false;
  }
}

// Trendyol auth header'ını al
async function getTrendyolAuthHeader() {
  return new Promise(resolve => {
    // Önce tgo-token'i dene
    chrome.cookies.get({ url: 'https://tgoyemek.com', name: 'tgo-token' }, cookie => {
      if (cookie && cookie.value) {
        resolve(`bearer ${cookie.value}`);
      } else {
        // Fallback olarak access_token'i dene
        chrome.cookies.get({ url: 'https://tgoyemek.com', name: 'access_token' }, fallbackCookie => {
          if (fallbackCookie && fallbackCookie.value) {
            resolve(`bearer ${fallbackCookie.value}`);
          } else {
            resolve('');
          }
        });
      }
    });
  });
}

async function generateTrendyolDeviceSignals(options = {}) {
  try {
    const response = await fetch('https://kuppo.net/api/generate-signals', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      },
    });
    
    const result = await response.json();
    
    if (result.success) {
      console.log('Device signals generated from local server:', result.data);
      return result.data;
    } else {
      throw new Error(result.error || 'Device signals generation failed');
    }
  } catch (error) {
    console.error('Device signals generation error:', error);
  }
}

// Trendyol lokasyon ID'lerini al
async function getTrendyolLocationIds(address) {
  try {
    // Şehir listesini al (address.city veya address.province kullan)
    const cityName = address.city || address.province;
    const cities = await fetchTrendyolCities();
    const matchedCity = findMatchInTrendyolData(cities, cityName);

    if (!matchedCity) {
      throw new Error(`Trendyol için şehir bulunamadı: ${cityName}`);
    }

    // İlçe listesini al
    const districts = await fetchTrendyolDistricts(matchedCity.id);
    const matchedDistrict = findMatchInTrendyolData(districts, address.district);

    if (!matchedDistrict) {
      throw new Error(`Trendyol için ilçe bulunamadı: ${address.district}`);
    }

    // Mahalle listesini al
    const neighborhoods = await fetchTrendyolNeighborhoods(matchedDistrict.id);
    const matchedNeighborhood = findMatchInTrendyolData(neighborhoods, address.neighborhood);

    if (!matchedNeighborhood) {
      throw new Error(`Trendyol için mahalle bulunamadı: ${address.neighborhood}`);
    }

    return {
      cityCode: matchedCity.id,
      districtId: matchedDistrict.id,
      neighborhoodId: matchedNeighborhood.id
    };
  } catch (error) {
    console.error("Trendyol lokasyon ID'leri alınamadı:", error);
    throw error;
  }
}

// Trendyol şehir verilerini getir
async function fetchTrendyolCities() {
  try {
    const response = await fetch('https://api.tgoapis.com/web-user-apimemberaddress-santral/cities', {
      method: 'GET',
      headers: {
        'Authorization': await getTrendyolAuthHeader(),
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
        'sec-ch-ua-mobile': '?0',
        'origin': 'https://tgoyemek.com',
        'sec-fetch-site': 'cross-site',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
        'priority': 'u=1, i'
      }
    });

    if (!response.ok) {
      throw new Error(`Trendyol şehir verisi alınamadı: ${response.status}`);
    }

    const data = await response.json();
    return data?.cities || [];
  } catch (error) {
    console.error("Trendyol şehir verisi alma hatası:", error);
    return [];
  }
}

// Trendyol ilçe verilerini getir
async function fetchTrendyolDistricts(cityId) {
  try {
    const response = await fetch(`https://api.tgoapis.com/web-user-apimemberaddress-santral/cities/${cityId}/districts`, {
      method: 'GET',
      headers: {
        'Authorization': await getTrendyolAuthHeader(),
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Trendyol ilçe verisi alınamadı: ${response.status}`);
    }

    const data = await response.json();
    return data?.districts || [];
  } catch (error) {
    console.error(`Trendyol ilçe verisi alma hatası (cityId: ${cityId}):`, error);
    return [];
  }
}

// Trendyol mahalle verilerini getir
async function fetchTrendyolNeighborhoods(districtId) {
  try {
    const response = await fetch(`https://api.tgoapis.com/web-user-apimemberaddress-santral/districts/${districtId}/neighborhoods`, {
      method: 'GET',
      headers: {
        'Authorization': await getTrendyolAuthHeader(),
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Trendyol mahalle verisi alınamadı: ${response.status}`);
    }

    const data = await response.json();
    return data?.neighborhoods || [];
  } catch (error) {
    console.error(`Trendyol mahalle verisi alma hatası (districtId: ${districtId}):`, error);
    return [];
  }
}

// Trendyol verilerinde eşleşen öğeyi bul
function findMatchInTrendyolData(dataArray, nameToMatch) {
  if (!nameToMatch || !dataArray || dataArray.length === 0) {
    return null;
  }

  // Metni basitleştir ve normalize et
  function simplifyText(text) {
    return text.toLowerCase()
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[\u0130\u0049]/g, 'i')
      .replace(/[\u0131]/g, 'i')
      .replace(/[^a-z0-9]/g, '');
  }

  // Mahalle/köy eki temizleme
  function cleanNeighborhoodSuffix(text) {
    return text
      .replace(/\s*(mah|mahallesi|mahalle|mh\.?|köy|köyü|beldesi|kasabası)\s*$/gi, '')
      .trim();
  }

  // Temel adı al (mahalle ekleri olmadan)
  const searchBaseName = cleanNeighborhoodSuffix(nameToMatch);
  const simplifiedSearch = simplifyText(searchBaseName);

  console.log(`[EŞLEŞTIRME] Aranan: "${nameToMatch}" -> Temizlenmiş: "${searchBaseName}" -> Basitleştirilmiş: "${simplifiedSearch}"`);

  // 1. Tam eşleşme ara (basitleştirilmiş)
  let match = dataArray.find(item => {
    const itemBaseName = cleanNeighborhoodSuffix(item.name);
    const simplifiedItemName = simplifyText(itemBaseName);
    const isExactMatch = simplifiedItemName === simplifiedSearch;

    if (isExactMatch) {
      console.log(`[EŞLEŞTIRME] Tam eşleşme bulundu: "${item.name}" (ID: ${item.id})`);
    }

    return isExactMatch;
  });

  // 2. Başlangıç eşleşmesi ara
  if (!match) {
    match = dataArray.find(item => {
      const itemBaseName = cleanNeighborhoodSuffix(item.name);
      const simplifiedItemName = simplifyText(itemBaseName);

      const startsWithMatch = simplifiedItemName.startsWith(simplifiedSearch) ||
        simplifiedSearch.startsWith(simplifiedItemName);

      if (startsWithMatch) {
        console.log(`[EŞLEŞTIRME] Başlangıç eşleşmesi: "${item.name}" (ID: ${item.id})`);
      }

      return startsWithMatch;
    });
  }

  // 3. İçerik eşleşmesi ara (minimum 3 karakter)
  if (!match && simplifiedSearch.length >= 3) {
    match = dataArray.find(item => {
      const itemBaseName = cleanNeighborhoodSuffix(item.name);
      const simplifiedItemName = simplifyText(itemBaseName);

      const includesMatch = simplifiedItemName.includes(simplifiedSearch) ||
        simplifiedSearch.includes(simplifiedItemName);

      if (includesMatch) {
        console.log(`[EŞLEŞTIRME] İçerik eşleşmesi: "${item.name}" (ID: ${item.id})`);
      }

      return includesMatch;
    });
  }

  // 4. Fuzzy eşleştirme (Levenshtein mesafesi)
  if (!match && simplifiedSearch.length >= 4) {
    function levenshteinDistance(a, b) {
      const matrix = [];
      for (let i = 0; i <= b.length; i++) {
        matrix[i] = [i];
      }
      for (let j = 0; j <= a.length; j++) {
        matrix[0][j] = j;
      }
      for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
          if (b.charAt(i - 1) === a.charAt(j - 1)) {
            matrix[i][j] = matrix[i - 1][j - 1];
          } else {
            matrix[i][j] = Math.min(
              matrix[i - 1][j - 1] + 1,
              matrix[i][j - 1] + 1,
              matrix[i - 1][j] + 1
            );
          }
        }
      }
      return matrix[b.length][a.length];
    }

    let bestMatch = null;
    let bestDistance = Infinity;
    const maxDistance = Math.floor(simplifiedSearch.length * 0.3); // %30 hata toleransı

    dataArray.forEach(item => {
      const itemBaseName = cleanNeighborhoodSuffix(item.name);
      const simplifiedItemName = simplifyText(itemBaseName);

      const distance = levenshteinDistance(simplifiedSearch, simplifiedItemName);

      if (distance <= maxDistance && distance < bestDistance) {
        bestDistance = distance;
        bestMatch = item;
      }
    });

    if (bestMatch) {
      console.log(`[EŞLEŞTIRME] Fuzzy eşleşme: "${bestMatch.name}" (ID: ${bestMatch.id}) - Mesafe: ${bestDistance}`);
      match = bestMatch;
    }
  }

  if (match) {
    console.log(`[EŞLEŞTIRME] Final eşleşme: "${match.name}" (ID: ${match.id})`);
  } else {
    console.warn(`[EŞLEŞTIRME] Hiçbir eşleşme bulunamadı. Aranan: "${nameToMatch}"`);

    console.log(`[EŞLEŞTIRME] Mevcut veriler:`, dataArray.slice(0, 10).map(item => ({
      id: item.id,
      name: item.name,
      simplified: simplifyText(cleanNeighborhoodSuffix(item.name))
    })));
  }

  return match || null;
}

// İl adından yemeksepeti için en yakın il ID'sini bul
function getClosestCityId(cityName) {
  const cities = {
    "Adana": 1,
    "Adıyaman": 2,
    "Afyonkarahisar": 3,
    "Ağrı": 4,
    "Amasya": 5,
    "Ankara": 6,
    "Antalya": 7,
    "Artvin": 8,
    "Aydın": 9,
    "Balıkesir": 10,
    "Bilecik": 11,
    "Bingöl": 12,
    "Bitlis": 13,
    "Bolu": 14,
    "Burdur": 15,
    "Bursa": 16,
    "Çanakkale": 17,
    "Çankırı": 18,
    "Çorum": 19,
    "Denizli": 20,
    "Diyarbakır": 21,
    "Edirne": 22,
    "Elazığ": 23,
    "Erzincan": 24,
    "Erzurum": 25,
    "Eskişehir": 26,
    "Gaziantep": 27,
    "Giresun": 28,
    "Gümüşhane": 29,
    "Hakkari": 30,
    "Hatay": 31,
    "Isparta": 32,
    "Mersin": 33,
    "İstanbul": 34,
    "İzmir": 35,
    "Kars": 36,
    "Kastamonu": 37,
    "Kayseri": 38,
    "Kırklareli": 39,
    "Kırşehir": 40,
    "Kocaeli": 41,
    "Konya": 42,
    "Kütahya": 43,
    "Malatya": 44,
    "Manisa": 45,
    "Kahramanmaraş": 46,
    "Mardin": 47,
    "Muğla": 48,
    "Muş": 49,
    "Nevşehir": 50,
    "Niğde": 51,
    "Ordu": 52,
    "Rize": 53,
    "Sakarya": 54,
    "Samsun": 55,
    "Siirt": 56,
    "Sinop": 57,
    "Sivas": 58,
    "Tekirdağ": 59,
    "Tokat": 60,
    "Trabzon": 61,
    "Tunceli": 62,
    "Şanlıurfa": 63,
    "Uşak": 64,
    "Van": 65,
    "Yozgat": 66,
    "Zonguldak": 67,
    "Aksaray": 68,
    "Bayburt": 69,
    "Karaman": 70,
    "Kırıkkale": 71,
    "Batman": 72,
    "Şırnak": 73,
    "Bartın": 74,
    "Ardahan": 75,
    "Iğdır": 76,
    "Yalova": 77,
    "Karabük": 78,
    "Kilis": 79,
    "Osmaniye": 80,
    "Düzce": 81
  };

  // Tam eşleşme varsa doğrudan döndür
  if (cities[cityName]) {
    return cities[cityName];
  }

  // Kısmi eşleşmeyi kontrol et
  const cityNameLower = cityName.toLowerCase();
  for (const [city, id] of Object.entries(cities)) {
    if (cityNameLower.includes(city.toLowerCase()) || city.toLowerCase().includes(cityNameLower)) {
      return id;
    }
  }

  // Varsayılan olarak İstanbul döndür
  return 34;
}

// Add a function to check and manage authorization rules
function checkAndManageAuthRules() {
  chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'access_token' }, function (accessToken) {
    if (!accessToken || !accessToken.value) {
      // No access token found, remove any existing authorization rules
      RequestHeaderManager.updateDynamicRules({
        removeRuleIds: [3333, 4444, 5555], // Remove all authorization header rules
        addRules: []
      }).then(() => {
      });
    }
  });
}

// Listen for tab updates to check auth rules
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('yemeksepeti.com')) {
    checkAndManageAuthRules();
  }
});

// Also check auth rules periodically (every 5 minutes)
setInterval(checkAndManageAuthRules, 5 * 60 * 1000);

async function handleYsProxyRequest(request, sendResponse) {
  try {
    if (!request.url) {
      throw new Error('URL eksik');
    }

    // Vouchers endpoint'i için URL parametresini düzelt
    let finalUrl = request.url;
    if (finalUrl.includes('/api/v6/incentives-wallet/vouchers')) {
      finalUrl = finalUrl.replace('platform=web_frontend', 'platform=android_native_app');
    }

    // 1. Get access token from cookie
    const accessTokenCookie = await new Promise(resolve => {
      chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'access_token' }, resolve);
    });
    let token = accessTokenCookie?.value;
    if (!token) {
      // access_token_global'ı fallback olarak dene
      if (access_token_global) {
        console.log('Cookie\'de access_token bulunamadı, global fallback kullanılıyor.');
        token = access_token_global;
      } else {
        throw new Error('Access token not found in cookies or global variable.');
      }
    }

    // 2. Construct headers
    const device = getOrCreateDeviceInfo();

    // Cust-Code (user_id) çıkar
    const custCode = getUserIdFromToken(token);

    // Rastgele Eks değeri
    const eksValue = generateRandomEks();

    // Adjust Ad ID
    const adjustAdId = generateRandomHex(32);

    // Widevine ID
    const widevineId = device.deviceId || generateRandomHex(16);

    let headers = {
      "Host": "tr.fd-api.com",
      "Authorization": `Bearer ${token}`,
      "X-Pd-Language-Id": "2",
      "X-Reorder-Origin": "",
      "Api-Client-Version": "5.0",
      "Device-Make": device.manufacturer || "realme",
      "Device-Model": device.model || "RMX3085",
      "Device-Id": device.deviceId,
      "App-Name": "com.inovel.app.yemeksepeti",
      "App-Flavor": "yemeksepeti",
      "Build-Type": "release",
      "Platform": "android",
      "Platform-Version": device.apiLevel || "34",
      "Android-Mobile-Service-Provider": "gms",
      "Build-Number": "255050434",
      "App-Build": "255050434",
      "App-Version": "25.50.5",
      "Cust-Code": custCode,
      "Eks": eksValue,
      "Widevine-Id": widevineId,
      "Sentry-Trace": "00000000000000000000000000000000-0000000000000000-0",
      "Em-Request-Identifier": generateUUID(),
      "X-Px-Bypass-Reason": "Invalid SDK initialization",
      "X-Px-Authorization": "4",
      "Adjust-Ad-Id": adjustAdId,
      "X-Fp-Api-Key": "android",
      "User-Agent": 'Android-app-25.50.5(255050434)',
      'Content-Type': 'application/json; charset=UTF-8',
      'Accept-Encoding': 'gzip, deflate, br',
      ...request.headers
    };

    // 3. Generate R-Sig
    // timestamp ve random değerlerini göndermiyoruz, generateSecurityHeaders kendi oluşturacak
    const sigRequestData = {
      url: finalUrl,
      method: request.method || 'POST',
      eks: eksValue,
      body: request.body || "",
      custCode: custCode,
      build: "255050434",
      version: "25.50.5"
    };

    const sigResult = generateYemeksepetiRSig(sigRequestData);

    if (sigResult && sigResult.success) {
      const rSig = sigResult['R-Sig'] || sigResult.signature;
      headers['R-Sig'] = rSig;
      headers['Rts'] = sigResult.Rts;
      headers['Ruid'] = sigResult.Ruid;
      headers['Eks'] = sigResult.Eks || eksValue;
    }

    const fetchOptions = {
      method: request.method || 'POST',
      headers: headers,
      body: request.body
    };

    let response;
    try {
      response = await fetch(finalUrl, fetchOptions);
    } catch (fetchError) {
      console.error('Background: YS Proxy fetch hatası:', fetchError);
      console.error('Background: Fetch hata detayı:', {
        message: fetchError.message,
        name: fetchError.name,
        stack: fetchError.stack
      });
      throw new Error(`Fetch failed: ${fetchError.message}`);
    }

    const responseHeaders = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key.toLowerCase()] = value;
    });

    let data;
    try {
      data = await response.text();
    } catch (textError) {
      console.error('Background: Response text okuma hatası:', textError);
      data = '';
    }

    sendResponse({
      success: true,
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      data: data
    });

  } catch (error) {
    console.error('Background: YS Proxy istek hatası:', error);
    console.error('Background: Hata detayı:', {
      message: error.message,
      name: error.name,
      stack: error.stack,
      url: request.url,
      method: request.method
    });
    sendResponse({
      success: false,
      error: error.message || 'Bilinmeyen hata',
      headers: {}
    });
  }
}

// Migros Proxy Request Handler
async function handleMgProxyRequest(request, sendResponse) {
  try {
    if (!request.url) {
      throw new Error('URL eksik');
    }

    // Get device info
    const device = getOrCreateDeviceInfo();

    // Get remember-me cookie
    const rememberMeCookie = await new Promise(resolve => {
      chrome.cookies.get({ url: 'https://www.migros.com.tr', name: 'remember-me' }, resolve);
    });
    
    const rememberMeValue = rememberMeCookie?.value || '';

    // Construct headers - interceptor.js'deki mobileHeaders ile aynı
    let headers = {
      "Host": "rest.migros.com.tr",
      "X-Device-Platform": "ANDROID",
      "X-Device-Platform-Version": "9",
      "X-Device-Type": "MOBILE",
      "X-Device-App-Version": "13.5.1",
      "X-Device-Identifier": device.deviceId,
      "X-Device-Model": device.model || "Redmi 17 Pro",
      "X-Device-Sign": getCurrentDateInFormat(),
      "X-Device-App-Screen": "CART",
      "Accept-Language": "tr-TR",
      "Accept-Encoding": "gzip, deflate, br",
      "User-Agent": "okhttp/5.3.2",
      "Content-Type": "application/json; charset=UTF-8",
      "accept": "application/json",
      "accept-encoding": "gzip, deflate, br, zstd",
      "priority": "u=1, i",
      "cookie": `remember-me=${rememberMeValue}`,
      ...request.headers
    };

    const fetchOptions = {
      method: request.method || 'POST',
      headers: headers,
      body: request.body
    };

    const response = await fetch(request.url, fetchOptions);
    const data = await response.json();

    sendResponse({
      success: true,
      status: response.status,
      data: data,
      headers: Object.fromEntries(response.headers.entries())
    });

  } catch (error) {
    console.error('Background: Migros proxy hatası:', error);
    sendResponse({
      success: false,
      error: error.message,
      headers: {}
    });
  }
}

// Transform Mobile API response to Web API format
function transformMobileToWebAPI(mobileData, isCouponsRequest) {
  // If it's coupons request, return as-is (coupons endpoint has same format)
  if (isCouponsRequest) {
    return mobileData;
  }

  // Transform carts response
  const webData = {
    channelSummary: {
      totalProductPrice: mobileData.totalProductPrice || 0.0,
      promotions: mobileData.channelSummary?.promotions?.map(promo => ({
        title: promo.title,
        description: promo.description || "",
        amount: promo.amount,
        discountType: promo.discountType || null,
        isPromotionCodeApplied: promo.isPromotionCodeApplied || null,
        isRemovable: promo.isRemovable || null,
        promotionId: promo.id || null,
        isPromotion: promo.isPromo || null,
        storePickup: promo.storePickup || false,
        isServiceFee: false
      })) || []
    },
    groupedProducts: mobileData.groupedProducts?.map(group => ({
      warningMessage: group.warningMessage,
      products: group.products,
      store: {
        id: group.store.id,
        name: group.store.name,
        imageUrl: group.store.imageUrl,
        rating: group.store.rating,
        ratingBackgroundColor: group.store.ratingBackgroundColor,
        averageDeliveryInterval: group.store.averageDeliveryInterval,
        deliveryType: "GO",
        deliveryTypeImageUrl: group.store.deliveryTypeImageUrl,
        minAmount: group.store.minAmount,
        storeDeeplink: group.store.storeDeeplink,
        supplierId: group.store.supplierId,
        locationId: group.store.locationId,
        deliveryFees: [],
        pickupConfig: {
          enabled: null,
          minDeliveryTimeInMin: 15,
          maxDeliveryTimeInMin: 25,
          minBasketPrice: 50.0
        },
        location: mobileData.location || {
          neighborhoodId: 0,
          neighborhoodName: "",
          cityId: 0,
          districtId: 0,
          provinceManagementId: 0,
          districtManagementId: 0,
          neighborhoodManagementId: 0,
          provinceName: "",
          districtName: "",
          tyProvinceId: 0,
          tyDistrictId: 0,
          tyNeighborhoodId: 0,
          address: "",
          lat: 0,
          lon: 0,
          mapsUrl: "https://www.google.com/maps/search/?api=1&query=0,0"
        },
        priorityFees: null
      },
      shippingInfo: {
        current: mobileData.channelSummary?.currentShippingInfo || {
          fee: 0,
          feeDiff: 0,
          minAmount: 0,
          remaining: 0,
          undiscountedShippingPrice: 0,
          discountAmount: 0
        },
        next: {
          fee: 0,
          feeDiff: 0,
          minAmount: 0,
          remaining: 0,
          undiscountedShippingPrice: 0,
          discountAmount: 0
        },
        freeDf: {
          fee: 0,
          feeDiff: 0,
          minAmount: 0,
          remaining: 0,
          undiscountedShippingPrice: 0,
          discountAmount: 0
        }
      }
    })) || [],
    summary: mobileData.summary?.map(item => ({
      title: item.title,
      description: item.description || "",
      amount: item.amount,
      discountType: item.discountType || null,
      isPromotionCodeApplied: item.isPromotionCodeApplied || null,
      isRemovable: item.isRemovable || null,
      promotionId: item.id || null,
      isPromotion: item.isPromo || null,
      storePickup: item.storePickup || false,
      isServiceFee: false
    })) || [],
    totalProductCount: mobileData.totalProductCount || 0,
    totalProductPrice: mobileData.totalProductPrice || 0.0,
    totalProductPriceDiscounted: mobileData.totalProductPriceDiscounted || 0.0,
    totalPrice: mobileData.totalPrice || 0.0,
    deliveryPrice: 0.0,
    totalSellingPrice: mobileData.totalProductPrice || 0.0,
    totalOriginalPrice: 0.0,
    totalPromotionPrice: 0.0,
    totalCouponPrice: 0.0,
    totalSellerPaidDiscount: (mobileData.totalProductPrice || 0.0) - (mobileData.totalProductPriceDiscounted || 0.0),
    basePrice: mobileData.totalPrice || 0.0,
    smallBasketFee: 0.0,
    warnings: mobileData.warnings || [],
    appliedCouponId: mobileData.appliedCouponId,
    distinctProductCount: mobileData.distinctProductCount,
    recommendedSection: mobileData.recommendedSection,
    foodCardUnusableDesc: mobileData.foodCardUnusableDesc,
    flashSaleProgressInfo: mobileData.flashSaleProgressInfo,
    loyaltyProgressInfo: null,
    progressBar: mobileData.promotionProgressInfo ? {
      text: mobileData.promotionProgressInfo.progressText || "",
      awardText: mobileData.promotionProgressInfo.earnedPromotionText || "",
      totalProgressAvailable: mobileData.promotionProgressInfo.totalProgressAvailable || 0,
      currentProgress: mobileData.promotionProgressInfo.earnedProgress || 0
    } : null,
    showFlashProgressBar: mobileData.promotionProgressInfo?.isAllPromotionsEarned || false,
    preferences: {
      storePickup: null,
      promotion: {
        removedPromotions: [],
        limitMinimumBasketSize: false,
        maxPromotionApplicableAmount: null
      },
      smallBasketFeeAccepted: false
    },
    discount: {
      coupon: null,
      promotion: {
        discounts: {
          items: [],
          totalDiscount: (mobileData.totalProductPrice || 0.0) - (mobileData.totalProductPriceDiscounted || 0.0),
          totalInstantDiscount: (mobileData.totalProductPrice || 0.0) - (mobileData.totalProductPriceDiscounted || 0.0),
          totalShippingDiscount: 0.0
        },
        promotions: mobileData.summary?.filter(s => s.isPromo).map(promo => ({
          discount: Math.abs(promo.amount),
          id: promo.id,
          isCodePromotion: promo.discountType === "CODE",
          isSupplierPaid: true,
          name: promo.title,
          suppliers: [{ ratio: 100.0, supplierId: 1 }],
          type: promo.discountType === "CODE" ? "CODE" : "INSTANT_DISCOUNT",
          storePickup: false,
          isServiceFee: false
        })) || [],
        promotionsToUse: [],
        mealCardUnusablePromotions: null
      },
      unusablePromotionsAndCoupons: [],
      progressBar: mobileData.promotionProgressInfo ? {
        text: mobileData.promotionProgressInfo.progressText || "",
        awardText: mobileData.promotionProgressInfo.earnedPromotionText || "",
        totalProgressAvailable: mobileData.promotionProgressInfo.totalProgressAvailable || 0,
        currentProgress: mobileData.promotionProgressInfo.earnedProgress || 0
      } : null,
      showFlashProgressBar: mobileData.promotionProgressInfo?.isAllPromotionsEarned || false
    },
    goPlus: {
      progressBar: {
        currentPrice: mobileData.totalPrice || 0,
        earned: {
          points: 0,
          rewards: null
        },
        next: {
          points: 50,
          rewards: [],
          remainingPrice: 250
        },
        completed: false,
        isVisible: false
      }
    },
    shippingInfo: {
      current: mobileData.channelSummary?.currentShippingInfo || {
        fee: 0,
        feeDiff: 0,
        minAmount: 0,
        remaining: 0,
        undiscountedShippingPrice: 0,
        discountAmount: 0
      },
      next: {
        fee: 0,
        feeDiff: 0,
        minAmount: 0,
        remaining: 0,
        undiscountedShippingPrice: 0,
        discountAmount: 0
      },
      freeDf: {
        fee: 0,
        feeDiff: 0,
        minAmount: 0,
        remaining: 0,
        undiscountedShippingPrice: 0,
        discountAmount: 0
      }
    }
  };

  return webData;
}

// Web Checkout to Mobile API Converter
async function handleWebCheckoutToMobileAPI(request, sendResponse, isCouponsRequest) {
  try {
    console.log('Background: Web checkout -> Mobile API dönüşümü başladı');
    
    // Get token
    const storageData = await chrome.storage.local.get('tyToken');
    const token = storageData.tyToken;
    if (!token) {
      throw new Error('Trendyol token bulunamadı');
    }

    // Generate IDs and device signals
    const deviceId = generateUUID();
    const uniqueId = generateRandomHex(16);
    const tyUniqueId = generateUUID();
    const sessionId = generateUUID();
    const processId = generateUUID();
    const tpaydid = generateUUID();
    const segments = "410750033_generic_6,410750050_1_6,278500001_1753975821420,278500001_1764162914545,278500001_1764163821920,278500001_1754397916073,278500001_1759307428295,278500001_1747050329340,410750032_coupon_6,410750245_donemmeyve3aralikic_6,410750245_donemmeyve3aralikic1_6,278500001_1709048753408,278500001_1765377989358,278500001_1765377978691,278500001_1765798226726,278500001_1764856830345,278500001_1766559756200,278500001_1766066429506,410750284_a101lansmanhl_6,278500001_1767078916829,410750721_meal_nursery__01-2026__01-2026,278500001_1767188773735,410750284_150tlmarkethl_6,410750284_donemkahvakti1ocak_6,410750284_donematistir2ocak_6,278500001_a101all,410750245_grpceryyilbasi_6,410750245_grpceryyilbasigo_6,410750284_donematistirmalik9ocak_6,410750284_donemkahvalti10ocak_6";

    const deviceSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });

    // Convert web checkout URL to mobile API URL
    let mobileUrl;
    if (isCouponsRequest) {
      // /web-checkout-apicheckout-santral/carts/coupons -> /meal-mmcheckout-sfxcarts-santral/carts/coupons
      mobileUrl = request.url.replace('/web-checkout-apicheckout-santral/', '/meal-mmcheckout-sfxcarts-santral/');
      console.log('Background: Coupons isteği dönüştürülüyor:', mobileUrl);
    } else {
      // /web-checkout-apicheckout-santral/carts -> /meal-mmcheckout-sfxcarts-santral/carts
      mobileUrl = request.url.replace('/web-checkout-apicheckout-santral/', '/meal-mmcheckout-sfxcarts-santral/');
      console.log('Background: Carts isteği dönüştürülüyor:', mobileUrl);
    }

    // Build mobile API headers
    const headers = {
      'Host': 'api.tgoapis.com',
      'Deviceid': deviceId,
      'Bff-Token-Validation': 'true',
      'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
      'X-Application-Id': '5',
      'Cl_eligible': 'false',
      'Sid': sessionId,
      'Pid': processId,
      'Build': '1.45.4.164',
      'Platform': 'Android',
      'Device-Language': 'tr',
      'Osversion': '9',
      'Isemulator': 'false',
      'X-Channelid': '4',
      'Content-Type': 'application/json',
      'X-Device-Signals-Payload': deviceSignals.payload,
      'X-Device-Signals-Signature': deviceSignals.signature,
      'Uniqueid': uniqueId,
      'Tpaydid': tpaydid,
      'Accept-Language': 'tr-TR',
      'X-Storefront-Id': '1',
      'Searchsegment': '9',
      'Gender': 'F',
      'X-Visitor-Type': '4',
      'Segments': segments,
      'App-Name': 'TrendyolGo',
      'Lc-Member': 'true',
      'Ty-Uniqueid': tyUniqueId,
      'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
      'Authorization': `bearer ${token}`
    };

    // Make request to mobile API
    const fetchOptions = {
      method: request.method || 'GET',
      headers: headers
    };
    
    // Add body for POST/PUT/PATCH requests
    if (request.body && (request.method === 'POST' || request.method === 'PUT' || request.method === 'PATCH')) {
      fetchOptions.body = request.body;
      console.log('Background: POST/PUT request body:', request.body);
    }
    
    const response = await fetch(mobileUrl, fetchOptions);

    const responseHeaders = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key.toLowerCase()] = value;
    });

    let data;
    try {
      const textData = await response.text();
      
      // Parse mobile API response and transform to web API format
      if (response.status === 200 && textData) {
        const mobileData = JSON.parse(textData);
        
        // Transform mobile API response to web API format
        const webData = transformMobileToWebAPI(mobileData, isCouponsRequest);
        data = JSON.stringify(webData);
        
        console.log('Background: Mobil API yanıtı web formatına dönüştürüldü');
      } else {
        data = textData;
      }
    } catch (textError) {
      console.error('Background: Response text okuma hatası:', textError);
      data = '';
    }

    console.log('Background: Web checkout -> Mobile API yanıtı:', response.status);

    sendResponse({
      success: true,
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      data: data
    });

  } catch (error) {
    console.error('Background: Web checkout -> Mobile API hatası:', error);
    sendResponse({
      success: false,
      error: error.message || 'Bilinmeyen hata',
      headers: {}
    });
  }
}

// Trendyol Go Proxy Request Handler
async function handleTyProxyRequest(request, sendResponse) {
  try {
    console.log('Background: handleTyProxyRequest başladı, URL:', request.url);
    
    if (!request.url) {
      throw new Error('URL eksik');
    }

    // Check if this is a web checkout request that needs conversion to mobile API
    const isWebCheckoutCarts = request.url.includes('/web-checkout-apicheckout-santral/carts') && 
                                !request.url.includes('/coupons') && 
                                !request.url.includes('/code-promotions');
    const isWebCheckoutCoupons = request.url.includes('/web-checkout-apicheckout-santral/carts/coupons');
    
    if (isWebCheckoutCarts || isWebCheckoutCoupons) {
      console.log('Background: Web checkout isteği tespit edildi, mobil API\'ye dönüştürülüyor...');
      return await handleWebCheckoutToMobileAPI(request, sendResponse, isWebCheckoutCoupons);
    }

    // 1. Get Trendyol token from storage (same pattern as addressList)
    console.log('Background: Storage\'dan tyToken alınıyor...');
    const storageData = await chrome.storage.local.get('tyToken');
    console.log('Background: Storage data:', storageData);
    
    let tyToken = storageData.tyToken;
    if (!tyToken) {
      console.error('Background: tyToken storage\'da bulunamadı!');
      console.error('Background: Storage içeriği:', JSON.stringify(storageData));
      throw new Error('Trendyol token bulunamadı. Lütfen önce token ile giriş yapın.');
    }
    
    console.log('Background: Access token alındı:', tyToken.substring(0, 30) + '...');
    const token = tyToken;

    // 3. Generate device info and headers
    const device = getOrCreateDeviceInfo();
    
    // Generate device signals (async function)
    console.log('Background: Device signals oluşturuluyor...');
    const { payload, signature, timestamp } = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    console.log('Background: Device signals oluşturuldu, payload:', payload);
    console.log('Background: Signature:', signature.substring(0, 50) + '...');
    
    // Generate random IDs
    const deviceId = generateUUID();
    const uniqueId = generateRandomHex(16);
    const tyUniqueId = generateUUID();
    const sessionId = generateUUID();
    const processId = generateUUID();
    const tpaydid = generateUUID();
    
    // Generate segments (from real captured requests)
    const segments = "410750033_generic_6,410750050_1_6,278500001_1753975821420,278500001_1764162914545,278500001_1764163821920,278500001_1754397916073,278500001_1759307428295,278500001_1747050329340,410750032_coupon_6,410750245_donemmeyve3aralikic_6,410750245_donemmeyve3aralikic1_6,278500001_1709048753408,278500001_1765377989358,278500001_1765377978691,278500001_1765798226726,278500001_1764856830345,278500001_1766559756200,278500001_1766066429506,410750284_a101lansmanhl_6,278500001_1767078916829,410750721_meal_nursery__01-2026__01-2026,278500001_1767188773735,410750284_150tlmarkethl_6,410750284_donemkahvakti1ocak_6,410750284_donematistir2ocak_6,278500001_a101all,410750245_grpceryyilbasi_6,410750245_grpceryyilbasigo_6,410750284_donematistirmalik9ocak_6,410750284_donemkahvalti10ocak_6"

    // 4. Pre-requests before coupon code application
    console.log('Background: Kupon kodundan önce pre-request\'ler gönderiliyor...');
    
    // 4.1 Get Addresses
    console.log('Background: 1/3 - Adres listesi alınıyor...');
    
    // Her request için yeni device signals oluştur
    const addressSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    console.log('Background: Address request için device signals oluşturuldu');
    
    const addressUrl = 'https://api.tgoapis.com/localcommerce-member-zeususer-service/addresses?getCities=false&appName=TrendyolGo&channelId=3';
    const addressHeaders = {
      'Host': 'api.tgoapis.com',
      'Deviceid': deviceId,
      'Bff-Token-Validation': 'true',
      'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
      'X-Application-Id': '5',
      'Cl_eligible': 'false',
      'Sid': sessionId,
      'Pid': processId,
      'Build': '1.45.4.164',
      'Platform': 'Android',
      'Device-Language': 'tr',
      'Osversion': '9',
      'Isemulator': 'false',
      'X-Channelid': '4', // Changed from 3 to 4
      'X-Device-Signals-Payload': addressSignals.payload,
      'X-Device-Signals-Signature': addressSignals.signature,
      'Uniqueid': uniqueId,
      'Tpaydid': tpaydid,
      'Accept-Language': 'tr-TR',
      'X-Storefront-Id': '1',
      'Searchsegment': '20', // Changed from 9 to 20
      'Gender': 'M',
      'X-Visitor-Type': '4',
      'Segments': segments,
      'App-Name': 'TrendyolGo',
      'Lc-Member': 'true',
      'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
      'Authorization': `bearer ${token}`
    };

    let addressId = null;
    let latitude = null;  // Default values
    let longitude = null;
    
    try {
      const addressResponse = await fetch(addressUrl, { method: 'GET', headers: addressHeaders });
      const addressData = await addressResponse.json();
      console.log('Background: Adres yanıtı:', addressResponse.status);
      
      if (addressData && addressData.addresses && addressData.addresses.length > 0) {
        const activeAddress = addressData.addresses[0];
        addressId = activeAddress.addressId;
        latitude = activeAddress.lat;
        longitude = activeAddress.lon;
      } else if (addressData && Array.isArray(addressData) && addressData.length > 0) {
        const activeAddress = addressData[0];
        addressId = activeAddress.addressId || activeAddress.id;
        latitude = activeAddress.lat;
        longitude = activeAddress.lon;
      }
      console.log('Background: Adres ID:', addressId);
      console.log('Background: Latitude:', latitude, 'Longitude:', longitude);
    } catch (error) {
      console.warn('Background: Adres alınamadı, devam ediliyor:', error.message);
    }

    // 4.2 Send Shipping Info (if addressId exists)
    if (addressId) {
      console.log('Background: 2/3 - Shipping bilgisi gönderiliyor...');
      
      // Shipping için yeni device signals
      const shippingSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
      console.log('Background: Shipping request için device signals oluşturuldu');
      
      const shippingUrl = 'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/shipping';
      const shippingHeaders = {
        'Host': 'api.tgoapis.com',
        'Deviceid': deviceId,
        'Bff-Token-Validation': 'true',
        'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED',
        'X-Application-Id': '5',
        'Cl_eligible': 'false',
        'Sid': sessionId,
        'Pid': processId,
        'Build': '1.45.4.164',
        'Platform': 'Android',
        'Device-Language': 'tr',
        'Osversion': '9',
        'Isemulator': 'false',
        'X-Channelid': '3',
        'X-Device-Signals-Payload': shippingSignals.payload,
        'X-Device-Signals-Signature': shippingSignals.signature,
        'Uniqueid': uniqueId,
        'Tpaydid': tpaydid,
        'Accept-Language': 'tr-TR',
        'X-Storefront-Id': '1',
        'Searchsegment': '9',
        'Gender': 'F',
        'X-Visitor-Type': '4',
        'Segments': segments,
        'App-Name': 'TrendyolGo',
        'Lc-Member': 'true',
        'Ty-Uniqueid': tyUniqueId,
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
        'Authorization': `bearer ${token}`,
        'Content-Type': 'application/json; charset=UTF-8'
      };
      
      const shippingBody = JSON.stringify({
        "invoiceAddressId": addressId,
        "shippingAddressId": addressId,
        "latitude": latitude,
        "longitude": longitude
      });

      try {
        const shippingResponse = await fetch(shippingUrl, { method: 'POST', headers: shippingHeaders, body: shippingBody });
        console.log('Background: Shipping yanıtı:', shippingResponse.status);
      } catch (error) {
        console.warn('Background: Shipping gönderilemedi, devam ediliyor:', error.message);
      }
    }

    // 4.3 Merge Cart
    console.log('Background: 3/5 - Sepet merge ediliyor...');
    
    // Merge için yeni device signals
    const mergeSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    console.log('Background: Merge request için device signals oluşturuldu');
    
    const mergeUrl = 'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/merge?shouldFetchCart=false&cityId=105&districtId=15';
    const mergeHeaders = {
      'Host': 'api.tgoapis.com',
      'Deviceid': deviceId,
      'Bff-Token-Validation': 'true',
      'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED',
      'X-Application-Id': '5',
      'Cl_eligible': 'false',
      'Sid': sessionId,
      'Pid': processId,
      'Build': '1.45.4.164',
      'Platform': 'Android',
      'Device-Language': 'tr',
      'Osversion': '9',
      'Isemulator': 'false',
      'X-Channelid': '3',
      'Content-Type': 'application/json',
      'X-Device-Signals-Payload': mergeSignals.payload,
      'X-Device-Signals-Signature': mergeSignals.signature,
      'Uniqueid': uniqueId,
      'Tpaydid': tpaydid,
      'Accept-Language': 'tr-TR',
      'X-Storefront-Id': '1',
      'Searchsegment': '9',
      'Gender': 'F',
      'X-Visitor-Type': '4',
      'Segments': segments,
      'App-Name': 'TrendyolGo',
      'Lc-Member': 'true',
      'Ty-Uniqueid': tyUniqueId,
      'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
      'Authorization': `bearer ${token}`
    };

    try {
      const mergeResponse = await fetch(mergeUrl, { method: 'POST', headers: mergeHeaders, body: '' });
      console.log('Background: Merge yanıtı:', mergeResponse.status);
    } catch (error) {
      console.warn('Background: Merge gönderilemedi, devam ediliyor:', error.message);
    }

    // 4.4 Get Cart
    console.log('Background: 4/5 - Sepet bilgisi alınıyor...');
    
    // Cart için yeni device signals
    const cartSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    console.log('Background: Cart request için device signals oluşturuldu');
    
    const cartUrl = 'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts?isDeliveryPriceProgressActive=true&isFlashSale=true&cityId=105&districtId=5&appName=TrendyolGo&lat=39.99518&lon=32.760481&channelId=3';
    const cartHeaders = {
      'Host': 'api.tgoapis.com',
      'Deviceid': deviceId,
      'Bff-Token-Validation': 'true',
      'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
      'X-Application-Id': '5',
      'Cl_eligible': 'false',
      'Sid': sessionId,
      'Pid': processId,
      'Build': '1.45.4.164',
      'Platform': 'Android',
      'Device-Language': 'tr',
      'Osversion': '9',
      'Isemulator': 'false',
      'X-Channelid': '4',
      'Content-Type': 'application/json',
      'X-Device-Signals-Payload': cartSignals.payload,
      'X-Device-Signals-Signature': cartSignals.signature,
      'Uniqueid': uniqueId,
      'Tpaydid': tpaydid,
      'Accept-Language': 'tr-TR',
      'X-Storefront-Id': '1',
      'Searchsegment': '9',
      'Gender': 'F',
      'X-Visitor-Type': '4',
      'Segments': segments,
      'App-Name': 'TrendyolGo',
      'Lc-Member': 'true',
      'Ty-Uniqueid': tyUniqueId,
      'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
      'Authorization': `bearer ${token}`
    };

    try {
      const cartResponse = await fetch(cartUrl, { method: 'GET', headers: cartHeaders });
      console.log('Background: Sepet yanıtı:', cartResponse.status);
    } catch (error) {
      console.warn('Background: Sepet getirilemedi, devam ediliyor:', error.message);
    }

    // 4.5 Get Coupons
    console.log('Background: 5/5 - Kupon listesi alınıyor...');
    
    // Coupons için yeni device signals
    const couponsSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    console.log('Background: Coupons request için device signals oluşturuldu');
    
    const couponsUrl = 'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/coupons?appName=TrendyolGo&channelId=4';
    const couponsHeaders = {
      'Host': 'api.tgoapis.com',
      'Deviceid': deviceId,
      'Bff-Token-Validation': 'true',
      'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
      'X-Application-Id': '5',
      'Cl_eligible': 'false',
      'Sid': sessionId,
      'Pid': processId,
      'Build': '1.45.4.164',
      'Platform': 'Android',
      'Device-Language': 'tr',
      'Osversion': '9',
      'Isemulator': 'false',
      'X-Channelid': '4',
      'Content-Type': 'application/json',
      'X-Device-Signals-Payload': couponsSignals.payload,
      'X-Device-Signals-Signature': couponsSignals.signature,
      'Uniqueid': uniqueId,
      'Tpaydid': tpaydid,
      'Accept-Language': 'tr-TR',
      'X-Storefront-Id': '1',
      'Searchsegment': '9',
      'Gender': 'F',
      'X-Visitor-Type': '4',
      'Segments': segments,
      'App-Name': 'TrendyolGo',
      'Lc-Member': 'true',
      'Ty-Uniqueid': tyUniqueId,
      'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
      'Authorization': `bearer ${token}`
    };

    try {
      const couponsResponse = await fetch(couponsUrl, { method: 'GET', headers: couponsHeaders });
      console.log('Background: Coupons yanıtı:', couponsResponse.status);
    } catch (error) {
      console.warn('Background: Coupons getirilemedi, devam ediliyor:', error.message);
    }

    console.log('Background: Pre-request\'ler tamamlandı, kupon kodu uygulanıyor...');

    // Kupon kodu için yeni device signals
    const couponSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    console.log('Background: Coupon request için device signals oluşturuldu');

    // 5. Apply Coupon Code
    const headers = {
      'Host': 'api.tgoapis.com',
      'Deviceid': deviceId,
      'Bff-Token-Validation': 'true',
      'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
      'X-Application-Id': '5',
      'Cl_eligible': 'false',
      'Sid': sessionId,
      'Pid': processId,
      'Build': '1.45.4.164',
      'Platform': 'Android',
      'Device-Language': 'tr',
      'Osversion': '9',
      'Isemulator': 'false',
      'X-Channelid': '4',
      'X-Device-Signals-Payload': couponSignals.payload,
      'X-Device-Signals-Signature': couponSignals.signature,
      'Uniqueid': uniqueId,
      'Tpaydid': tpaydid,
      'Accept-Language': 'tr-TR',
      'X-Storefront-Id': '1',
      'Searchsegment': '9',
      'Gender': 'F',
      'X-Visitor-Type': '4',
      'Segments': segments,
      'App-Name': 'TrendyolGo',
      'Lc-Member': 'true',
      'Ty-Uniqueid': tyUniqueId,
      'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
      'Authorization': `bearer ${token}`,
      'Content-Type': 'application/json; charset=UTF-8'
    };

    const fetchOptions = {
      method: request.method || 'POST',
      headers: headers,
      body: request.body
    };

    // Use the correct endpoint for code promotions
    const couponUrl = 'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/code-promotions';
    console.log('Background: TY Proxy kupon isteği gönderiliyor:', couponUrl);

    let response;
    try {
      response = await fetch(couponUrl, fetchOptions);
    } catch (fetchError) {
      console.error('Background: TY Proxy fetch hatası:', fetchError);
      throw new Error(`Fetch failed: ${fetchError.message}`);
    }

    const responseHeaders = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key.toLowerCase()] = value;
    });

    let data;
    try {
      data = await response.text();
    } catch (textError) {
      console.error('Background: Response text okuma hatası:', textError);
      data = '';
    }

    console.log('Background: TY Proxy yanıtı alındı:', response.status);

    sendResponse({
      success: true,
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      data: data
    });

  } catch (error) {
    console.error('Background: TY Proxy istek hatası:', error);
    console.error('Background: Hata detayı:', {
      message: error.message,
      name: error.name,
      stack: error.stack,
      url: request.url,
      method: request.method
    });
    sendResponse({
      success: false,
      error: error.message || 'Bilinmeyen hata',
      headers: {}
    });
  }
}

// Trendyol Cart Items Request Handler (sepete ürün eklerken addresses ve shipping gönder)
async function handleTyCartItemsRequest(request, sendResponse) {
  try {
    console.log('Background: handleTyCartItemsRequest başladı, URL:', request.url);
    
    if (!request.url) {
      throw new Error('URL eksik');
    }

    // Storage'dan token al
    const storageData = await chrome.storage.local.get('tyToken');
    let tyToken = storageData.tyToken;
    if (!tyToken) {
      throw new Error('Trendyol token bulunamadı.');
    }
    
    const token = tyToken;
    const device = getOrCreateDeviceInfo();
    
    // Random IDs
    const deviceId = generateUUID();
    const uniqueId = generateRandomHex(16);
    const tyUniqueId = generateUUID();
    const sessionId = generateUUID();
    const processId = generateUUID();
    const tpaydid = generateUUID();
    
    const segments = '410750033_generic_6,410750050_1_6,278500001_1753975821420,278500001_1764162914545,278500001_1764163821920,278500001_1754397916073,278500001_1759307428295,278500001_1747050329340,410750032_coupon_6,410750245_donemmeyve3aralikic_6,410750245_donemmeyve3aralikic1_6,278500001_1709048753408,278500001_1765377989358,278500001_1765377978691,278500001_1765798226726,278500001_1764856830345,278500001_1766559756200,278500001_1766066429506,410750284_a101lansmanhl_6,278500001_1767078916829,410750721_meal_nursery__01-2026__01-2026,278500001_1767188773735,410750284_150tlmarkethl_6,410750284_donemkahvakti1ocak_6,410750284_donematistir2ocak_6,278500001_a101all,410750245_grpceryyilbasi_6,410750245_grpceryyilbasigo_6,410750284_donematistirmalik9ocak_6,410750284_donemkahvalti10ocak_6';

    // Addresses al
    console.log('Background: Adres alınıyor...');
    
    // Address request için device signals
    const addressSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    console.log('Background: Address request için device signals oluşturuldu');
    
    const addressUrl = 'https://api.tgoapis.com/localcommerce-member-zeususer-service/addresses?getCities=false&appName=TrendyolGo&channelId=3';
    const addressHeaders = {
      'Host': 'api.tgoapis.com',
      'Deviceid': deviceId,
      'Bff-Token-Validation': 'true',
      'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
      'X-Application-Id': '5',
      'Cl_eligible': 'false',
      'Sid': sessionId,
      'Pid': processId,
      'Build': '1.45.4.164',
      'Platform': 'Android',
      'Device-Language': 'tr',
      'Osversion': '9',
      'Isemulator': 'false',
      'X-Channelid': '3',
      'Content-Type': 'application/json',
      'X-Device-Signals-Payload': addressSignals.payload,
      'X-Device-Signals-Signature': addressSignals.signature,
      'Uniqueid': uniqueId,
      'Tpaydid': tpaydid,
      'Accept-Language': 'tr-TR',
      'X-Storefront-Id': '1',
      'Searchsegment': '9',
      'Gender': 'F',
      'X-Visitor-Type': '4',
      'Segments': segments,
      'App-Name': 'TrendyolGo',
      'Lc-Member': 'true',
      'Ty-Uniqueid': tyUniqueId,
      'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
      'Authorization': `bearer ${token}`
    };

    let addressId = null;
    let latitude = null;
    let longitude = null;
    
    try {
      const addressResponse = await fetch(addressUrl, { method: 'GET', headers: addressHeaders });
      const addressData = await addressResponse.json();
      if (addressData && addressData.addresses && addressData.addresses.length > 0) {
        const activeAddress = addressData.addresses[0];
        addressId = activeAddress.addressId;
        latitude = activeAddress.lat;
        longitude = activeAddress.lon;
      }
      console.log('Background: Adres ID:', addressId);
      console.log('Background: Latitude:', latitude, 'Longitude:', longitude);
    } catch (error) {
      console.warn('Background: Adres alınamadı:', error.message);
    }

    // Shipping gönder
    if (addressId) {
      console.log('Background: Shipping gönderiliyor...');
      
      // Shipping request için yeni device signals
      const shippingSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
      console.log('Background: Shipping request için device signals oluşturuldu');
      
      const shippingUrl = 'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/shipping';
      const shippingHeaders = {
        'Host': 'api.tgoapis.com',
        'Deviceid': deviceId,
        'Bff-Token-Validation': 'true',
        'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
        'X-Application-Id': '5',
        'Cl_eligible': 'false',
        'Sid': sessionId,
        'Pid': processId,
        'Build': '1.45.4.164',
        'Platform': 'Android',
        'Device-Language': 'tr',
        'Osversion': '9',
        'Isemulator': 'false',
        'X-Channelid': '3',
        'X-Device-Signals-Payload': shippingSignals.payload,
        'X-Device-Signals-Signature': shippingSignals.signature,
        'Uniqueid': uniqueId,
        'Tpaydid': tpaydid,
        'Accept-Language': 'tr-TR',
        'X-Storefront-Id': '1',
        'Searchsegment': '9',
        'Gender': 'F',
        'X-Visitor-Type': '4',
        'Segments': segments,
        'App-Name': 'TrendyolGo',
        'Lc-Member': 'true',
        'Ty-Uniqueid': tyUniqueId,
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
        'Authorization': `bearer ${token}`,
        'Content-Type': 'application/json; charset=UTF-8'
      };
      
      const shippingBody = JSON.stringify({
        "invoiceAddressId": addressId,
        "shippingAddressId": addressId,
        "latitude": latitude,
        "longitude": longitude
      });

      try {
        await fetch(shippingUrl, { 
          method: 'POST', 
          headers: shippingHeaders, 
          body: shippingBody 
        });
        console.log('Background: Shipping gönderildi');
      } catch (error) {
        console.warn('Background: Shipping gönderilemedi:', error.message);
      }
    }

    // Sepete ürün ekle
    console.log('Background: Sepete ürün ekleniyor...');
    
    // Cart items request için yeni device signals
    const cartItemsSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    console.log('Background: Cart items request için device signals oluşturuldu');
    
    const headers = {
      'Host': 'api.tgoapis.com',
      'Deviceid': deviceId,
      'Bff-Token-Validation': 'true',
      'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
      'X-Application-Id': '5',
      'Cl_eligible': 'false',
      'Sid': sessionId,
      'Pid': processId,
      'Build': '1.45.4.164',
      'Platform': 'Android',
      'Device-Language': 'tr',
      'Osversion': '9',
      'Isemulator': 'false',
      'X-Channelid': '4',
      'X-Device-Signals-Payload': cartItemsSignals.payload,
      'X-Device-Signals-Signature': cartItemsSignals.signature,
      'Uniqueid': uniqueId,
      'Tpaydid': tpaydid,
      'Accept-Language': 'tr-TR',
      'X-Storefront-Id': '1',
      'Searchsegment': '9',
      'Gender': 'F',
      'X-Visitor-Type': '4',
      'Segments': segments,
      'App-Name': 'TrendyolGo',
      'Lc-Member': 'true',
      'Ty-Uniqueid': tyUniqueId,
      'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
      'Authorization': `bearer ${token}`,
      'Content-Type': 'application/json; charset=UTF-8'
    };

    const response = await fetch(request.url, {
      method: request.method || 'POST',
      headers: headers,
      body: request.body
    });

    const responseHeaders = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key.toLowerCase()] = value;
    });

    const data = await response.text();
    console.log('Background: Sepete ürün eklendi:', response.status);

    sendResponse({
      success: true,
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      data: data
    });

  } catch (error) {
    console.error('Background: Cart Items hatası:', error);
    sendResponse({
      success: false,
      error: error.message || 'Bilinmeyen hata',
      headers: {}
    });
  }
}
