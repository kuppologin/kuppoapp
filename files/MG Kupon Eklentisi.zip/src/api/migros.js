// Bu dosya, Migros API'si ile ilgili tüm ağ isteklerini ve kupon
// doğrulama/uygulama mantığını içerir.

'use strict';

// Kupon listesini API'den çeken fonksiyon
async function fetchCoupons(service) {
  try {
    // Sipariş ID'sini URL'den al
    const pathMatch = window.location.pathname.match(/\/(yemek|hemen)?\/siparis\/odeme\/(\d+)/);
    if (!pathMatch || !pathMatch[2]) {
      console.error('Sipariş ID URL\'den alınamadı:', window.location.pathname);
      return [];
    }
    
    const checkoutId = pathMatch[2];
    console.log('Sipariş ID (checkoutId):', checkoutId);
    
    // Şu anki timestamp oluştur (19 karakter uzunluğunda)
    const timestamp = Date.now().toString() + Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
    
    // Servis tipine göre uygun API endpoint'ini kullan
    let endpoint;
    switch (service) {
      case 'yemek':
        endpoint = `/yemek/checkouts/${checkoutId}/discounts/applicable?reid=${timestamp}`;
        break;
      case 'hemen':
        endpoint = `/hemen/checkouts/${checkoutId}/discounts/applicable?reid=${timestamp}`;
        break;
      default: // sanalmarket
        endpoint = `/checkouts/${checkoutId}/discounts/applicable?reid=${timestamp}`;
        break;
    }
    
    console.log(`Fetching coupons from: ${endpoint}`);
    
    // ProxyRequest kullanarak background.js üzerinden istek yap
    const requestId = Date.now() + Math.random().toString().substring(2, 8);
    window.migrosKupon.fetchCallbacks = window.migrosKupon.fetchCallbacks || {};
    
    // Yanıt beklemek için bir Promise oluştur
    const responsePromise = new Promise((resolve, reject) => {
      window.migrosKupon.fetchCallbacks[requestId] = (response) => {
        if (response && response.success) {
          resolve(response.data);
        } else {
          reject(new Error(response ? response.error : 'Bilinmeyen hata'));
        }
        delete window.migrosKupon.fetchCallbacks[requestId];
      };
    });
    
    // İsteği postMessage ile gönder
    window.postMessage({
      source: 'MIGROS_KUPON_EXTENSION',
      action: 'proxyRequest',
      requestId: requestId,
      url: `https://rest.migros.com.tr${endpoint}`,
      method: 'POST',
      headers: {
        'accept': 'application/json',
        'content-type': 'application/json',
        'x-forwarded-rest': 'true'
      },
      body: JSON.stringify({ "bagSelected": true })
    }, '*');
    
    // Yanıtı bekle
    const responseData = await responsePromise;
    const data = JSON.parse(responseData);
    console.log('Raw coupon data:', data);
    
    // Data yapısını kontrol et
    let coupons = [];
    if (data && data.successful && Array.isArray(data.data)) {
      // Yeni API yapısı - doğrudan data dizisi olarak geliyor
      coupons = data.data;
    } else if (data && Array.isArray(data.discounts)) {
      // Alternatif yeni API yapısı
      coupons = data.discounts;
    } else if (data && typeof data === 'object' && !Array.isArray(data)) {
      // Eski API yapıları
      if (Array.isArray(data.availableDiscounts)) {
        coupons = data.availableDiscounts;
      } else if (Array.isArray(data.discountResults)) {
        coupons = data.discountResults;
      } else if (Array.isArray(data.data?.availableDiscounts)) {
        coupons = data.data.availableDiscounts;
      }
    }

    if (!Array.isArray(coupons)) {
      console.error('Beklenen kupon dizisi alınamadı:', coupons);
      coupons = [];
    }

    // Şu an geçerli olan kuponları filtrele
    const now = Date.now();
    const validCoupons = coupons.filter(coupon => {
      const startDate = coupon.startDate ? new Date(coupon.startDate).getTime() : 0;
      const finishDate = coupon.finishDate ? new Date(coupon.finishDate).getTime() : Infinity;
      const isValidDate = startDate <= now && finishDate >= now;
      // İndirim miktarını discountAmount olarak kontrol et (yeni API'de bu şekilde)
      const discountValue = coupon.discountValue || coupon.discountAmount;
      const hasRequiredInfo = coupon.id && coupon.name && discountValue;
      return isValidDate && hasRequiredInfo;
    });

    console.log('Valid coupons found:', validCoupons.length);
    return validCoupons;
  } catch (error) {
    console.error('Kupon listesi alınırken hata:', error);
    return [];
  }
}

// Kupon doğrulama fonksiyonu - kupon kodu veya ID ile
async function validateCoupon(service, couponCode, checkoutId, couponId = null) {
    try {
        const endpoint = `${getApiBaseUrl(service)}/checkouts/${checkoutId}/discounts/checks`;

        // Eğer kuponId varsa direk o ID ile validation yap, yoksa kupon kodu ile
        const body = couponId
            ? { "campaignType": "COUPON", "bagSelected": true, "deliveryProvider": "NONE", "paymentType": "CREDIT_CARD", "discountId": couponId } // Diğer parametreler sorun çıkarabilir, sadeleştirelim
            : { "campaignType": "COUPON", "bagSelected": true, "deliveryProvider": "NONE", "paymentType": "CREDIT_CARD", "couponCode": couponCode };

        console.log('Kupon doğrulama isteği:', endpoint, JSON.stringify(body));
        
        // ProxyRequest kullanarak background.js üzerinden istek yap
        const requestId = Date.now() + Math.random().toString().substring(2, 8);
        window.migrosKupon.fetchCallbacks = window.migrosKupon.fetchCallbacks || {};
        
        // Yanıt beklemek için bir Promise oluştur
        const responsePromise = new Promise((resolve, reject) => {
          window.migrosKupon.fetchCallbacks[requestId] = (response) => {
            if (response && response.success) {
              resolve(response.data);
            } else {
              reject(new Error(response ? response.error : 'Bilinmeyen hata'));
            }
            delete window.migrosKupon.fetchCallbacks[requestId];
          };
        });
        
        // İsteği postMessage ile gönder
        window.postMessage({
          source: 'MIGROS_KUPON_EXTENSION',
          action: 'proxyRequest',
          requestId: requestId,
          url: `https://rest.migros.com.tr${endpoint}`,
          method: 'POST',
          headers: {
            'accept': 'application/json',
            'content-type': 'application/json',
            'x-forwarded-rest': 'true'
          },
          body: JSON.stringify(body)
        }, '*');
        
        // Yanıtı bekle
        const responseData = await responsePromise;
        const data = JSON.parse(responseData);
        console.log('Kupon doğrulama sonucu (tam):', JSON.stringify(data));

        if (!data.successful) {
            // Detaylı hata mesajı oluştur
            let detailedErrorMsg = '';
            
            if (typeof data.errorDetail === 'string') {
                // errorDetail doğrudan string olarak gelmiş
                detailedErrorMsg = data.errorDetail;
            } else if (data.errorDetail?.detailMessage) {
                // errorDetail bir nesne ve detailMessage içeriyor
                detailedErrorMsg = data.errorDetail.detailMessage;
            } else if (data.errorDetail?.message) {
                // errorDetail bir nesne ve message içeriyor
                detailedErrorMsg = data.errorDetail.message;
            } else if (data.message) {
                // Doğrudan message alanı varsa
                detailedErrorMsg = data.message;
            } else {
                // Hiçbir anlamlı hata mesajı yoksa
                detailedErrorMsg = 'Bilinmeyen doğrulama hatası';
            }
            
            // Hata kodu ve başlık bilgilerini ekle
            if (data.errorCode || data.errorTitle) {
                detailedErrorMsg += '\n\nDetaylı Hata Bilgisi:';
                
                if (data.errorCode) {
                    detailedErrorMsg += `\nHata Kodu: ${data.errorCode}`;
                }
                
                if (data.errorTitle) {
                    detailedErrorMsg += `\nHata Başlığı: ${data.errorTitle}`;
                }
            }
            
            // Kupon detaylarını kontrol et ve varsa ekle
            if (data.data && data.data.details) {
                // HTML formatındaki detayları temizle
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = data.data.details;
                const plainText = tempDiv.textContent || tempDiv.innerText || '';
                
                detailedErrorMsg += '\n\nKupon Detayları:\n' + plainText;
            }
            
            console.error('Kupon doğrulama başarısız:', detailedErrorMsg);
            showMessage(detailedErrorMsg, 'Kupon Doğrulanamadı', 'error');
            return null;
        }

        const resultData = data.data;
        
        // Çakışma durumu kontrolü - response'da hasConflict true ise
        if (resultData && resultData.hasConflict === true) {
            console.log('Kupon çakışması tespit edildi:', resultData);
            
            // Kupon çakışma seçim popup'ını oluştur
            const popupContainer = createPopup();
            
            // Popup başlık ve içeriğini ayarla
            const popupTitle = popupContainer.querySelector('#migros-popup-title');
            const popupContent = popupContainer.querySelector('#migros-popup-content');
            const popupButtons = popupContainer.querySelector('#migros-popup-buttons');
            
            popupTitle.textContent = 'Kupon Çakışması';
            
            // Kullanıcıya anlaşılır bir mesaj göster
            const newDiscountValue = resultData.discountAmountLabel || '?? TL indirim';
            const oldDiscountValue = resultData.removableDiscountAmountLabel || '?? TL indirim';
            const oldDiscountType = resultData.removableDiscountType || 'indirim';
            
            popupContent.innerHTML = `
                <p style="margin: 0 0 14px 0; color: #6b7280;">Yeni kupon uygulamak için mevcut indirimi kaldırmanız gerekiyor.</p>
                <div style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 14px;">
                    <div style="background: linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 100%); border: 1px solid #bbf7d0; border-radius: 10px; padding: 12px 14px; display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-weight: 600; color: #16a34a; font-size: 13px;">Yeni Kupon</span>
                        <span style="font-weight: 700; color: #16a34a; font-size: 14px;">${newDiscountValue}</span>
                    </div>
                    <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 10px; padding: 12px 14px; display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-weight: 600; color: #6b7280; font-size: 13px;">Mevcut ${oldDiscountType}</span>
                        <span style="font-weight: 700; color: #374151; font-size: 14px;">${oldDiscountValue}</span>
                    </div>
                </div>
                <p style="margin: 0; color: #374151; font-weight: 500; font-size: 13px;">Hangi indirimi uygulamak istersiniz?</p>
            `;
            
            // Butonları düzenle
            popupButtons.innerHTML = '';
            
            // Promise için resolve fonksiyonu
            let resolvePromise;
            const conflictPromise = new Promise(resolve => {
                resolvePromise = resolve;
            });
             
            // Mevcut indirimi koru butonu
            const keepOldButton = document.createElement('button');
            keepOldButton.className = 'secondary';
            keepOldButton.textContent = 'Mevcut İndirimi Koru';
            keepOldButton.onclick = () => {
                // Popup'ı kapat
                popupContainer.classList.remove('visible');
                setTimeout(() => {
                    if (popupContainer.parentNode) {
                        popupContainer.parentNode.removeChild(popupContainer);
                    }
                }, 300);
                
                // Promise'ı çöz - mevcut indirimi koruyoruz
                resolvePromise({ hasConflict: true, message: 'Mevcut indirim korundu', cancelled: true });
            };
            
            // Yeni kuponu uygula butonu
            const applyNewButton = document.createElement('button');
            applyNewButton.className = 'primary';
            applyNewButton.textContent = 'Yeni Kuponu Uygula';
            
            // Yeni kupon için çakışma çözme API'sine istek
            applyNewButton.onclick = async () => {
                // Popup'ı kapat
                popupContainer.classList.remove('visible');
                setTimeout(() => {
                    if (popupContainer.parentNode) {
                        popupContainer.parentNode.removeChild(popupContainer);
                    }
                }, 300);
                
                try {
                    // Kaldırılacak indirim tutarını kaydet
                    if (resultData.removableDiscountAmountLabel) {
                        try {
                            // "100,00 TL indirim" formatından sadece sayısal değeri al
                            const priceStr = resultData.removableDiscountAmountLabel.replace(/[^0-9,]+/g, "").replace(",", ".");
                            const removableAmount = parseFloat(priceStr) * 100; // TL'den kuruş'a çevir
                            
                            if (!isNaN(removableAmount)) {
                                // Global değişkenlere kaydet
                                window.migrosKupon.conflictResolution = true;
                                window.migrosKupon.removableDiscountAmount = removableAmount;
                                console.log('Kaldırılacak indirim miktarı kaydedildi:', removableAmount, 'kuruş');
                            }
                        } catch(e) {
                            console.error('Kaldırılacak indirim miktarı işlenirken hata:', e);
                        }
                    }
                    // "checkouts/resolve-conflict" endpoint'ine istek hazırla
                    const timestamp = Date.now().toString() + Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
                    
                    // Endpoint oluştur
                    let endpoint;
                    switch (service) {
                        case 'yemek':
                            endpoint = `/yemek/checkouts/${checkoutId}/discounts/resolve-conflict?reid=${timestamp}`;
                            break;
                        case 'hemen':
                            endpoint = `/hemen/checkouts/${checkoutId}/discounts/resolve-conflict?reid=${timestamp}`;
                            break;
                        default: // sanalmarket
                            endpoint = `/checkouts/${checkoutId}/discounts/resolve-conflict?reid=${timestamp}`;
                            break;
                    }
                    
                    console.log(`Çakışma çözme isteği gönderiliyor: ${endpoint}`);
                    
                    // ProxyRequest kullanarak isteği gönder
                    const requestId = Date.now() + Math.random().toString().substring(2, 8);
                    window.migrosKupon.fetchCallbacks = window.migrosKupon.fetchCallbacks || {};
                    
                    // Yanıt beklemek için Promise
                    const apiPromise = new Promise((resolve, reject) => {
                        window.migrosKupon.fetchCallbacks[requestId] = (response) => {
                            if (response && response.success) {
                                resolve(response.data);
                            } else {
                                reject(new Error(response ? response.error : 'Bilinmeyen hata'));
                            }
                            delete window.migrosKupon.fetchCallbacks[requestId];
                        };
                    });
                    
                    // İsteği gönder - Önemli: discountId olarak resultData.discountId kullanılmalı
                    window.postMessage({
                        source: 'MIGROS_KUPON_EXTENSION',
                        action: 'proxyRequest',
                        requestId: requestId,
                        url: `https://rest.migros.com.tr${endpoint}`,
                        method: 'POST',
                        headers: {
                            'accept': 'application/json',
                            'content-type': 'application/json',
                            'x-forwarded-rest': 'true'
                        },
                        body: JSON.stringify({
                            "campaignType": "COUPON", 
                            "bagSelected": true, 
                            "deliveryProvider": "NONE", 
                            "paymentType": "CREDIT_CARD", 
                            "discountId": resultData.discountId
                        })
                    }, '*');
                    
                    // Yanıtı bekle
                    const resolveResponseData = await apiPromise;
                    const resolveData = JSON.parse(resolveResponseData);
                    console.log('Çakışma çözme sonucu:', resolveData);
                    
                    if (resolveData.successful) {
                        // Başarılı yanıttan sonra kupon uygulanacak
                        // Çok önemli: discountId üst seviyede, kaydedelim
                        if (resolveData.data && resolveData.data.discountId) {
                            // discountId'yi global değişkene kaydet
                            window.migrosKupon.validDiscountId = resolveData.data.discountId;
                            console.log('Çakışma çözümünden validDiscountId alındı:', resolveData.data.discountId);
                        }
                        
                        // Burada resolve-conflict API'sinden dönen veriyi kullan
                        if (resolveData.data && resolveData.data.discountResult) {
                            // discountResult'a discountId ekleyelim
                            if (resolveData.data.discountId && resolveData.data.discountResult) {
                                resolveData.data.discountResult.id = resolveData.data.discountId;
                                resolveData.data.discountResult.discountId = resolveData.data.discountId;
                            }
                            resolvePromise(resolveData.data);
                        } else {
                            // API yanıtında beklenen veri yoksa orijinal veriyi kullan
                            resolvePromise(resultData);
                        }
                    } else {
                        // Hata durumunda mesaj göster
                        showMessage('Kupon çakışması çözülemedi: ' + 
                                    (resolveData.errorDetail?.message || resolveData.message || 'Bilinmeyen hata'),
                                   'Hata', 'error');
                        resolvePromise({ hasConflict: true, message: 'Çakışma çözülemedi', cancelled: true });
                    }
                } catch (error) {
                    console.error('Çakışma çözme hatası:', error);
                    showMessage(`Çakışma çözme hatası: ${error.message}`, 'Hata', 'error');
                    resolvePromise({ hasConflict: true, message: error.message, cancelled: true });
                }
            };
            
            // Butonları ekle
            popupButtons.appendChild(keepOldButton);
            popupButtons.appendChild(applyNewButton);
            
            // Popup'ı göster
            popupContainer.classList.add('visible');

            // Dışa tıklama ile kapatma
            popupContainer.addEventListener('click', function(e) {
                if (e.target === popupContainer) {
                    popupContainer.classList.remove('visible');
                    setTimeout(() => {
                        if (popupContainer.parentNode) {
                            popupContainer.parentNode.removeChild(popupContainer);
                        }
                    }, 300);
                    
                    // İşlem iptal edildi, çakışma çözülmedi
                    resolvePromise({ hasConflict: true, message: 'İşlem iptal edildi', cancelled: true });
                }
            });
            
            // X butonu ile kapatma
            popupContainer.querySelector('#migros-popup-close').addEventListener('click', function() {
                popupContainer.classList.remove('visible');
                setTimeout(() => {
                    if (popupContainer.parentNode) {
                        popupContainer.parentNode.removeChild(popupContainer);
                    }
                }, 300);
                
                // İşlem iptal edildi, çakışma çözülmedi
                resolvePromise({ hasConflict: true, message: 'İşlem iptal edildi', cancelled: true });
            });
            
            // Promise döndür
            return conflictPromise;
        }

        if (!resultData || !resultData.discountResult) {
             console.error('Doğrulama yanıtında beklenen `data.discountResult` yapısı bulunamadı.');
             showMessage('Kupon doğrulandı ancak beklenen veri yapısı alınamadı.', 'Veri Hatası', 'warning');
             return null; // Veya kısmi veriyle devam etmeyi dene? Şimdilik null dönelim.
        }
        // Yanıt "successful" olsa bile, actionDetails içinde hata olabilir
        if (resultData.discountResult.actionDetails && resultData.discountResult.actionDetails.actionTitle === "Kupon Uygulanamadı") {
            console.error('Kupon gerekli koşulları sağlamıyor:', resultData.discountResult.actionDetails);
            
            // Kullanıcıya anlamlı hata mesajlarını göster
            let errorMessage = "Kupon uygulanamadı: ";
            
            if (resultData.discountResult.actionDetails.actionMessages && resultData.discountResult.actionDetails.actionMessages.length > 0) {
                errorMessage += resultData.discountResult.actionDetails.actionMessages.join("\n• ");
            } else if (resultData.discountResult.actionDetails.actionDescription) {
                errorMessage += resultData.discountResult.actionDetails.actionDescription;
            }
            
            // Kupon detaylarını kontrol et ve varsa ekle
            if (resultData.discountResult.details) {
                // HTML formatındaki detayları temizle
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = resultData.discountResult.details;
                const plainText = tempDiv.textContent || tempDiv.innerText || '';
                
                errorMessage += '\n\nKupon Detayları:\n' + plainText;
            }
            
            showMessage(errorMessage, 'Kupon Geçersiz', 'warning');
            return { hasConflict: true, message: errorMessage };
        }
        
        // Eğer hasConflict varsa ve true ise zaten mevcut kontrol çalışacak
        
        // Yanıt içerisinden discountId'yi de kaydedelim (en güvenilir yer discountResult olabilir)
        const resolvedDiscountId = resultData.discountResult.id || resultData.discountResult.discountId || resultData.discountId || couponId;
        if (resolvedDiscountId) {
            window.migrosKupon.validDiscountId = resolvedDiscountId;
            console.log('Doğrulama sonrası `validDiscountId` kaydedildi:', resolvedDiscountId);
        } else {
             console.warn('Doğrulama yanıtından geçerli bir `discountId` çıkarılamadı.');
             // Orijinal ID'yi kullanmaya çalışalım
             if (couponId) {
                 window.migrosKupon.validDiscountId = couponId;
                 console.log('Orijinal `couponId` fallback olarak kullanıldı:', couponId);
             }
        }


         // Orijinal kupon ID'sini sonuçta sakla (eğer ID ile başlattıysak)
        if (couponId && resultData.discountResult) {
            resultData.discountResult.originalCouponId = couponId; // discountResult nesnesine ekleyelim
            window.migrosKupon.originalCouponId = couponId; // Globalde de tutalım
            console.log('Orijinal kupon ID (`originalCouponId`) kaydedildi:', couponId);
        }


        return resultData; // resultData'yı döndür, içinde discountResult var
    } catch (error) {
        console.error('Kupon doğrulanırken hata:', error);
        showMessage(`Bir hata oluştu: ${error.message}`, 'Hata', 'error');
        return null;
    }
}

// Kupon uygulama fonksiyonu (asenkron)
async function applyCouponAction(couponCode, couponId) {
    const checkoutIdMatch = window.location.pathname.match(/\/odeme(?:\/[\w-]+)*\/(\d+)/); // Daha esnek URL eşleşmesi
    if (!checkoutIdMatch || !checkoutIdMatch[1]) {
        console.error('Sipariş ID URL\'den alınamadı:', window.location.pathname);
        try {
            showMessage('Sipariş ID bulunamadı. Lütfen sayfanın doğru yüklendiğinden emin olun.', 'Hata', 'error');
        } catch (e) {
            console.error('Hata mesajı gösterilemedi:', e);
        }
        return false;
    }

    const checkoutId = checkoutIdMatch[1];
    console.log('Checkout ID:', checkoutId);

    const currentService = detectService();
    window.migrosKupon.currentService = currentService;

    if (!currentService) {
        try {
            showMessage('Servis tipi tespit edilemedi', 'Hata', 'error');
        } catch (e) {
            console.error('Hata mesajı gösterilemedi:', e);
        }
        return false;
    }
    console.log('Current service:', currentService);

    // Butonu devre dışı bırak
    const applyButton = document.querySelector('#migros-coupon-container .apply-coupon-button');
    if (applyButton) applyButton.disabled = true;

    try {
        const validationResult = await validateCoupon(currentService, couponCode, checkoutId, couponId);

        // Validasyon sonucunu kontrol et
        if (!validationResult) {
            // Hata mesajı zaten validateCoupon içinde gösterildi
            clearAppliedCouponUI();
            return false;
        }
        
        // Kupon çakışma sonucuna göre işlem yap
        if (validationResult.hasConflict) {
            // Kupon çakışması durumu - cancelled özelliği kontrolü
            if (validationResult.cancelled) {
                console.log('Kullanıcı kupon çakışmasını çözmeyi iptal etti.');
                clearAppliedCouponUI(); // UI'ı temizle
                return false;
            }
            
            // Eğer kullanıcı yeni kuponu seçtiyse ve çakışma çözüldüyse
            if (validationResult.discountResult) {
                // Çakışma çözüldü ve başarılı yanıt alındı
                try {
                    // DiscountId'yi önceden global değişkene kaydet (eger varsa)
                    if (validationResult.discountId) {
                        window.migrosKupon.validDiscountId = validationResult.discountId;
                        console.log('applyCouponAction: validDiscountId kaydedildi:', validationResult.discountId);
                    }
                
                    handleSuccessfulCouponApplication(validationResult.discountResult);
                    try {
                        showMessage('Kupon başarıyla uygulandı!', 'Başarılı', 'success');
                    } catch (e) {
                        console.log('Kupon başarıyla uygulandı!');
                    }
                    return true;
                } catch (e) {
                    console.error('Kuponu uygularken hata:', e);
                    // Hata olsa bile başarılı sayalım çünkü temel işlem yapılmış olabilir
                    return true;
                }
            } else {
                // Çakışma çözüldü ama hata oluştu veya API hata döndü
                try {
                    showMessage(`${validationResult.message || 'Kupon uygulanamadı.'}`, 'Kupon Uygulanamadı', 'warning');
                } catch (e) {
                    console.error('Hata mesajı gösterilemedi:', e);
                }
                clearAppliedCouponUI(); // UI'ı temizle
                return false;
            }
        } else if (validationResult.discountResult) {
            // Normal başarılı durum - çakışma yok
            try {
                handleSuccessfulCouponApplication(validationResult.discountResult);
                try {
                    showMessage('Kupon başarıyla uygulandı!', 'Başarılı', 'success');
                } catch (e) {
                    console.log('Kupon başarıyla uygulandı!');
                }
                return true;
            } catch (e) {
                console.error('Kuponu uygularken hata:', e);
                return true; // Hata olsa bile başarılı sayalım
            }
        } else {
            // Validasyon başarılı ama beklenen data yapısı yok
            try {
                showMessage('Kupon doğrulandı ancak uygulanamadı.', 'Hata', 'warning');
            } catch (e) {
                console.error('Hata mesajı gösterilemedi:', e);
            }
            clearAppliedCouponUI();
            return false;
        }
    } catch (mainError) {
        console.error('Kupon uygulama işleminde beklenmeyen hata:', mainError);
        try {
            showMessage('Kupon uygulanırken bir hata oluştu.', 'Hata', 'error');
        } catch (e) {
            console.error('Hata mesajı gösterilemedi:', e);
        }
        return false;
    } finally {
         // Butonu tekrar etkinleştir
         if (applyButton) applyButton.disabled = false;
    }
}
