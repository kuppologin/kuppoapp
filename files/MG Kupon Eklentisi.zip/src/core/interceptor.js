// Bu dosya, XMLHttpRequest ve Fetch API'lerini manipüle ederek
// ağ isteklerini yakalayan ve yönlendiren mantığı içerir.

'use strict';

// Custom texts response oluşturmak için yardımcı fonksiyon
// Standart custom texts yanıtı üreten fonksiyon
  // Standart custom texts yanıtı üreten fonksiyon
  function generateCustomTextsResponse() {
    return {"version":349,"customTextMap":{"DARK_KITCHEN":[{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileFavorites","value":"Favori Ürünlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profilePoints","value":"Puanlarım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileSupport","value":"Yardım ve Destek"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecini hızlandırabilir, özel fırsatlara erişebilirsin"},{"type":"anonAuthenticationTitle","value":"Siparişine Devam Et"},{"type":"authenticationTitle","value":"Hoş Geldin"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerini kullanarak alışverişini daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra 60 gün içerisinde tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere!"},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"}],"ELEKTRONIK":[{"type":"bagCountInfo","value":"Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için, ürün gruplarına göre sınıflandırarak olabilecek en az poşet kullanımı ile size ulaştırmaya çalışıyoruz. Poşet veya alışveriş çanta kullanım adetleri ürün çeşitliliğine göre değişmektedir.\n\nSipariş ettiğiniz ürünlerin; taze meyve sebze, temizlik malzemeleri veya donuk ürünlerin bir arada taşınması, hem ürünler açısından hem de siz müşterilerimizin sağlığı açısından sakıncalı olacağından, ürünleri ayrı poşet veya alışveriş çantalarına yerleştirmekteyiz.\n\nSiparişleri temin eden çalışanımız, bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı, poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"bagInfo","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı’nın mevzuatı gereği plastik poşetlerin 50 Kr ücret karşılığı verilmesi zorunlu hale getirildi. Yasa ile birlikte Migros Sanal Market’te siparişlerinizi hazırlamak için kullandığımız poşetler de ücretli hale geldi.Plastik poşet kullanımını azaltmak amacıyla alternatif olarak tekrar kullanılabilir Alışveriş Çantalarımızı da beğeninize sunuyoruz, dilerseniz siparişlerinizi Alışveriş Çantaları ile de hazırlayıp sizlere ulaştırabiliriz.Siparişlerinizi gıda güvenliğine uygun koşullarda sizlere teslim edebilmek konusunda çok hassasız, bunun için siparişinizi ürün gruplarına göre sınıflandırarak gıda-gıdadışı-soğuk ürünler şeklinde ayrıştırıyoruz, ancak çevre konusunda da çok hassas olduğumuzdan minimum adette poşet veya alışveriş çantası kullanmaya da özen gösteriyoruz.Siparişlerinizi özenle hazırlayan alışveriş danışmanlarımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yapması sebebiyle siparişinizde kaç adet poşet veya çanta kullanılacağı ancak sipariş hazırlama aşamasında belirlenebiliyor."},{"type":"bagPriceInfo","value":"1 Ocak 2019 tarihi itibari ile Çevre ve Şehircilik Bakanlığı’nın kararı uyarınca plastik poşetler adedi 50 kuruş olarak ücretlendirilecektir. Poşet bedeli siparişinizin hazırlanma aşamasında (sipariş kapasitenize göre) belirlenecek olup sipariş tutarınıza yansıtılacaktır."},{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"deliveryPriceInfo","value":"<strong>Teslimat ücretiniz ödeme adımında gösterilecektir.</strong><br/>Teslimat ücreti; seçtiğiniz bölge, zaman ve sipariş tutarınız ile değişkenlik gösterebilir.<br/><br/><strong>Sipariş tutarına göre teslimat tutarları:</strong><br/><strong>60 TL - 149,99 TL</strong> arası <strong>5,90 TL</strong> (KDV Dahil)<br/><strong>150 TL - 249,99 TL</strong> arası <strong>3,90 TL</strong> (KDV Dahil)<br/><strong>250 TL</strong> ve üzeri <strong>ücretsiz</strong>"},{"type":"noteNotUpdatedable","value":"Hazırlanmaya başladıktan sonra not eklenemez."},{"type":"plasticBagPriceInfo","value":"Poşetli teslimat istiyorum. (Adet: 0,50 TL)"},{"type":"returnShipmentExpirationInfo","value":"İade etmek istediğin ürünleri faturası ve iade kodu ile birlikte en geç 15 iş günü içinde kargo firmasına teslim etmen gerekiyor."},{"type":"returnShipmentInfo","value":"Siparişin içerisinden seçtiğin ürünleri sipariş faturası ve oluşturacağın iade kodu ile birlikte kargo firmasına teslim ederek iade edebilirsin."},{"type":"returnShipmentProcessFollowUpInfo","value":"İade sürecini ilgili siparişin detay sayfası üzerinden ya da 0850 200 40 00 numaralı çağrı merkezini arayarak takip edebilirsin."},{"type":"shoppingBagPriceInfo","value":"Alışveriş çantalı teslimat istiyorum (Adet: 1.50TL)"},{"type":"specialDiscountInfo","value":"Gördüğünüze İnanın Kampanyası, Money Kart ile yapılan her 200 TL’lik alışverişte geçerlidir. Kampanyaya alkollü içkiler, sigara, operatör TL ürün yükleme satışları, elektrikli ve elektronik ürünler, Ramazan Kolileri, Kurban siparişleri, bahçe mobilyaları, Yılbaşı Sepeti, Milli Piyango Biletleri ve yeniden satış amaçlı toplu satın alımlar dahil değildir. Money kullanılarak yapılan ödemelerde, Money tutarı kampanya harcama kotasına dahil değildir. Gördüğünüze İnanın kampanyası diğer kampanyalar ile birleştirilemez. Yukarıda belirtilen kategori ve ürünler hariç 200 TL ve üzeri alışverişinizde belirlenen tarihler arasında ve belirlenen ürünlerde 200 TL ve üzeri siparişlerinizde geçerli olmak üzere indirim uygulanmaktadır. İndirimli ürünlerden yararlanmak için Migros Sanal Market’e üye girişi yapmanız ve üyelik bilgilerinizde Money Kart veya Money Bonus MIN numaranızın kayıtlı olması gerekmektedir. 200 TL ve üzeri alışverişlerinizde, indirimli satın alabileceğiniz ürünler üyelik girişi yaparak verdiğiniz siparişlerin sepet detay sayfasında, sepetinizdeki ürünlerin altında gözükmekte ve dilerseniz siparişinizi bitirmeden önce buradan sepete eklenebilmektedir. Kampanyadan yararlanmak için 200 TL üzeri sepetinize kampanyalı ürünü eklemeniz gerekmektedir. Kampanya ürünlerine Migros Sanal Market ana sayfa Bütün Kampanyalar/Gördüğünüze Duyduğunuza İnanın reyonundan da ulaşılmaktadır. Toplam alışveriş tutarınızın her 200 TL’si için 1 adet indirimli ürün satın alabilirsiniz. Hak edilen indirimli ürün adetinden daha fazla eklenen ürünler için indirim uygulanmamaktadır. 200 TL ve üzeri bir alışverişinizde tek ürün indirimi yapılacaktır. Ürünler mağaza stokları ile sınırlıdır. Ürünleriniz sepete reyon fiyatından eklenecek, indirimleriniz siparişinizi bitirirken düşülecektir. Bu kampanya Migroskop ve diğer yüzde indirim kampanyaları ile birleştirilemez. Pil, Elektrikli Küçük Ev Aletleri ve Elektrikli Kişisel Bakım ürünleri 200 TL alım kotasına dahil değildir. Money Bonus veya Money Kart özellikli diğer kartlar ile yapacağınız alışverişlerde geçerlidir. İndirimden yararlanmak için Migros Sanal Market'e üye girişi yapılmalı,\n        üyelik bilgileriniz Money Kart veya Money Bonus MIN numarasına kayıtlı olmalıdır."},{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"OrderSuccessCargoText","value":"Ürünlerin 1-7 iş günü içerisinde kargoya verilecektir. Kargonu siparişlerim altından takip edebilirsin."},{"type":"CheckoutCargoTextTitle","value":"Kargo ile Adrese Teslim"},{"type":"CheckoutCargoText","value":"Ürünlerin 1-7 iş günü içerisinde kargoya verilecektir."},{"type":"CheckoutBagTitle","value":"Poşet Seçimi"},{"type":"CheckoutPlasticBag","value":"Poşetli teslimat istiyorum"},{"type":"CheckoutShoppingBag","value":"Alışveriş çantalı teslimat istiyorum"},{"type":"CheckoutPaperBag","value":"Kağıt poşetli teslimat istiyorum"},{"type":"CheckoutBagQuestion","value":"Siparişim kaç adet poşet ile gelir?"},{"type":"CheckoutBagAnswer","value":"Sepete eklenen ürünlerin hacmine göre poşet ücreti hesaplanmaktadır."},{"type":"CheckoutBagPriceInfo","value":"Poşet Ücreti Hakkında"},{"type":"CheckoutBagPriceAnswer","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı'nın mevzuatı gereği plastik poşetler ücretli olacaktır ve poşetlerin 50 Kuruş ücret karşılığında verilmesi zorunlu hale gelmiştir. Yasa kapsamında Migros Sanal Market'te de ücretli poşet uygulamasına geçmiştir. 31 Mart 2019 itibariyle plastik poşete alternatif olarak, farklı kullanım amaçlarını da destekleyecek tekrar kullanılabilir alışveriş çantası ürettik. Dilerseniz bu çantalar ile teslimatınızı yapabiliriz. Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için ürün gruplarına göre sınıflandırarak ayrı ayrı minimum adette poşet veya bez çanta kullanmaya çalışıyoruz. Siparişleri temin eden çalışanımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"CheckoutBagPriceFormat","value":"Adedi %@"},{"type":"OrderSuccessReferralTitle","value":"Arkadaşına Öner, 50 TL Kazan!"},{"type":"OrderSuccessReferralText","value":"Migros Hemen'i arkadaşlarına öner, 50 TL indirim hemen senin olsun!"},{"type":"OrderSuccessReferralButton","value":"Arkadaşını Davet Et"},{"type":"CheckoutProvisionText","value":"Siparişinizde gramaj fazlalığı olma ihtimaline karşı banka tarafından fazladan provizyon ödemesi alınmaktadır. Fazladan alınan tutar provizyonda tutulup sipariş teslimi sonrasında yalnızca fatura tutarı kadar kesin çekim yapılmakta, kalan tutar kredi kartlarında aynı gün/debit kartlarda ise ertesi gün geri iade edilmektedir. Provizyon tutarı bankanıza göre değişir."},{"type":"CheckoutProvisionTitle","value":"Banka Provizyonu Hakkında"},{"type":"HelpAndSupportContactText","value":"Siparişinizle ve oluşturmuş olduğunuz taleplerle ilgili 850'li numaradan aranabilirsiniz.\t"},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"checkoutLoanTitle","value":"Şimdi Al, Sonra Öde"},{"type":"checkoutLoanSubTitle","value":"Erteleyerek Ödeme Fırsatı"},{"type":"checkoutOtherPaymentTitle","value":"Farklı Ödeme Yöntemleri"},{"type":"checkoutOtherPaymentSubTitle","value":"Dijital Banka Ödemeleri"},{"type":"checkoutWalletSubTitle","value":"Money Ayrıcalıklarını Kullan\t"},{"type":"successRegistrationBulletOne","value":"Üye ol ilk siparişine 200 TL indirim,"},{"type":"successRegistrationBulletTwo","value":" İlk Siparişine özel ücretsiz teslimat."},{"type":"successRegistrationBulletThree","value":" Money üyesi ol Money'li fiyatlardan kaçırma"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileFavorites","value":"Favori Ürünlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profilePoints","value":"Puanlarım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileSupport","value":"Yardım ve Destek"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"successAlternativeDescription","value":"Siparişin ve oluşturmuş olduğun taleplerinle ilgili 850'li numaralı telefondan aranabilirsin. Numara geri aramaya kapalıdır."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecini hızlandırabilir, özel fırsatlara erişebilirsin"},{"type":"anonAuthenticationTitle","value":"Siparişine Devam Et"},{"type":"authenticationTitle","value":"Hoş Geldin"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerini kullanarak alışverişini daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <p>Kampanya, 01.02.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</p> <ul> <li> Kampanyadan yararlanabilmek için \"Hesabım\" kısmındaki \"Arkadaşına Öner, Kazan!\" kutucuğuna tıklayıp \"Arkadaşını Davet Et\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir. </li> <li> Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 500 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır. </li> <li> Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir. </li> <li> Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir. </li> <li> Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz. </li> <li> Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir. </li> <li> Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir. </li> <li> Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir. </li> <li> Kampanya kapsamında kazanılan indirimler 500 TL ve üzeri siparişlerde geçerlidir. </li> <li> Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. </li> <li> Kampanya 100.000 kullanım kotası ile sınırlıdır. </li> <li> Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. </li> <li> Kampanya yalnızca Migros Hemen'de geçerlidir. </li> <li> Migros Hemen (Dijital Platform Gıda Hizmetleri A. Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. </li> <li> Başka kampanyalar ile birleştirilemez. </li> <li> Tek kullanımlıktır, bölünemez. </li> <li> Para ile satılamaz veya paraya çevrilemez. </li> <li> Karşılığında para iadesi yapılamaz. </li> <li> Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır. </li> <li> Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir. </li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşını Davet Et"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere!"},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"}],"HEMEN":[{"type":"bagCountInfo","value":"Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için, ürün gruplarına göre sınıflandırarak olabilecek en az poşet kullanımı ile size ulaştırmaya çalışıyoruz. Poşet veya alışveriş çanta kullanım adetleri ürün çeşitliliğine göre değişmektedir.  Sipariş ettiğiniz ürünlerin; taze meyve sebze, temizlik malzemeleri veya donuk ürünlerin bir arada taşınması, hem ürünler açısından hem de siz müşterilerimizin sağlığı açısından sakıncalı olacağından, ürünleri ayrı poşet veya alışveriş çantalarına yerleştirmekteyiz.  Siparişleri temin eden çalışanımız, bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı, poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"bagInfo","value":"Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı’nın mevzuatı gereği plastik poşetlerin 50 Kr ücret karşılığı verilmesi zorunlu hale getirildi. Yasa ile birlikte Migros Sanal Market’te siparişlerinizi hazırlamak için kullandığımız poşetler de ücretli hale geldi. Plastik poşet kullanımını azaltmak amacıyla alternatif olarak tekrar kullanılabilir Alışveriş Çantalarımızı da beğeninize sunuyoruz, dilerseniz siparişlerinizi Alışveriş Çantaları ile de hazırlayıp sizlere ulaştırabiliriz.  Siparişlerinizi gıda güvenliğine uygun koşullarda sizlere teslim edebilmek konusunda çok hassasız, bunun için siparişinizi ürün gruplarına göre sınıflandırarak gıda-gıdadışı-soğuk ürünler şeklinde ayrıştırıyoruz, ancak çevre konusunda da çok hassas olduğumuzdan minimum adette poşet veya alışveriş çantası kullanmaya da özen gösteriyoruz.  Siparişlerinizi özenle hazırlayan alışveriş danışmanlarımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yapması sebebiyle siparişinizde kaç adet poşet veya çanta kullanılacağı ancak sipariş hazırlama aşamasında belirlenebiliyor."},{"type":"bagInfoDescription","value":"Siparişlerinizin hacmine ve sepet içeriğinize göre poşet adediniz belirlenir. Sepetinizdeki ürünlerin hacmi ve poşetlerin taşıma kapasitesine göre otomatik bir hesaplama çalışmaktadır."},{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"deliveryPriceInfo","value":"<strong>Teslimat ücretiniz ödeme adımında gösterilecektir.</strong><br/>Teslimat ücreti; seçtiğiniz bölge, zaman ve sipariş tutarınız ile değişkenlik gösterebilir.<br/><br/><strong>Sipariş tutarına göre teslimat tutarları:</strong><br/><strong>60 TL - 149,99 TL</strong> arası <strong>5,90 TL</strong> (KDV Dahil)<br/><strong>150 TL - 249,99 TL</strong> arası <strong>3,90 TL</strong> (KDV Dahil)<br/><strong>250 TL</strong> ve üzeri <strong>ücretsiz</strong>"},{"type":"noteNotUpdatedable","value":"Hazırlanmaya başladıktan sonra not eklenemez."},{"type":"plasticBagPriceInfo","value":"Adet: ₺0,25"},{"type":"referralPagePart1","value":"Arkadaşına Öner, Kazan!"},{"type":"referralPagePart2","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"referralPagePart3","value":"Migros Hemen’e arkadaşlarını davet etmek, sana 200 TL kazandıracak!"},{"type":"referralPagePart4","value":"Şimdi arkadaşını Migros Hemen’e davet et, o ilk siparişini versin, sen de 20 TL kazan! Unutma, en fazla 10 arkadaşını davet edebilir ve kazancını 60 TL ve üzeri Migros Hemen siparişlerinde kullanabilirsin! Migros Hemen’e davet ettiğin arkadaşlarının durumunu buradan takip edebilirsin!"},{"type":"referralPagePart5","value":"-Kampanya kapsamında, davetinizi kabul edip sipariş veren her arkadaşınız için size 60 TL ve üzeri siparişlerinizde kullanabileceğiniz 20 TL indirim hediye ediyoruz! Arkadaşlarınız da sizin davetiniz sayesinde 60 TL ve üzeri siparişinde kullanabileceği 20 TL indirim kazanıyor! -Kampanya Migros Hemen üzerinden oluşturacağın 60 TL ve üzeri siparişlerde geçerlidir. -Kampanya size 20 TL indirim sağlamaktadır. İndirim ödeme adımında yansıyacaktır. -Kampanyadan yararlanabilmen için en az 1 siparişinin olması gerekmektedir. -Kampanyadan yararlanabilmen için davet ettiğin arkadaşının Migros uygulamasına kaydolması ve en az 1 sipariş oluşturması gerekmektedir. -Kampanya kapsamında en fazla 10 kişi davet edilebilir ve en fazla 10 kere kupon kazanılabilir. -Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. -Kampanya kota ile sınırlandırılmıştır. Belirlenen kotaya ulaştığı taktirde kampanya sona erecektir ve kampanya pasif hale gelecektir. -Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. -Kampanyanın son kullanım tarihi 31.12.2023'tür. Bu tarihten ve saatten sonra kampanya geçerli olmayacaktır. -Kampanya,        başka indirim kodu kampanyaları ile birleştirilemez. -İndirim kodu tek kullanımlıktır, bölünemez. -                                                                                               İndirim kodları para ile satılamaz veya paraya çevrilemez. -İndirim kodları karşılığında para iadesi yapılamaz. -Sipariş iptali ya da iadesinde kampanyadan tekrar faydalanılamaz. < br >  -Migros Hemen (Migros T.A.Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. < br > -Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir."},{"type":"referralPagePart6","value":"Davetiyen ile gönderdiğin link üzerinden arkadaşın üyelik oluşturup ilk siparişini verdiğinde, hem sen hem de arkadaşın 20 TL indirim kazanır ve anında hesabınıza tanımlanır. Unutma, en fazla 10 arkadaşın gönderdiğin link üzerinden üyelik oluşturup sipariş verebilir."},{"type":"shoppingBagPriceInfo","value":"Adet: ₺3,00"},{"type":"specialDiscountInfo","value":"Gördüğünüze İnanın Kampanyası,\n        Money Kart ile yapılan her 100 TL’lik alışverişte geçerlidir. Kampanyaya alkollü içkiler, sigara,\n        operatör TL ürün yükleme satışları, elektrikli ve elektronik ürünler, Ramazan Kolileri, Kurban siparişleri,\n        bahçe mobilyaları, Yılbaşı Sepeti,\n        Milli Piyango Biletleri ve yeniden satış amaçlı toplu satın alımlar dahil değildir. Money kullanılarak yapılan ödemelerde,\n        Money tutarı kampanya harcama kotasına dahil değildir. Gördüğünüze İnanın kampanyası diğer kampanyalar ile birleştirilemez. Yukarıda belirtilen kategori ve ürünler hariç 100 TL ve üzeri alışverişinizde belirlenen tarihler arasında ve belirlenen ürünlerde 100 TL ve üzeri siparişlerinizde geçerli olmak üzere indirim uygulanmaktadır. İndirimli ürünlerden yararlanmak için Migros Sanal Market’e üye girişi yapmanız ve üyelik bilgilerinizde Money Kart veya Money Bonus MIN numaranızın kayıtlı olması gerekmektedir. 100 TL ve üzeri alışverişlerinizde,\n        indirimli satın alabileceğiniz ürünler üyelik girişi yaparak verdiğiniz siparişlerin sepet detay sayfasında,\n        sepetinizdeki ürünlerin altında gözükmekte ve dilerseniz siparişinizi bitirmeden önce buradan sepete eklenebilmektedir. Kampanyadan yararlanmak için 100 TL üzeri sepetinize kampanyalı ürünü eklemeniz gerekmektedir. Kampanya ürünlerine Migros Sanal Market ana sayfa Bütün Kampanyalar/Gördüğünüze Duyduğunuza İnanın reyonundan da ulaşılmaktadır. Toplam alışveriş tutarınızın her 100 TL’si için 1 adet indirimli ürün satın alabilirsiniz. Hak edilen indirimli ürün adetinden daha fazla eklenen ürünler için indirim uygulanmamaktadır. 100 TL ve üzeri bir alışverişinizde tek ürün indirimi yapılacaktır. Ürünler mağaza stokları ile sınırlıdır. Ürünleriniz sepete reyon fiyatından eklenecek,\n        indirimleriniz siparişinizi bitirirken düşülecektir. Bu kampanya Migroskop ve diğer yüzde indirim kampanyaları ile birleştirilemez. Pil,\n        Elektrikli Küçük Ev Aletleri ve Elektrikli Kişisel Bakım ürünleri 100 TL alım kotasına dahil değildir. Money Bonus veya Money Kart özellikli diğer kartlar ile yapacağınız alışverişlerde geçerlidir. İndirimden yararlanmak için Migros Sanal Market'e üye girişi yapılmalı, üyelik bilgileriniz Money Kart veya Money Bonus MIN numarasına kayıtlı olmalıdır."},{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"CheckoutCargoTextTitle","value":"Kargo ile Adrese Teslim"},{"type":"CheckoutCargoText","value":"Ürünlerin 1-3 iş günü içerisinde kargoya verilecektir."},{"type":"CheckoutBagTitle","value":"Poşet Seçimi"},{"type":"CheckoutPlasticBag","value":"Poşetli teslimat istiyorum"},{"type":"CheckoutShoppingBag","value":"Alışveriş çantalı teslimat istiyorum"},{"type":"CheckoutPaperBag","value":"Kağıt poşetli teslimat istiyorum"},{"type":"CheckoutBagQuestion","value":"Siparişim kaç adet poşet ile gelir?"},{"type":"CheckoutBagAnswer","value":"Sepete eklenen ürünlerin hacmine göre poşet ücreti hesaplanmaktadır."},{"type":"CheckoutBagPriceInfo","value":"Poşet Ücreti Hakkında"},{"type":"CheckoutBagPriceAnswer","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı'nın mevzuatı gereği plastik poşetler ücretli olacaktır ve poşetlerin 50 Kuruş ücret karşılığında verilmesi zorunlu hale gelmiştir. Yasa kapsamında Migros Sanal Market'te de ücretli poşet uygulamasına geçmiştir. 31 Mart 2019 itibariyle plastik poşete alternatif olarak, farklı kullanım amaçlarını da destekleyecek tekrar kullanılabilir alışveriş çantası ürettik. Dilerseniz bu çantalar ile teslimatınızı yapabiliriz. Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için ürün gruplarına göre sınıflandırarak ayrı ayrı minimum adette poşet veya bez çanta kullanmaya çalışıyoruz. Siparişleri temin eden çalışanımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"CheckoutBagPriceFormat","value":"Adedi %@"},{"type":"OrderSuccessReferralTitle","value":"Arkadaşına Öner, Kazan!"},{"type":"OrderSuccessReferralText","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"OrderSuccessReferralButton","value":"Arkadaşını Davet Et"},{"type":"CheckoutProvisionText","value":"Siparişinizde gramaj fazlalığı olma ihtimaline karşı banka tarafından fazladan provizyon ödemesi alınmaktadır. Fazladan alınan tutar provizyonda tutulup sipariş teslimi sonrasında yalnızca fatura tutarı kadar kesin çekim yapılmakta, kalan tutar kredi kartlarında aynı gün/debit kartlarda ise ertesi gün geri iade edilmektedir. Provizyon tutarı bankanıza göre değişir."},{"type":"CheckoutProvisionTitle","value":"Banka Provizyonu Hakkında"},{"type":"HelpAndSupportContactText","value":"Siparişinizle ve oluşturmuş olduğunuz taleplerle ilgili 850'li numaradan aranabilirsiniz."},{"type":"successReferralTitle","value":"Arkadaşına Öner, Kazan!"},{"type":"successReferralText","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"successReferralButton","value":"Arkadaşını Davet Et"},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"checkoutLoanTitle","value":"Şimdi Al, Sonra Öde"},{"type":"checkoutLoanSubTitle","value":"Erteleyerek Ödeme Fırsatı"},{"type":"checkoutOtherPaymentTitle","value":"Farklı Ödeme Yöntemleri"},{"type":"checkoutOtherPaymentSubTitle","value":"Dijital Banka Ödemeleri"},{"type":"checkoutWalletSubTitle","value":"Money Ayrıcalıklarını Kullan\t"},{"type":"successRegistrationBulletOne","value":"Üye ol ilk 3 siparişine özel Ücretsiz Teslimat,"},{"type":"successRegistrationBulletTwo","value":"İlk siparişine özel indirim,"},{"type":"successRegistrationBulletThree","value":" Money üyesi ol Money'li fiyatlardan kaçırma"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileFavorites","value":"Favori Ürünlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profilePoints","value":"Puanlarım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileSupport","value":"Yardım ve Destek"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"successAlternativeDescription","value":"Siparişin ve oluşturmuş olduğun taleplerinle ilgili 850'li numaralı telefondan aranabilirsin. Numara geri aramaya kapalıdır."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecini hızlandırabilir, özel fırsatlara erişebilirsin"},{"type":"anonAuthenticationTitle","value":"Siparişine Devam Et"},{"type":"authenticationTitle","value":"Hoş Geldin"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerini kullanarak alışverişini daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <ul> <li>Kampanya, 01.03.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</li> <li>Kampanyadan yararlanabilmek için \"<strong>Hesabım</strong>\" kısmındaki <b>\"Arkadaşına Öner, Kazan!\"</b> kutucuğuna tıklayıp \"<b>Arkadaşını Davet Et</b>\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir.</li> <li>Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 300 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır.</li> <li>Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir.</li> <li>Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir.</li> <li>Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz.</li> <li>Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir.</li> <li>Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir.</li> <li>Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir.</li> <li>Kampanya kapsamında kazanılan indirimler 300 TL ve üzeri siparişlerde geçerlidir.</li> <li>Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri kampanyaya dahil değildir.</li> <li>Kampanya 100.000 kullanım kotası ile sınırlıdır.</li> <li>Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar.</li> <li>Kampanya yalnızca Migros Hemen'de geçerlidir.</li> <li>Migros Hemen (Dijital Platform Gıda Hizmetleri A.Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar.</li> <li>Başka kampanyalar ile birleştirilemez.</li> <li>Tek kullanımlıktır, bölünemez.</li> <li>Para ile satılamaz veya paraya çevrilemez.</li> <li>Karşılığında para iadesi yapılamaz.</li> <li>Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır.</li> <li>Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir.</li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşına Öner, Kazan!"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere!"},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"}],"KURBAN":[{"type":"bagCountInfo","value":"Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için, ürün gruplarına göre sınıflandırarak olabilecek en az poşet kullanımı ile size ulaştırmaya çalışıyoruz. Poşet veya alışveriş çanta kullanım adetleri ürün çeşitliliğine göre değişmektedir.\n\nSipariş ettiğiniz ürünlerin; taze meyve sebze, temizlik malzemeleri veya donuk ürünlerin bir arada taşınması, hem ürünler açısından hem de siz müşterilerimizin sağlığı açısından sakıncalı olacağından, ürünleri ayrı poşet veya alışveriş çantalarına yerleştirmekteyiz.\n\nSiparişleri temin eden çalışanımız, bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı, poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"bagInfo","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı’nın mevzuatı gereği plastik poşetlerin 25 Kr ücret karşılığı verilmesi zorunlu hale getirildi. Yasa ile birlikte Migros Sanal Market’te siparişlerinizi hazırlamak için kullandığımız poşetler de ücretli hale geldi.\nPlastik poşet kullanımını azaltmak amacıyla alternatif olarak tekrar kullanılabilir Alışveriş Çantalarımızı da beğeninize sunuyoruz, dilerseniz siparişlerinizi Alışveriş Çantaları ile de hazırlayıp sizlere ulaştırabiliriz.\n\nSiparişlerinizi gıda güvenliğine uygun koşullarda sizlere teslim edebilmek konusunda çok hassasız, bunun için siparişinizi ürün gruplarına göre sınıflandırarak gıda-gıdadışı-soğuk ürünler şeklinde ayrıştırıyoruz, ancak çevre konusunda da çok hassas olduğumuzdan minimum adette poşet veya alışveriş çantası kullanmaya da özen gösteriyoruz.\n\nSiparişlerinizi özenle hazırlayan alışveriş danışmanlarımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yapması sebebiyle siparişinizde kaç adet poşet veya çanta kullanılacağı ancak sipariş hazırlama aşamasında belirlenebiliyor."},{"type":"bagPriceInfo","value":"1 Ocak 2019 tarihi itibari ile Çevre ve Şehircilik Bakanlığı’nın kararı uyarınca plastik poşetler adedi 25 kuruş olarak ücretlendirilecektir. Poşet bedeli siparişinizin hazırlanma aşamasında (sipariş kapasitenize göre) belirlenecek olup sipariş tutarınıza yansıtılacaktır."},{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"deliveryPriceInfo","value":"<strong>Teslimat ücretiniz ödeme adımında gösterilecektir.</strong><br/>Teslimat ücreti; seçtiğiniz bölge, zaman ve sipariş tutarınız ile değişkenlik gösterebilir.<br/><br/><strong>Sipariş tutarına göre teslimat tutarları:</strong><br/><strong>60 TL - 149,99 TL</strong> arası <strong>5,90 TL</strong> (KDV Dahil)<br/><strong>150 TL - 249,99 TL</strong> arası <strong>3,90 TL</strong> (KDV Dahil)<br/><strong>250 TL</strong> ve üzeri <strong>ücretsiz</strong>"},{"type":"plasticBagPriceInfo","value":"Poşetli teslimat istiyorum. (Adet: 0,25TL)"},{"type":"preAuthText","value":"Sipariş tutarı kartınızda provizyonda bekler, siparişiniz size teslim edildiğinde sadece teslim aldığınız ürünlerin ücreti kartınızdan çekilir, tedarik edilmeyen ürünler için ücret ödemezsiniz."},{"type":"shoppingBagPriceInfo","value":"Alışveriş çantalı teslimat istiyorum (Adet: 1.50TL)"},{"type":"specialDiscountInfo","value":"Gördüğünüze İnanın Kampanyası, Money Kart ile yapılan her 100 TL’lik alışverişte geçerlidir. Kampanyaya alkollü içkiler, sigara, operatör TL ürün yükleme satışları, elektrikli ve elektronik ürünler, Ramazan Kolileri, Kurban siparişleri, bahçe mobilyaları, Yılbaşı Sepeti, Milli Piyango Biletleri ve yeniden satış amaçlı toplu satın alımlar dahil değildir. Money kullanılarak yapılan ödemelerde, Money tutarı kampanya harcama kotasına dahil değildir. Gördüğünüze İnanın kampanyası diğer kampanyalar ile birleştirilemez. Yukarıda belirtilen kategori ve ürünler hariç 100 TL ve üzeri alışverişinizde belirlenen tarihler arasında ve belirlenen ürünlerde 100 TL ve üzeri siparişlerinizde geçerli olmak üzere indirim uygulanmaktadır. İndirimli ürünlerden yararlanmak için Migros Sanal Market’e üye girişi yapmanız ve üyelik bilgilerinizde Money Kart veya Money Bonus MIN numaranızın kayıtlı olması gerekmektedir. 100 TL ve üzeri alışverişlerinizde, indirimli satın alabileceğiniz ürünler üyelik girişi yaparak verdiğiniz siparişlerin sepet detay sayfasında, sepetinizdeki ürünlerin altında gözükmekte ve dilerseniz siparişinizi bitirmeden önce buradan sepete eklenebilmektedir. Kampanyadan yararlanmak için 100 TL üzeri sepetinize kampanyalı ürünü eklemeniz gerekmektedir. Kampanya ürünlerine Migros Sanal Market ana sayfa Bütün Kampanyalar/Gördüğünüze Duyduğunuza İnanın reyonundan da ulaşılmaktadır. Toplam alışveriş tutarınızın her 100 TL’si için 1 adet indirimli ürün satın alabilirsiniz. Hak edilen indirimli ürün adetinden daha fazla eklenen ürünler için indirim uygulanmamaktadır. 100 TL ve üzeri bir alışverişinizde tek ürün indirimi yapılacaktır. Ürünler mağaza stokları ile sınırlıdır. Ürünleriniz sepete reyon fiyatından eklenecek, indirimleriniz siparişinizi bitirirken düşülecektir. Bu kampanya Migroskop ve diğer yüzde indirim kampanyaları ile birleştirilemez. Pil, Elektrikli Küçük Ev Aletleri ve Elektrikli Kişisel Bakım ürünleri 100 TL alım kotasına dahil değildir. Money Bonus veya Money Kart özellikli diğer kartlar ile yapacağınız alışverişlerde geçerlidir. İndirimden yararlanmak için Migros Sanal Market'e üye girişi yapılmalı,\n        üyelik bilgileriniz Money Kart veya Money Bonus MIN numarasına kayıtlı olmalıdır."},{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"OrderSuccessCargoText","value":"Ürünlerin 1-3 iş günü içerisinde kargoya verilecektir. Kargonu siparişlerim altından takip edebilirsin."},{"type":"CheckoutProvisionText","value":"Siparişinizde gramaj fazlalığı olma ihtimaline karşı banka tarafından fazladan provizyon ödemesi alınmaktadır. Fazladan alınan tutar provizyonda tutulup sipariş teslimi sonrasında yalnızca fatura tutarı kadar kesin çekim yapılmakta, kalan tutar kredi kartlarında aynı gün/debit kartlarda ise ertesi gün geri iade edilmektedir. Provizyon tutarı bankanıza göre değişir."},{"type":"CheckoutProvisionTitle","value":"Banka Provizyonu Hakkında"},{"type":"HelpAndSupportContactText","value":"Siparişinizle ve oluşturmuş olduğunuz taleplerle ilgili 850'li bir numaradan iletişime geçeceğiz."},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileFavorites","value":"Favori Ürünlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profilePoints","value":"Puanlarım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileSupport","value":"Yardım ve Destek"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"successAlternativeDescription","value":"Siparişin ve oluşturmuş olduğun taleplerinle ilgili 850'li numaralı telefondan aranabilirsin. Numara geri aramaya kapalıdır."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecini hızlandırabilir, özel fırsatlara erişebilirsin"},{"type":"anonAuthenticationTitle","value":"Siparişine Devam Et"},{"type":"authenticationTitle","value":"Hoş Geldin"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerini kullanarak alışverişini daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <p>Kampanya, 01.02.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</p> <ul> <li> Kampanyadan yararlanabilmek için \"Hesabım\" kısmındaki \"Arkadaşına Öner, Kazan!\" kutucuğuna tıklayıp \"Arkadaşını Davet Et\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir. </li> <li> Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 500 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır. </li> <li> Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir. </li> <li> Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir. </li> <li> Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz. </li> <li> Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir. </li> <li> Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir. </li> <li> Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir. </li> <li> Kampanya kapsamında kazanılan indirimler 500 TL ve üzeri siparişlerde geçerlidir. </li> <li> Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. </li> <li> Kampanya 100.000 kullanım kotası ile sınırlıdır. </li> <li> Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. </li> <li> Kampanya yalnızca Migros Hemen'de geçerlidir. </li> <li> Migros Hemen (Dijital Platform Gıda Hizmetleri A. Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. </li> <li> Başka kampanyalar ile birleştirilemez. </li> <li> Tek kullanımlıktır, bölünemez. </li> <li> Para ile satılamaz veya paraya çevrilemez. </li> <li> Karşılığında para iadesi yapılamaz. </li> <li> Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır. </li> <li> Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir. </li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşını Davet Et"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere!"},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"}],"LOTTERY":[{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"OrderSuccessReferralTitle","value":"Arkadaşına Öner, 50 TL Kazan!"},{"type":"OrderSuccessReferralText","value":"Migros Hemen'i arkadaşlarına öner, 50 TL indirim hemen senin olsun!"},{"type":"OrderSuccessReferralButton","value":"Arkadaşını Davet Et"},{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"authenticationTitle","value":"Kimlik Doğrulama Gerekiyor"},{"type":"authenticationDesc","value":"Daha önce kimlik doğrulama yaptıysan bu adımı atlamak için giriş yapabilirsin ya da üye olarak bu adımı sadece ilk alışverişin için kolayca yapabilirsin."},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileBillingaddresses","value":"Fatura Adreslerim"},{"type":"profileFAQ","value":"Sıkça Sorulan Sorular"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"profileQuery","value":"Bilet Kodu Sorgula"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <p>Kampanya, 01.02.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</p> <ul> <li> Kampanyadan yararlanabilmek için \"Hesabım\" kısmındaki \"Arkadaşına Öner, Kazan!\" kutucuğuna tıklayıp \"Arkadaşını Davet Et\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir. </li> <li> Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 500 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır. </li> <li> Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir. </li> <li> Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir. </li> <li> Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz. </li> <li> Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir. </li> <li> Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir. </li> <li> Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir. </li> <li> Kampanya kapsamında kazanılan indirimler 500 TL ve üzeri siparişlerde geçerlidir. </li> <li> Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. </li> <li> Kampanya 100.000 kullanım kotası ile sınırlıdır. </li> <li> Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. </li> <li> Kampanya yalnızca Migros Hemen'de geçerlidir. </li> <li> Migros Hemen (Dijital Platform Gıda Hizmetleri A. Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. </li> <li> Başka kampanyalar ile birleştirilemez. </li> <li> Tek kullanımlıktır, bölünemez. </li> <li> Para ile satılamaz veya paraya çevrilemez. </li> <li> Karşılığında para iadesi yapılamaz. </li> <li> Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır. </li> <li> Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir. </li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşını Davet Et"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere!"},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"}],"MACROCENTER":[{"type":"bagCountInfo","value":"Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için, ürün gruplarına göre sınıflandırarak olabilecek en az poşet kullanımı ile size ulaştırmaya çalışıyoruz. Poşet veya alışveriş çanta kullanım adetleri ürün çeşitliliğine göre değişmektedir.\n\nSipariş ettiğiniz ürünlerin; taze meyve sebze, temizlik malzemeleri veya donuk ürünlerin bir arada taşınması, hem ürünler açısından hem de siz müşterilerimizin sağlığı açısından sakıncalı olacağından, ürünleri ayrı poşet veya alışveriş çantalarına yerleştirmekteyiz.\n\nSiparişleri temin eden çalışanımız, bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı, poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"bagInfo","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı’nın mevzuatı gereği plastik poşetlerin 50 Kr ücret karşılığı verilmesi zorunlu hale getirildi. Yasa ile birlikte Migros Sanal Market’te siparişlerinizi hazırlamak için kullandığımız poşetler de ücretli hale geldi.Plastik poşet kullanımını azaltmak amacıyla alternatif olarak tekrar kullanılabilir Alışveriş Çantalarımızı da beğeninize sunuyoruz, dilerseniz siparişlerinizi Alışveriş Çantaları ile de hazırlayıp sizlere ulaştırabiliriz.Siparişlerinizi gıda güvenliğine uygun koşullarda sizlere teslim edebilmek konusunda çok hassasız, bunun için siparişinizi ürün gruplarına göre sınıflandırarak gıda-gıdadışı-soğuk ürünler şeklinde ayrıştırıyoruz, ancak çevre konusunda da çok hassas olduğumuzdan minimum adette poşet veya alışveriş çantası kullanmaya da özen gösteriyoruz.Siparişlerinizi özenle hazırlayan alışveriş danışmanlarımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yapması sebebiyle siparişinizde kaç adet poşet veya çanta kullanılacağı ancak sipariş hazırlama aşamasında belirlenebiliyor."},{"type":"bagPriceInfo","value":"1 Ocak 2019 tarihi itibari ile Çevre ve Şehircilik Bakanlığı’nın kararı uyarınca plastik poşetler adedi 50 kuruş olarak ücretlendirilecektir. Poşet bedeli siparişinizin hazırlanma aşamasında (sipariş kapasitenize göre) belirlenecek olup sipariş tutarınıza yansıtılacaktır."},{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"deliveryPriceInfo","value":"<strong>Teslimat ücretiniz ödeme adımında gösterilecektir.</strong><br/>Teslimat ücreti; seçtiğiniz bölge, zaman ve sipariş tutarınız ile değişkenlik gösterebilir.<br/><br/><strong>Adrese Teslim teslimat yöntemi için sipariş tutarına göre teslimat tutarları:</strong><br/><strong>Randevulu Teslimat:</strong><br/><strong>100 TL - 499,99 TL</strong> arası <strong>9,99 TL</strong> (KDV Dahil)<br/><strong>500 TL</strong> ve üzeri <strong>ücretsiz</strong>.<br/>Mağazadan Alacağım teslimat yöntemi için teslimat <strong>ücretsiz</strong>.<br/><strong>Hızlı Teslimat:</strong><br/><strong>100 TL - 499,99 TL</strong> arası <strong>12,99 TL</strong> (KDV Dahil)<br/><strong>500 TL</strong> ve üzeri <strong>ücretsiz</strong>.<br/>Mağazadan Alacağım teslimat yöntemi için teslimat <strong>ücretsiz</strong>."},{"type":"emailVerificationReminderDesc","value":"Siparişlerinle ilgili e-postaları almaya devam etmek için %@ adresini doğrulaman gerektiğini hatırlatırız."},{"type":"emailVerificationReminderTitle","value":"E-posta adresini doğrulamayı unutma"},{"type":"noteNotUpdatedable","value":"Hazırlanmaya başladıktan sonra not eklenemez."},{"type":"plasticBagPriceInfo","value":"Poşetli teslimat istiyorum. (Adet: 0,50TL)"},{"type":"shoppingBagPriceInfo","value":"Alışveriş çantalı teslimat istiyorum."},{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"CheckoutCargoTextTitle","value":"Kargo ile Adrese Teslim"},{"type":"CheckoutCargoText","value":"Ürünlerin 1-3 iş günü içerisinde kargoya verilecektir."},{"type":"CheckoutBagTitle","value":"Poşet Seçimi"},{"type":"CheckoutPlasticBag","value":"Poşetli teslimat istiyorum"},{"type":"CheckoutShoppingBag","value":"Alışveriş çantalı teslimat istiyorum"},{"type":"CheckoutPaperBag","value":"Kağıt poşetli teslimat istiyorum"},{"type":"CheckoutBagQuestion","value":"Siparişim kaç adet poşet ile gelir?"},{"type":"CheckoutBagAnswer","value":"Sepete eklenen ürünlerin hacmine göre poşet ücreti hesaplanmaktadır."},{"type":"CheckoutBagPriceInfo","value":"Poşet Ücreti Hakkında"},{"type":"CheckoutBagPriceAnswer","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı'nın mevzuatı gereği plastik poşetler ücretli olacaktır ve poşetlerin 50 Kuruş ücret karşılığında verilmesi zorunlu hale gelmiştir. Yasa kapsamında Migros Sanal Market'te de ücretli poşet uygulamasına geçmiştir. 31 Mart 2019 itibariyle plastik poşete alternatif olarak, farklı kullanım amaçlarını da destekleyecek tekrar kullanılabilir alışveriş çantası ürettik. Dilerseniz bu çantalar ile teslimatınızı yapabiliriz. Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için ürün gruplarına göre sınıflandırarak ayrı ayrı minimum adette poşet veya bez çanta kullanmaya çalışıyoruz. Siparişleri temin eden çalışanımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"CheckoutBagPriceFormat","value":"Adedi %@"},{"type":"OrderSuccessReferralTitle","value":"Arkadaşına Öner, 50 TL Kazan!"},{"type":"OrderSuccessReferralText","value":"Migros Hemen'i arkadaşlarına öner, 50 TL indirim hemen senin olsun!"},{"type":"OrderSuccessReferralButton","value":"Arkadaşını Davet Et"},{"type":"CheckoutProvisionText","value":"Siparişinizde alternatif ürün veya gramaj fazlalığı olma ihtimaline karşı banka tarafından fazladan provizyon ödemesi alınmaktadır. Fazladan alınan tutar provizyonda tutulup sipariş teslimi sonrasında yalnızca fatura tutarı kadar kesin çekim yapılmaktadır. Kalan tutar kredi kartlarında aynı gün, debit kartlarda ise ertesi gün geri iade edilmektedir. Provizyon tutarı bankanıza göre değişir."},{"type":"CheckoutProvisionTitle","value":"Banka Provizyonu Hakkında"},{"type":"HelpAndSupportContactText","value":"Siparişinizle ve oluşturmuş olduğunuz taleplerle ilgili 850'li numaradan aranabilirsiniz."},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"checkoutLoanTitle","value":"Şimdi Al, Sonra Öde"},{"type":"checkoutLoanSubTitle","value":"Erteleyerek Ödeme Fırsatı"},{"type":"checkoutOtherPaymentTitle","value":"Farklı Ödeme Yöntemleri"},{"type":"checkoutOtherPaymentSubTitle","value":"Dijital Banka Ödemeleri"},{"type":"checkoutWalletSubTitle","value":"Money Ayrıcalıklarını Kullan\t"},{"type":"successRegistrationBulletOne","value":"Üye ol ilk siparişine 200 TL indirim,"},{"type":"successRegistrationBulletTwo","value":" İlk Siparişine özel ücretsiz teslimat."},{"type":"successRegistrationBulletThree","value":" Money üyesi ol Money'li fiyatlardan kaçırma"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileFavorites","value":"Favori Ürünlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profilePoints","value":"Puanlarım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileSupport","value":"Yardım ve Destek"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"successAlternativeDescription","value":"Siparişiniz ve oluşturmuş olduğunuz taleplerinizle ilgili 850'li numaralı telefondan aranabilirsiniz. Numara geri aramaya kapalıdır."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecinizi hızlandırabilir, özel fırsatlara erişebilirsiniz"},{"type":"anonAuthenticationTitle","value":"Siparişinize Devam Edin"},{"type":"authenticationTitle","value":"Hoş Geldiniz"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerinizi kullanarak alışverişinizi daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <p>Kampanya, 01.02.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</p> <ul> <li> Kampanyadan yararlanabilmek için \"Hesabım\" kısmındaki \"Arkadaşına Öner, Kazan!\" kutucuğuna tıklayıp \"Arkadaşını Davet Et\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir. </li> <li> Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 500 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır. </li> <li> Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir. </li> <li> Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir. </li> <li> Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz. </li> <li> Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir. </li> <li> Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir. </li> <li> Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir. </li> <li> Kampanya kapsamında kazanılan indirimler 500 TL ve üzeri siparişlerde geçerlidir. </li> <li> Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. </li> <li> Kampanya 100.000 kullanım kotası ile sınırlıdır. </li> <li> Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. </li> <li> Kampanya yalnızca Migros Hemen'de geçerlidir. </li> <li> Migros Hemen (Dijital Platform Gıda Hizmetleri A. Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. </li> <li> Başka kampanyalar ile birleştirilemez. </li> <li> Tek kullanımlıktır, bölünemez. </li> <li> Para ile satılamaz veya paraya çevrilemez. </li> <li> Karşılığında para iadesi yapılamaz. </li> <li> Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır. </li> <li> Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir. </li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşını Davet Et"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığınıza üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabınızı sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksınız. Tekrar görüşmek üzere! "},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"},{"type":"productDetailTGA","value":"Teslimat saatini beklemeden, siparişini Tıkla Gel Al ile hemen alabilirsin."},{"type":"timeSlotTGA","value":"Teslimat saatini beklemeden, siparişini Tıkla Gel Al ile hemen alabilirsin."},{"type":"searchNoResultTGA","value":"Adrese teslimatta bulamadığın ürünler için Tıkla Gel Al hizmetini deneyebilirsin."},{"type":"orderSuccessPickUpTitle","value":"Siparişimi nasıl teslim alacağım?"},{"type":"orderSuccessPickUpFirstText","value":"Siparişin, seçtiğin teslimat saatine kadar hazırlanacak ve hazır olduğunda sana SMS ya da bildirim gönderilecek."},{"type":"orderSuccessPickUpSecondText","value":"Seçtiğin saat aralığında mağazadaki Tıkla Gel Al teslim noktasına gelmelisin."}],"MION":[{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"noteNotUpdatedable","value":"Hazırlanmaya başladıktan sonra not eklenemez."},{"type":"returnShipmentExpirationInfo","value":"İade etmek istediğin ürünleri faturası ve iade kodu ile birlikte en geç 15 iş günü içinde kargo firmasına teslim etmen gerekiyor."},{"type":"returnShipmentInfo","value":"Siparişin içerisinden seçtiğin ürünleri sipariş faturası ve oluşturacağın iade kodu ile birlikte kargo firmasına teslim ederek iade edebilirsin."},{"type":"returnShipmentProcessFollowUpInfo","value":"İade sürecini ilgili siparişin detay sayfası üzerinden ya da 0850 200 40 00 numaralı çağrı merkezini arayarak takip edebilirsin."},{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"OrderSuccessCargoText","value":"Ürünlerin 1-7 iş günü içerisinde kargoya verilecektir. Kargonu siparişlerim altından takip edebilirsin."},{"type":"CheckoutCargoTextTitle","value":"Kargo ile Adrese Teslim"},{"type":"CheckoutCargoText","value":"Ürünlerin 1-7 iş günü içerisinde kargoya verilecektir."},{"type":"CheckoutBagTitle","value":"Poşet Seçimi"},{"type":"CheckoutPlasticBag","value":"Poşetli teslimat istiyorum"},{"type":"CheckoutShoppingBag","value":"Alışveriş çantalı teslimat istiyorum"},{"type":"CheckoutPaperBag","value":"Kağıt poşetli teslimat istiyorum"},{"type":"CheckoutBagQuestion","value":"Siparişim kaç adet poşet ile gelir?"},{"type":"CheckoutBagAnswer","value":"Sepete eklenen ürünlerin hacmine göre poşet ücreti hesaplanmaktadır."},{"type":"CheckoutBagPriceInfo","value":"Poşet Ücreti Hakkında"},{"type":"CheckoutBagPriceAnswer","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı'nın mevzuatı gereği plastik poşetler ücretli olacaktır ve poşetlerin 50 Kuruş ücret karşılığında verilmesi zorunlu hale gelmiştir. Yasa kapsamında Migros Sanal Market'te de ücretli poşet uygulamasına geçmiştir. 31 Mart 2019 itibariyle plastik poşete alternatif olarak, farklı kullanım amaçlarını da destekleyecek tekrar kullanılabilir alışveriş çantası ürettik. Dilerseniz bu çantalar ile teslimatınızı yapabiliriz. Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için ürün gruplarına göre sınıflandırarak ayrı ayrı minimum adette poşet veya bez çanta kullanmaya çalışıyoruz. Siparişleri temin eden çalışanımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"CheckoutBagPriceFormat","value":"Adedi %@"},{"type":"OrderSuccessReferralTitle","value":"Arkadaşına Öner, 50 TL Kazan!"},{"type":"OrderSuccessReferralText","value":"Migros Hemen'i arkadaşlarına öner, 50 TL indirim hemen senin olsun!"},{"type":"OrderSuccessReferralButton","value":"Arkadaşını Davet Et"},{"type":"CheckoutProvisionText","value":"Siparişinizde gramaj fazlalığı olma ihtimaline karşı banka tarafından fazladan provizyon ödemesi alınmaktadır. Fazladan alınan tutar provizyonda tutulup sipariş teslimi sonrasında yalnızca fatura tutarı kadar kesin çekim yapılmakta, kalan tutar kredi kartlarında aynı gün/debit kartlarda ise ertesi gün geri iade edilmektedir. Provizyon tutarı bankanıza göre değişir."},{"type":"CheckoutProvisionTitle","value":"Banka Provizyonu Hakkında"},{"type":"HelpAndSupportContactText","value":"Siparişinizle ve oluşturmuş olduğunuz taleplerle ilgili 850'li numaradan aranabilirsiniz."},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"checkoutLoanTitle","value":"Şimdi Al, Sonra Öde"},{"type":"checkoutLoanSubTitle","value":"Erteleyerek Ödeme Fırsatı"},{"type":"checkoutOtherPaymentTitle","value":"Farklı Ödeme Yöntemleri"},{"type":"checkoutOtherPaymentSubTitle","value":"Dijital Banka Ödemeleri"},{"type":"checkoutWalletSubTitle","value":"Money Ayrıcalıklarını Kullan\t"},{"type":"successRegistrationBulletOne","value":"Üye ol ilk siparişine 200 TL indirim,"},{"type":"successRegistrationBulletTwo","value":" İlk Siparişine özel ücretsiz teslimat."},{"type":"successRegistrationBulletThree","value":" Money üyesi ol Money'li fiyatlardan kaçırma"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileFavorites","value":"Favori Ürünlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profilePoints","value":"Puanlarım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileSupport","value":"Yardım ve Destek"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"successAlternativeDescription","value":"Siparişin ve oluşturmuş olduğun taleplerinle ilgili 850'li numaralı telefondan aranabilirsin. Numara geri aramaya kapalıdır."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecini hızlandırabilir, özel fırsatlara erişebilirsin"},{"type":"anonAuthenticationTitle","value":"Siparişine Devam Et"},{"type":"authenticationTitle","value":"Hoş Geldin"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerini kullanarak alışverişini daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <p>Kampanya, 01.02.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</p> <ul> <li> Kampanyadan yararlanabilmek için \"Hesabım\" kısmındaki \"Arkadaşına Öner, Kazan!\" kutucuğuna tıklayıp \"Arkadaşını Davet Et\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir. </li> <li> Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 500 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır. </li> <li> Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir. </li> <li> Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir. </li> <li> Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz. </li> <li> Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir. </li> <li> Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir. </li> <li> Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir. </li> <li> Kampanya kapsamında kazanılan indirimler 500 TL ve üzeri siparişlerde geçerlidir. </li> <li> Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. </li> <li> Kampanya 100.000 kullanım kotası ile sınırlıdır. </li> <li> Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. </li> <li> Kampanya yalnızca Migros Hemen'de geçerlidir. </li> <li> Migros Hemen (Dijital Platform Gıda Hizmetleri A. Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. </li> <li> Başka kampanyalar ile birleştirilemez. </li> <li> Tek kullanımlıktır, bölünemez. </li> <li> Para ile satılamaz veya paraya çevrilemez. </li> <li> Karşılığında para iadesi yapılamaz. </li> <li> Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır. </li> <li> Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir. </li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşını Davet Et"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere!"},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"},{"type":"productDetailTGA","value":"Teslimat saatini beklemeden, siparişini Tıkla Gel Al ile hemen alabilirsin."},{"type":"timeSlotTGA","value":"Teslimat saatini beklemeden, siparişini Tıkla Gel Al ile hemen alabilirsin."},{"type":"searchNoResultTGA","value":"Adrese teslimatta bulamadığın ürünler için Tıkla Gel Al hizmetini deneyebilirsin."},{"type":"orderSuccessPickUpTitle","value":"Siparişimi nasıl teslim alacağım?"},{"type":"orderSuccessPickUpFirstText","value":"Siparişin, seçtiğin teslimat saatine kadar hazırlanacak ve hazır olduğunda sana SMS ya da bildirim gönderilecek."},{"type":"orderSuccessPickUpSecondText","value":"Seçtiğin saat aralığında mağazadaki Tıkla Gel Al teslim noktasına gelmelisin."}],"PET":[{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"OrderSuccessCargoText","value":"Ürünlerin 1-7 iş günü içerisinde kargoya verilecektir. Kargonu siparişlerim altından takip edebilirsin."},{"type":"CheckoutCargoTextTitle","value":"Kargo ile Adrese Teslim"},{"type":"CheckoutCargoText","value":"Ürünlerin 1-7 iş günü içerisinde kargoya verilecektir."},{"type":"CheckoutBagTitle","value":"Poşet Seçimi"},{"type":"CheckoutPlasticBag","value":"Poşetli teslimat istiyorum"},{"type":"CheckoutShoppingBag","value":"Alışveriş çantalı teslimat istiyorum"},{"type":"CheckoutPaperBag","value":"Kağıt poşetli teslimat istiyorum"},{"type":"CheckoutBagQuestion","value":"Siparişim kaç adet poşet ile gelir?"},{"type":"CheckoutBagAnswer","value":"Sepete eklenen ürünlerin hacmine göre poşet ücreti hesaplanmaktadır."},{"type":"CheckoutBagPriceInfo","value":"Poşet Ücreti Hakkında"},{"type":"CheckoutBagPriceAnswer","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı'nın mevzuatı gereği plastik poşetler ücretli olacaktır ve poşetlerin 25 Kuruş ücret karşılığında verilmesi zorunlu hale gelmiştir. Yasa kapsamında Migros Sanal Market'te de ücretli poşet uygulamasına geçmiştir. 31 Mart 2019 itibariyle plastik poşete alternatif olarak, farklı kullanım amaçlarını da destekleyecek tekrar kullanılabilir alışveriş çantası ürettik. Dilerseniz bu çantalar ile teslimatınızı yapabiliriz. Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için ürün gruplarına göre sınıflandırarak ayrı ayrı minimum adette poşet veya bez çanta kullanmaya çalışıyoruz. Siparişleri temin eden çalışanımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"CheckoutBagPriceFormat","value":"Adedi %@"},{"type":"OrderSuccessReferralTitle","value":"Arkadaşına Öner, 50 TL Kazan!"},{"type":"OrderSuccessReferralText","value":"Migros Hemen'i arkadaşlarına öner, 50 TL indirim hemen senin olsun!"},{"type":"OrderSuccessReferralButton","value":"Arkadaşını Davet Et"},{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"CheckoutProvisionText","value":"Siparişinizde gramaj fazlalığı olma ihtimaline karşı banka tarafından fazladan provizyon ödemesi alınmaktadır. Fazladan alınan tutar provizyonda tutulup sipariş teslimi sonrasında yalnızca fatura tutarı kadar kesin çekim yapılmakta, kalan tutar kredi kartlarında aynı gün/debit kartlarda ise ertesi gün geri iade edilmektedir. Provizyon tutarı bankanıza göre değişir."},{"type":"CheckoutProvisionTitle","value":"Banka Provizyonu Hakkında"},{"type":"HelpAndSupportContactText","value":"Siparişinizle ve oluşturmuş olduğunuz taleplerle ilgili 850'li bir numaradan iletişime geçeceğiz."},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"checkoutLoanTitle","value":"Şimdi Al, Sonra Öde"},{"type":"checkoutLoanSubTitle","value":"Erteleyerek ödeme fırsat"},{"type":"checkoutOtherPaymentTitle","value":"Farklı Ödeme Yöntemleri"},{"type":"checkoutOtherPaymentSubTitle","value":"Kapıda Ödeme ve Dijital Banka Ödemeleri"},{"type":"checkoutWalletSubTitle","value":"Money Ayrıcalıklarını Kullan\t"},{"type":"successRegistrationBulletOne","value":"Üye ol ilk siparişine 200 TL indirim,"},{"type":"successRegistrationBulletTwo","value":" İlk Siparişine özel ücretsiz teslimat."},{"type":"successRegistrationBulletThree","value":" Money üyesi ol Money'li fiyatlardan kaçırma"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileFavorites","value":"Favori Ürünlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profilePoints","value":"Puanlarım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileSupport","value":"Yardım ve Destek"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"successAlternativeDescription","value":"Siparişin ve oluşturmuş olduğun taleplerinle ilgili 850'li numaralı telefondan aranabilirsin. Numara geri aramaya kapalıdır."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecini hızlandırabilir, özel fırsatlara erişebilirsin"},{"type":"anonAuthenticationTitle","value":"Siparişine Devam Et"},{"type":"authenticationTitle","value":"Hoş Geldin"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerini kullanarak alışverişini daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <p>Kampanya, 01.02.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</p> <ul> <li> Kampanyadan yararlanabilmek için \"Hesabım\" kısmındaki \"Arkadaşına Öner, Kazan!\" kutucuğuna tıklayıp \"Arkadaşını Davet Et\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir. </li> <li> Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 500 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır. </li> <li> Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir. </li> <li> Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir. </li> <li> Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz. </li> <li> Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir. </li> <li> Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir. </li> <li> Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir. </li> <li> Kampanya kapsamında kazanılan indirimler 500 TL ve üzeri siparişlerde geçerlidir. </li> <li> Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. </li> <li> Kampanya 100.000 kullanım kotası ile sınırlıdır. </li> <li> Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. </li> <li> Kampanya yalnızca Migros Hemen'de geçerlidir. </li> <li> Migros Hemen (Dijital Platform Gıda Hizmetleri A. Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. </li> <li> Başka kampanyalar ile birleştirilemez. </li> <li> Tek kullanımlıktır, bölünemez. </li> <li> Para ile satılamaz veya paraya çevrilemez. </li> <li> Karşılığında para iadesi yapılamaz. </li> <li> Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır. </li> <li> Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir. </li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşını Davet Et"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere!"},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"}],"SANALMARKET":[{"type":"bagCountInfo","value":"Siparişleriniz gıda güvenliğine uygun olarak sizlere teslim edebilmek için, ürün gruplarına göre sınıflandırarak olabilecek en az poşet kullanımı ile size ulaştırmaya çalışıyoruz. Poşet veya alışveriş çanta kullanım adetleri ürün çeşitliliğine göre değişmektedir.Sipariş ettiğiniz ürünlerin; taze meyve sebze, temizlik malzemeleri veya donuk ürünlerin bir arada taşınması, hem ürünler açısından hem de siz müşterilerimizin sağlığı açısından sakıncalı olacağından, ürünleri ayrı poşet veya alışveriş çantalarına yerleştirmekteyiz.Siparişleri temin eden çalışanımız, bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı, poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"bagInfo","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı’nın mevzuatı gereği plastik poşetlerin 50 Kr ücret karşılığı verilmesi zorunlu hale getirildi. Yasa ile birlikte Migros Sanal Market’te siparişlerinizi hazırlamak için kullandığımız poşetler de ücretli hale geldi.Plastik poşet kullanımını azaltmak amacıyla alternatif olarak tekrar kullanılabilir Alışveriş Çantalarımızı da beğeninize sunuyoruz, dilerseniz siparişlerinizi Alışveriş Çantaları ile de hazırlayıp sizlere ulaştırabiliriz.Siparişlerinizi gıda güvenliğine uygun koşullarda sizlere teslim edebilmek konusunda çok hassasız, bunun için siparişinizi ürün gruplarına göre sınıflandırarak gıda-gıdadışı-soğuk ürünler şeklinde ayrıştırıyoruz, ancak çevre konusunda da çok hassas olduğumuzdan minimum adette poşet veya alışveriş çantası kullanmaya da özen gösteriyoruz.Siparişlerinizi özenle hazırlayan alışveriş danışmanlarımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yapması sebebiyle siparişinizde kaç adet poşet veya çanta kullanılacağı ancak sipariş hazırlama aşamasında belirlenebiliyor."},{"type":"bagPriceInfo","value":"1 Ocak 2019 tarihi itibari ile Çevre ve Şehircilik Bakanlığı’nın kararı uyarınca plastik poşetler adedi 50 kuruş olarak ücretlendirilecektir. Poşet bedeli siparişinizin hazırlanma aşamasında (sipariş kapasitenize göre) belirlenecek olup sipariş tutarınıza yansıtılacaktır."},{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"deliveryPriceInfo","value":"<strong>Teslimat ücretiniz ödeme adımında gösterilecektir.</strong><br/>Teslimat ücreti; seçtiğiniz bölge, zaman ve sipariş tutarınız ile değişkenlik gösterebilir.<br/><br/><strong>Sipariş tutarına göre teslimat tutarları:</strong><br/><strong>60 TL - 149,99 TL</strong> arası <strong>5,90 TL</strong> (KDV Dahil)<br/><strong>150 TL - 249,99 TL</strong> arası <strong>3,90 TL</strong> (KDV Dahil)<br/><strong>250 TL</strong> ve üzeri <strong>ücretsiz</strong>"},{"type":"emailVerificationReminderDesc","value":"Siparişlerinle ilgili e-postaları almaya devam etmek için <b>%1$s</b> adresini doğrulaman gerektiğini hatırlatırız."},{"type":"emailVerificationReminderTitle","value":"E-posta adresini doğrulamayı unutma"},{"type":"noteNotUpdatedable","value":"Hazırlanmaya başladıktan sonra not eklenemez."},{"type":"plasticBagPriceInfo","value":"Poşetli teslimat istiyorum."},{"type":"preAuthText","value":"Sipariş tutarı kartınızda provizyonda bekler, siparişiniz size teslim edildiğinde sadece teslim aldığınız ürünlerin ücreti kartınızdan çekilir, tedarik edilmeyen ürünler için ücret ödemezsiniz. Kartınızdan alınan provizyon oranı bankanıza göre değişiklik göstermektedir."},{"type":"returnShipmentExpirationInfo","value":"İade etmek istediğin ürünleri faturası ve iade kodu ile birlikte en geç 15 iş günü içinde kargo firmasına teslim etmen gerekiyor."},{"type":"returnShipmentInfo","value":"Siparişin içerisinden seçtiğin ürünleri sipariş faturası ve oluşturacağın iade kodu ile birlikte kargo firmasına teslim ederek iade edebilirsin."},{"type":"returnShipmentProcessFollowUpInfo","value":"İade sürecini ilgili siparişin detay sayfası üzerinden ya da 0850 200 40 00 numaralı çağrı merkezini arayarak takip edebilirsin."},{"type":"shoppingBagPriceInfo","value":"Alışveriş çantalı teslimat istiyorum."},{"type":"specialDiscountInfo","value":"Gördüğünüze İnanın Kampanyası, Money Kart ile yapılan her 300 TL’lik alışverişte geçerlidir. Her 300 TL’lik alışverişte kampanyadaki ürünlerden bir tanesi alınabilir. Kampanyaya Ramazan kolileri, 23 Nisan kampanya ürünleri, alkollü içkiler, sigara, operatör, TL ürün yükleme satışları, Sinemia Kart paketi, elektrikli ve elektronik ürünler, bahçe-ev-plaj-ofis mobilyaları, egzersiz aletleri, kuyum ürünleri, fırsat paketleri müşteri poşetleri ve yeniden satış amaçlı toplu satın alımlar dahil değildir. Money kullanılarak yapılan ödemelerde, Money tutarı kampanya harcama kotasına dahil değildir. Gördüğünüze İnanın Kampanyası başka kampanya ile birleştirilemez. Kampanyada yer alan ürünler stoklarla sınırlıdır. Ürün stoklarının anlık değişkenlik göstermesi nedeniyle siparişinizde tedarik edilemeyen ürünler bulunabilir. Bu durumunda, kampanya koşullarını sağladığınız ölçüde indirimden faydalanabilirsiniz."},{"type":"specialPromotionDescription","value":"Her 300 TL ve üzeri alışverişinizde inanılmaz indirimler sizi bekliyor!"},{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Kapıya Bırak"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım/Alışveriş Kodlarım\t"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Siparişinizle ilgili notunuzu buradan bize iletebilirsiniz."},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"CheckoutCargoTextTitle","value":"Kargo ile Adrese Teslim"},{"type":"CheckoutCargoText","value":"Ürünlerin 1-7 iş günü içerisinde kargoya verilecektir."},{"type":"CheckoutBagTitle","value":"Poşet Seçimi"},{"type":"CheckoutPlasticBag","value":"Poşetli teslimat istiyorum"},{"type":"CheckoutShoppingBag","value":"Çevreci çanta ile teslimat istiyorum."},{"type":"CheckoutPaperBag","value":"Kağıt poşetli teslimat istiyorum"},{"type":"CheckoutBagQuestion","value":"Siparişim kaç adet poşet ile gelir?"},{"type":"CheckoutBagAnswer","value":"Sepete eklenen ürünlerin hacmine göre poşet ücreti hesaplanmaktadır."},{"type":"CheckoutBagPriceInfo","value":"Poşet Ücreti Hakkında"},{"type":"CheckoutBagPriceAnswer","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı'nın mevzuatı gereği plastik poşetler ücretli olacaktır ve poşetlerin 50 Kuruş ücret karşılığında verilmesi zorunlu hale gelmiştir. Yasa kapsamında Migros Sanal Market'te de ücretli poşet uygulamasına geçmiştir. 31 Mart 2019 itibariyle plastik poşete alternatif olarak, farklı kullanım amaçlarını da destekleyecek tekrar kullanılabilir alışveriş çantası ürettik. Dilerseniz bu çantalar ile teslimatınızı yapabiliriz. Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için ürün gruplarına göre sınıflandırarak ayrı ayrı minimum adette poşet veya bez çanta kullanmaya çalışıyoruz. Siparişleri temin eden çalışanımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"CheckoutBagPriceFormat","value":"Adedi %@"},{"type":"OrderSuccessCargoText","value":"Ürünlerin 1-7 iş günü içerisinde kargoya verilecektir. Kargonu siparişlerim altından takip edebilirsin."},{"type":"OrderSuccessReferralTitle","value":"Arkadaşına Öner, 50 TL Kazan!"},{"type":"OrderSuccessReferralText","value":"Migros Hemen'i arkadaşlarına öner, 50 TL indirim hemen senin olsun!"},{"type":"OrderSuccessReferralButton","value":"Arkadaşını Davet Et"},{"type":"CheckoutProvisionText","value":"Siparişinizde alternatif ürün veya gramaj fazlalığı olma ihtimaline karşı banka tarafından fazladan provizyon ödemesi alınmaktadır. Fazladan alınan tutar provizyonda tutulup sipariş teslimi sonrasında yalnızca fatura tutarı kadar kesin çekim yapılmaktadır. Kalan tutar kredi kartlarında aynı gün, banka kartlarında ise ertesi gün geri iade edilmektedir. Provizyon tutarı bankanıza göre değişir."},{"type":"CheckoutProvisionTitle","value":"Banka Provizyonu Hakkında"},{"type":"HelpAndSupportContactText","value":"Siparişinizle ve oluşturmuş olduğunuz taleplerle ilgili 850'li numaradan aranabilirsiniz."},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"checkoutLoanTitle","value":"Şimdi Al, Sonra Öde"},{"type":"checkoutLoanSubTitle","value":"Erteleyerek Ödeme Fırsatı"},{"type":"checkoutOtherPaymentTitle","value":"Farklı Ödeme Yöntemleri"},{"type":"checkoutOtherPaymentSubTitle","value":"Dijital Banka Ödemeleri"},{"type":"checkoutWalletSubTitle","value":"Money Ayrıcalıklarını Kullan\t"},{"type":"successRegistrationBulletOne","value":"Üye ol ilk siparişine 200 TL indirim,"},{"type":"successRegistrationBulletTwo","value":" İlk Siparişine özel ücretsiz teslimat."},{"type":"successRegistrationBulletThree","value":" Money üyesi ol Money'li fiyatlardan kaçırma"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileFavorites","value":"Favori Ürünlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profilePoints","value":"Puanlarım"},{"type":"profileHealthylifejourney","value":"Sağlıklı Yaşam Yolculuğum"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileSupport","value":"Yardım ve Destek"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"successAlternativeDescription","value":"Siparişin ve oluşturmuş olduğun taleplerinle ilgili 850'li numaralı telefondan aranabilirsin. Numara geri aramaya kapalıdır."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecini hızlandırabilir, özel fırsatlara erişebilirsin"},{"type":"anonAuthenticationTitle","value":"Siparişine Devam Et"},{"type":"authenticationTitle","value":"Hoş Geldin"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerini kullanarak alışverişini daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <p>Kampanya, 01.02.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</p> <ul> <li> Kampanyadan yararlanabilmek için \"Hesabım\" kısmındaki \"Arkadaşına Öner, Kazan!\" kutucuğuna tıklayıp \"Arkadaşını Davet Et\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir. </li> <li> Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 500 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır. </li> <li> Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir. </li> <li> Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir. </li> <li> Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz. </li> <li> Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir. </li> <li> Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir. </li> <li> Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir. </li> <li> Kampanya kapsamında kazanılan indirimler 500 TL ve üzeri siparişlerde geçerlidir. </li> <li> Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. </li> <li> Kampanya 100.000 kullanım kotası ile sınırlıdır. </li> <li> Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. </li> <li> Kampanya yalnızca Migros Hemen'de geçerlidir. </li> <li> Migros Hemen (Dijital Platform Gıda Hizmetleri A. Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. </li> <li> Başka kampanyalar ile birleştirilemez. </li> <li> Tek kullanımlıktır, bölünemez. </li> <li> Para ile satılamaz veya paraya çevrilemez. </li> <li> Karşılığında para iadesi yapılamaz. </li> <li> Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır. </li> <li> Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir. </li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşını Davet Et"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere! "},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"},{"type":"productDetailTGA","value":"Teslimat saatini beklemeden, siparişini Tıkla Gel Al ile hemen alabilirsin."},{"type":"timeSlotTGA","value":"Teslimat saatini beklemeden, siparişini Tıkla Gel Al ile hemen alabilirsin."},{"type":"searchNoResultTGA","value":"Adrese teslimatta bulamadığın ürünler için Tıkla Gel Al hizmetini deneyebilirsin."},{"type":"orderSuccessPickUpTitle","value":"Siparişimi nasıl teslim alacağım?"},{"type":"orderSuccessPickUpFirstText","value":"Siparişin, seçtiğin teslimat saatine kadar hazırlanacak ve hazır olduğunda sana SMS ya da bildirim gönderilecek."},{"type":"orderSuccessPickUpSecondText","value":"Seçtiğin saat aralığında mağazadaki Tıkla Gel Al teslim noktasına gelmelisin."}],"TAZEDIREKT":[{"type":"bagInfo","value":"Bazı ürünlerimizi plastik poşet ile gönderiyoruz. <strong>0,25₺/adet</strong> poşet bedelini hazırlanma aşamasında hesaplayarak faturanıza yansıtacağız."},{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"emailVerificationReminderDesc","value":"Siparişlerinle ilgili e-postaları almaya devam etmek için %@ adresini doğrulaman gerektiğini hatırlatırız."},{"type":"emailVerificationReminderTitle","value":"E-posta adresini doğrulamayı unutma"},{"type":"mainPageInfo","value":"İstanbul, Ankara, Bursa, Kocaeli ve İzmir'deyiz!"},{"type":"noteNotUpdatedable","value":"Hazırlanmaya başladıktan sonra not eklenemez."},{"type":"referralPagePart1","value":"Sevdiklerinizin Ne Yediğini Önemseyin!"},{"type":"referralPagePart2","value":"Tazedirekt’i sevdiklerinize önerin, 50 TL indirim kazanın."},{"type":"referralPagePart3","value":"Harika değil mi? Bu davet ile siz 50 TL indirim kazanıyorsunuz, daveti kabul eden arkadaşınızsa ilk siparişini 50 TL indirimli veriyor."},{"type":"referralPagePart4","value":"Hemen aşağıdaki linki kopyala ve sevdiklerinle paylaş!"},{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım/Alışveriş Kodlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"CheckoutCargoTextTitle","value":"Kargo ile Adrese Teslim"},{"type":"CheckoutCargoText","value":"Ürünlerin 1-3 iş günü içerisinde kargoya verilecektir."},{"type":"CheckoutBagTitle","value":"Poşet Seçimi"},{"type":"CheckoutPlasticBag","value":"Poşetli teslimat istiyorum"},{"type":"CheckoutShoppingBag","value":"Alışveriş çantalı teslimat istiyorum"},{"type":"CheckoutPaperBag","value":"Kağıt poşetli teslimat istiyorum"},{"type":"CheckoutBagQuestion","value":"Siparişim kaç adet poşet ile gelir?"},{"type":"CheckoutBagAnswer","value":"Sepete eklenen ürünlerin hacmine göre poşet ücreti hesaplanmaktadır."},{"type":"CheckoutBagPriceInfo","value":"Poşet Ücreti Hakkında"},{"type":"CheckoutBagPriceAnswer","value":"1 Ocak 2019 tarihi itibariyle Çevre ve Şehircilik Bakanlığı'nın mevzuatı gereği plastik poşetler ücretli olacaktır ve poşetlerin 50 Kuruş ücret karşılığında verilmesi zorunlu hale gelmiştir. Yasa kapsamında Migros Sanal Market'te de ücretli poşet uygulamasına geçmiştir. 31 Mart 2019 itibariyle plastik poşete alternatif olarak, farklı kullanım amaçlarını da destekleyecek tekrar kullanılabilir alışveriş çantası ürettik. Dilerseniz bu çantalar ile teslimatınızı yapabiliriz. Siparişlerinizi gıda güvenliğine uygun olarak sizlere teslim edebilmek için ürün gruplarına göre sınıflandırarak ayrı ayrı minimum adette poşet veya bez çanta kullanmaya çalışıyoruz. Siparişleri temin eden çalışanımızın bu kriterlere uygun bir şekilde poşetleme veya çantalama yaptığından dolayı poşet veya çanta kullanım adeti sipariş hazırlanma aşamasında belirlenebilmektedir."},{"type":"CheckoutBagPriceFormat","value":"Adedi %@"},{"type":"OrderSuccessReferralTitle","value":"Arkadaşına Öner, 50 TL Kazan!"},{"type":"OrderSuccessReferralText","value":"Migros Hemen'i arkadaşlarına öner, 50 TL indirim hemen senin olsun!"},{"type":"OrderSuccessReferralButton","value":"Arkadaşını Davet Et"},{"type":"CheckoutProvisionText","value":"Siparişinizde alternatif ürün veya gramaj fazlalığı olma ihtimaline karşı banka tarafından fazladan provizyon ödemesi alınmaktadır. Fazladan alınan tutar provizyonda tutulup sipariş teslimi sonrasında yalnızca fatura tutarı kadar kesin çekim yapılmaktadır. Kalan tutar kredi kartlarında aynı gün, debit kartlarda ise ertesi gün geri iade edilmektedir. Provizyon tutarı bankanıza göre değişir."},{"type":"CheckoutProvisionTitle","value":"Banka Provizyonu Hakkında"},{"type":"HelpAndSupportContactText","value":"Siparişinizin teslimatı ile ilgili 0850'li numaradan, oluşturmuş olduğunuz taleplerle ilgili 444'lü numaradan aranabilirsiniz."},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"checkoutLoanTitle","value":"Şimdi Al, Sonra Öde"},{"type":"checkoutLoanSubTitle","value":"Erteleyerek Ödeme Fırsatı"},{"type":"checkoutOtherPaymentTitle","value":"Farklı Ödeme Yöntemleri"},{"type":"checkoutOtherPaymentSubTitle","value":"Dijital Banka Ödemeleri"},{"type":"checkoutWalletSubTitle","value":"Money Ayrıcalıklarını Kullan\t"},{"type":"successRegistrationBulletOne","value":"Üye ol ilk siparişine 200 TL indirim,"},{"type":"successRegistrationBulletTwo","value":" İlk Siparişine özel ücretsiz teslimat."},{"type":"successRegistrationBulletThree","value":" Money üyesi ol Money'li fiyatlardan kaçırma"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileFavorites","value":"Favori Ürünlerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profilePoints","value":"Puanlarım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileSupport","value":"Yardım ve Destek"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"successAlternativeDescription","value":"Siparişin ve oluşturmuş olduğun taleplerinle ilgili 850'li numaralı telefondan aranabilirsin. Numara geri aramaya kapalıdır."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecini hızlandırabilir, özel fırsatlara erişebilirsin"},{"type":"anonAuthenticationTitle","value":"Siparişine Devam Et"},{"type":"authenticationTitle","value":"Hoş Geldin"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerini kullanarak alışverişini daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <p>Kampanya, 01.02.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</p> <ul> <li> Kampanyadan yararlanabilmek için \"Hesabım\" kısmındaki \"Arkadaşına Öner, Kazan!\" kutucuğuna tıklayıp \"Arkadaşını Davet Et\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir. </li> <li> Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 500 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır. </li> <li> Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir. </li> <li> Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir. </li> <li> Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz. </li> <li> Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir. </li> <li> Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir. </li> <li> Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir. </li> <li> Kampanya kapsamında kazanılan indirimler 500 TL ve üzeri siparişlerde geçerlidir. </li> <li> Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. </li> <li> Kampanya 100.000 kullanım kotası ile sınırlıdır. </li> <li> Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. </li> <li> Kampanya yalnızca Migros Hemen'de geçerlidir. </li> <li> Migros Hemen (Dijital Platform Gıda Hizmetleri A. Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. </li> <li> Başka kampanyalar ile birleştirilemez. </li> <li> Tek kullanımlıktır, bölünemez. </li> <li> Para ile satılamaz veya paraya çevrilemez. </li> <li> Karşılığında para iadesi yapılamaz. </li> <li> Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır. </li> <li> Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir. </li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşını Davet Et"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere! "},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"}],"YEMEK":[{"type":"deleteAccountLegalText","value":"<div> <p>Hesabınızı silmek istediğiniz için üzgünüz;</p> <ul> <li> Hesabınızı sildiğinizde mevcut hesabınızı yeniden aktif edemeyeceksiniz, favorileriniz ve sipariş geçmişinizi görüntüleyemeyeceksiniz, tarafınıza tanımlı dijital kodları, hediye çeklerini kullanamayacaksınız. </li> <li> Hesap silme talebini ilettiğiniz hesap aracılığıyla kullandığınız Migros Uygulaması içindeki diğer hizmetleri de bu hesabınız ile artık kullanamayacaksınız. </li> <li> Hesabınıza bağlı iletişim bilgileriniz üzerinden tarafınıza elektronik ticari ileti gönderilmeyecektir. </li> <li> Eğer teslimatı devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızda söz konusu tutar provizyon olarak tutularak ürün teslimatı yapıldığında tahsilat gerçekleştirilecektir. </li> <li> Eğer ödemesi devam eden bir ürününüz varsa, hesabınız silinse bile kayıtlı kredi kartınızdan tahsilat yapılmaya devam edilecektir. </li> <li> Hesap silme bir kişisel veri silme işlemi değildir. </li> </ul> </div>"},{"type":"checkoutTitle","value":"Siparişi Tamamla"},{"type":"checkoutRingBell","value":"Zili Çalma"},{"type":"checkoutContactless","value":"Temassız Teslimat"},{"type":"checkoutDeliveryAddress","value":"Teslimat Adresin"},{"type":"checkoutDeliveryTime","value":"Teslimat Zamanın"},{"type":"checkoutPaymentMethod","value":"Ödeme Yöntemin"},{"type":"checkoutPoints","value":"Puanlarım"},{"type":"checkoutCouponsCode","value":"Kupon Kodu Kullan"},{"type":"checkoutCouponsCodeUse","value":"Kullan"},{"type":"checkoutOrderNote","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderNoteDesc","value":"Sipariş Notu Ekle"},{"type":"checkoutOrderSummary","value":"Sipariş Özeti"},{"type":"checkoutOrderComplete","value":"Ödeme Yap"},{"type":"checkoutWalletTitle","value":"Cüzdan'a Yükle ve Öde"},{"type":"successStatus","value":"Sipariş Alındı"},{"type":"successOrderNumber","value":"Sipariş Numarası:"},{"type":"successOrders","value":"Siparişlerim"},{"type":"successOrderInfo","value":"Sipariş Bilgileri"},{"type":"successAmount","value":"Sipariş Tutarı"},{"type":"successItemCount","value":"Sepetindeki Ürün Adedi"},{"type":"successDeliveryFee","value":"Teslimat Tutarı"},{"type":"successDiscount","value":"Migros İndirimi"},{"type":"successTotal","value":"Genel Toplam"},{"type":"successHomepage","value":"Anasayfaya Dön"},{"type":"successAdditionalOrder","value":"Siparişe Ek Yap"},{"type":"OrderSuccessReferralTitle","value":"Arkadaşına Öner, 50 TL Kazan!"},{"type":"OrderSuccessReferralText","value":"Migros Hemen'i arkadaşlarına öner, 50 TL indirim hemen senin olsun!"},{"type":"OrderSuccessReferralButton","value":"Arkadaşını Davet Et"},{"type":"HelpAndSupportContactText","value":"Siparişinizle ve oluşturmuş olduğunuz taleplerle ilgili 850'li bir numaradan iletişime geçeceğiz."},{"type":"CheckoutMoneyDetail","value":"Money Cüzdan hesabınızda öncelikli bakiye kullanımı Money Para’dır. Burada yer alan bakiyeniz bittikten sonra Money Cüzdan hesabınızdan harcama yapılacaktır. Money Cüzdan ile yapılan ödemelerde banka tarafından %15 provizyon alınmaktadır.\t"},{"type":"checkoutLoanTitle","value":"Şimdi Al, Sonra Öde"},{"type":"checkoutLoanSubTitle","value":"Erteleyerek Ödeme Fırsatı"},{"type":"checkoutOtherPaymentTitle","value":"Farklı Ödeme Yöntemleri"},{"type":"checkoutOtherPaymentSubTitle","value":"Kapıda Ödeme ve Dijital Banka Ödemeleri"},{"type":"checkoutWalletSubTitle","value":"Money Ayrıcalıklarını Kullan\t"},{"type":"successRegistrationBulletOne","value":"Üye ol ilk siparişine 200 TL indirim,"},{"type":"successRegistrationBulletTwo","value":" İlk Siparişine özel ücretsiz teslimat."},{"type":"successRegistrationBulletThree","value":" Money üyesi ol Money'li fiyatlardan kaçırma"},{"type":"serviceselectionSearch","value":"Ürün, yemek veya hizmet ara"},{"type":"profileTitle","value":"Hesabım"},{"type":"profileAddresses","value":"Adreslerim"},{"type":"profileOrders","value":"Siparişlerim"},{"type":"profileYemekFavorites","value":"Favorilerim"},{"type":"profileSavedcards","value":"Kayıtlı Kartlarım"},{"type":"profileMoneypay","value":"Money Cüzdanım"},{"type":"profileAccountsettings","value":"Hesap Ayarları"},{"type":"profileLanguage","value":"Dil & Uygulama Ayarları"},{"type":"profileFAQ","value":"Sıkça Sorulan Sorular"},{"type":"profileOrderTracking","value":"Sipariş Takibi"},{"type":"profileOrderTrackingDesc","value":"Üye olmayan kullanıcılar için"},{"type":"profileLogin","value":"Üye ol veya Giriş Yap"},{"type":"ringBellDesc","value":"Teslimat danışmanı adresine geldiğinde seni 850’li bir numaradan arayacak."},{"type":"successAlternativeDescription","value":"Siparişin ve oluşturmuş olduğun taleplerinle ilgili 850'li numaralı telefondan aranabilirsin. Numara geri aramaya kapalıdır."},{"type":"anonAuthenticationDesc","value":"Giriş yaparak ya da üye olarak ödeme sürecini hızlandırabilir, özel fırsatlara erişebilirsin"},{"type":"anonAuthenticationTitle","value":"Siparişine Devam Et"},{"type":"authenticationTitle","value":"Hoş Geldin"},{"type":"authenticationDesc","value":"Kayıtlı adres ve ödeme bilgilerini kullanarak alışverişini daha hızlı tamamlamak için"},{"type":"unimoneyApprovalStageDrawerButton","value":"Anlaştık!"},{"type":"unimoneyApprovalStageDrawer","value":"Selam! Belgen artık doğrulanma aşamasında. Sana kısa bir süre içinde haber vereceğiz!"},{"type":"unimoneyApprovalStageDrawerTitle","value":"Selam!"},{"type":"referralDetailsAndConditions","value":"<div> <p>Kampanya, 01.02.2025 saat 00:00 ile 31.12.2025 saat 23:59 tarihleri arasında geçerlidir.</p> <ul> <li> Kampanyadan yararlanabilmek için \"Hesabım\" kısmındaki \"Arkadaşına Öner, Kazan!\" kutucuğuna tıklayıp \"Arkadaşını Davet Et\" butonuna tıkladıktan sonra çıkan paylaşma seçeneklerinden birini seçip, arkadaşlarınıza davet linkini iletmeniz gerekmektedir. </li> <li> Arkadaşınız ilgili davet linkine tıklayıp kayıt olduktan sonra ilk siparişini oluşturursa, sipariş tamamlandıktan sonra hem siz hem de arkadaşınız 500 TL ve üzeri siparişte geçerli 100 TL indirim kazanmaktadır. </li> <li> Kampanyadan yararlanabilmeniz için en az 1 sipariş vermiş olmanız gerekmektedir. </li> <li> Kampanyadan yararlanabilmeniz için davet ettiğiniz arkadaşınızın Migros Hemen'e kaydolması ve en az 1 sipariş oluşturması gerekmektedir. </li> <li> Kampanya kapsamında en fazla 5 arkadaşınızı davet edip kampanyadan faydalanabilirsiniz. </li> <li> Kullanıcılar kampanya kapsamında en fazla 5 kez 100 TL değerinde indirim kazanabilir. </li> <li> Kampanya koşullarını sağlayarak arkadaşını davet eden kullanıcılar 5 ayrı siparişi için ayrı ayrı 100 TL; toplamda 500 TL değerinde indirim kazanabilir. </li> <li> Kazanılan 100 TL'lik indirimler ayrı ayrı siparişlerde kullanılabilecektir. </li> <li> Kampanya kapsamında kazanılan indirimler 500 TL ve üzeri siparişlerde geçerlidir. </li> <li> Ayçiçek yağı, Nutella ürünleri, Toz ve Küp şekerler, Dökme Çay, Taze kırmızı et ürünleri, Enerji içeceği ürünleri hariç olarak hesaplanacaktır, bu ürünler kampanyaya dahil değildir. </li> <li> Kampanya 100.000 kullanım kotası ile sınırlıdır. </li> <li> Belirlenen kampanya kotasına ulaşıldığı takdirde Migros Hemen kampanyayı durdurma hakkını saklı tutar. </li> <li> Kampanya yalnızca Migros Hemen'de geçerlidir. </li> <li> Migros Hemen (Dijital Platform Gıda Hizmetleri A. Ş.) kampanya koşullarında değişiklik yapma hakkını saklı tutar. </li> <li> Başka kampanyalar ile birleştirilemez. </li> <li> Tek kullanımlıktır, bölünemez. </li> <li> Para ile satılamaz veya paraya çevrilemez. </li> <li> Karşılığında para iadesi yapılamaz. </li> <li> Sipariş iptal veya iadesinde indiriminiz hesabınıza yeniden tanımlanacaktır. </li> <li> Detaylı bilgi için 0850 200 40 00 no'lu Migros müşteri hizmetlerine ulaşılabilir. </li> </ul> </div>"},{"type":"referralHeader","value":"Migros Hemen'e arkadaşlarını davet etmek sana 500 TL'ye varan indirim kazandıracak!"},{"type":"referralInfo","value":"Arkadaşını Migros Hemen'e davet et, arkadaşın ilk siparişini tamamladığında hem sen hem de arkadaşın anında 100 TL indirim kazansın! Unutma, en fazla 5 arkadaşından kupon hak edişi sağlayabilir ve toplamda 500 TL indirim kazanabilirsin! Migros Hemen'e davet ettigin arkadaşlarının durumunu da buradan takip edebilirsin."},{"type":"profileReferralTitle","value":"Arkadaşını Davet Et"},{"type":"profileReferralSubtitle","value":"Migros Hemen’i arkadaşlarına öner, 500 TL’ye varan indirim senin olsun!"},{"type":"deleteAccountDrawerTitle","value":"Ayrıldığına üzüldük!"},{"type":"deleteAccountDrawerText","value":"Hesabını sildikten sonra aşağıdaki tarihe kadar tekrar üyelik oluşturamayacaksın. Tekrar görüşmek üzere!"},{"type":"unimoneyAciklama","value":"*Açık öğretim ve doktora programlarını kapsamamaktadır."},{"type":"unimoneyAydinlatma","value":"Kişisel verileriniz, UniMoney süreçlerinin yürütülmesi için Kişisel Verilerin Korunması Hakkında Aydınlatma Metni kapsamında işlenecektir."},{"type":"unimoneyAcikRiza","value":"UniMoney programı dahilindeki tekliflerin sunulabilmesi amacıyla kişisel verilerimin Açık Rıza Metni kapsamında işlenmesine ve paylaşılmasına onay veriyorum."},{"type":"unimoneyKVKK","value":"Kişisel Verilerin Korunması Hakkında Aydınlatma Metni"},{"type":"unimoneyAcikRizaMetni","value":"Açık Rıza Metni"},{"type":"deleteAccountDrawerButton","value":"Hesabımı Kalıcı Olarak Sil"},{"type":"orderDetailReturnGenerate","value":"İade kodu oluştur"},{"type":"orderDetailReturnDesc","value":"İade kodu ile kargo şubesine iade"}]}};
  }
// XMLHttpRequest'i manipüle et (orijinal kod korunuyor)
const originalXHROpen = XMLHttpRequest.prototype.open;
const originalXHRSend = XMLHttpRequest.prototype.send;

XMLHttpRequest.prototype.open = function(method, url, ...args) {
    this._requestUrl = url;
    this._requestMethod = method;
    
    // Intercept custom-texts API calls and return custom response
    if (typeof url === 'string' && isCustomTextsEndpoint(url)) {
        console.log('XMLHttpRequest: Intercepting custom-texts API call to provide custom response:', url);
        this._interceptCustomTexts = true;
        // We'll still call the original open but handle it in send
    }
    
    // Service Worker dosyasını yakala
    if (typeof url === 'string' && isServiceWorkerFile(url)) {
        console.log('XMLHttpRequest: Service Worker dosyası yakalandı ve engellenecek:', url);
        this._isServiceWorker = true;
    }
    
    // PWA manifest dosyalarını yakala
    if (typeof url === 'string' && isPWAManifestFile(url)) {
        console.log('XMLHttpRequest: PWA manifest dosyası yakalandı ve engellenecek:', url);
        this._isPWAManifest = true;
    }
    
    // Profil ikonu dosyasını yakala
    if (typeof url === 'string' && isProfileIconFile(url)) {
        console.log('XMLHttpRequest: Profil ikonu dosyası yakalandı ve engellenecek:', url);
        this._isProfileIcon = true;
    }

    // Analytics ve tracking isteklerini yakala
    if (typeof url === 'string' && isAnalyticsOrTrackingEndpoint(url)) {
        console.log('XMLHttpRequest: Analytics/tracking isteği yakalandı ve engellenecek:', url);
        this._isAnalyticsBlocked = true;
    }

    // Yemeksepeti proxy endpoint'ini yakala
    if (typeof url === 'string' && isYsProxyEndpoint(url)) {
        this._isYsProxyEndpoint = true;
    }

    // Migros proxy endpoint'ini yakala
    if (typeof url === 'string' && isMgProxyEndpoint(url)) {
        console.log('XMLHttpRequest: MG Proxy endpoint detected:', url);
        this._isMgProxyEndpoint = true;
    }

    // Trendyol proxy endpoint'ini yakala
    if (typeof url === 'string' && isTyProxyEndpoint(url)) {
        console.log('XMLHttpRequest: TY Proxy endpoint detected:', url, 'Method:', method);
        this._isTyProxyEndpoint = true;
    }
    
    return originalXHROpen.apply(this, [method, url, ...args]);
};

XMLHttpRequest.prototype.send = function(body) {
    // MIGROS PROXY - Tüm Migros endpoint'lerini background.js'e yönlendir
    if (this._isMgProxyEndpoint) {
        console.log('Inject: Intercepting MG XHR request and proxying through background.js', this._requestUrl);
        const originalXhr = this;
        
        this.abort(); // Abort the original request

        const requestId = Date.now() + Math.random().toString().substring(2, 8);
        window.migrosKupon.xhrCallbacks = window.migrosKupon.xhrCallbacks || {};
        
        window.migrosKupon.xhrCallbacks[requestId] = (response) => {
            if (response && response.success) {
                console.log('MG Proxy yanıtı alındı:', response.status);
                
                const mockResponse = {
                    status: response.status,
                    statusText: response.statusText || '',
                    responseText: response.data,
                    response: response.data,
                    headers: response.headers || {}
                };
                
                Object.defineProperty(originalXhr, 'readyState', {
                    configurable: true,
                    get: function() { return 4; }
                });
                
                Object.defineProperty(originalXhr, 'status', {
                    configurable: true,
                    get: function() { return mockResponse.status; }
                });
                
                Object.defineProperty(originalXhr, 'statusText', {
                    configurable: true,
                    get: function() { return mockResponse.statusText; }
                });
                
                Object.defineProperty(originalXhr, 'responseText', {
                    configurable: true,
                    get: function() { return mockResponse.responseText; }
                });
                
                Object.defineProperty(originalXhr, 'response', {
                    configurable: true,
                    get: function() { return mockResponse.response; }
                });
                
                setTimeout(() => {
                    if (typeof originalXhr.onreadystatechange === 'function') {
                        originalXhr.onreadystatechange();
                    }
                    if (typeof originalXhr.onload === 'function') {
                        originalXhr.onload();
                    }
                    if (typeof originalXhr.onloadend === 'function') {
                        originalXhr.onloadend();
                    }
                    originalXhr.dispatchEvent(new Event('readystatechange'));
                    originalXhr.dispatchEvent(new Event('load'));
                    originalXhr.dispatchEvent(new Event('loadend'));
                }, 0);
            } else {
                console.error('MG Proxy hatası:', response ? response.error : 'Bilinmeyen hata');
                
                Object.defineProperty(originalXhr, 'readyState', {
                    configurable: true,
                    get: function() { return 4; }
                });
                
                Object.defineProperty(originalXhr, 'status', {
                    configurable: true,
                    get: function() { return 0; }
                });
                
                setTimeout(() => {
                    if (typeof originalXhr.onerror === 'function') {
                        originalXhr.onerror();
                    }
                    if (typeof originalXhr.onreadystatechange === 'function') {
                        originalXhr.onreadystatechange();
                    }
                    if (typeof originalXhr.onloadend === 'function') {
                        originalXhr.onloadend();
                    }
                    originalXhr.dispatchEvent(new Event('error'));
                    originalXhr.dispatchEvent(new Event('readystatechange'));
                    originalXhr.dispatchEvent(new Event('loadend'));
                }, 50);
            }
            delete window.migrosKupon.xhrCallbacks[requestId];
        };

        console.log('MG Proxy isteği gönderiliyor...');
        window.postMessage({
            source: 'MIGROS_KUPON_EXTENSION',
            action: 'mgProxyRequest',
            url: this._requestUrl,
            method: this._requestMethod || 'POST',
            headers: {},
            body: body,
            requestId: requestId
        }, '*');
        
        return;
    }

    // TRENDYOL PROXY - Tüm Trendyol endpoint'lerini background.js'e yönlendir
    if (this._isTyProxyEndpoint) {
        console.log('Inject: Intercepting TY XHR request and proxying through background.js', this._requestUrl);
        const originalXhr = this;
        
        this.abort();

        const requestId = Date.now() + Math.random().toString().substring(2, 8);
        window.migrosKupon.xhrCallbacks = window.migrosKupon.xhrCallbacks || {};
        
        window.migrosKupon.xhrCallbacks[requestId] = (response) => {
            if (response && response.success) {
                console.log('TY Proxy yanıtı alındı:', response.status);
                
                const mockResponse = {
                    status: response.status,
                    statusText: response.statusText || '',
                    responseText: response.data,
                    response: response.data,
                    headers: response.headers || {}
                };
                
                Object.defineProperty(originalXhr, 'readyState', {
                    configurable: true,
                    get: function() { return 4; }
                });
                
                Object.defineProperty(originalXhr, 'status', {
                    configurable: true,
                    get: function() { return mockResponse.status; }
                });
                
                Object.defineProperty(originalXhr, 'statusText', {
                    configurable: true,
                    get: function() { return mockResponse.statusText; }
                });
                
                Object.defineProperty(originalXhr, 'responseText', {
                    configurable: true,
                    get: function() { return mockResponse.responseText; }
                });
                
                Object.defineProperty(originalXhr, 'response', {
                    configurable: true,
                    get: function() { return mockResponse.response; }
                });
                
                setTimeout(() => {
                    if (typeof originalXhr.onreadystatechange === 'function') {
                        originalXhr.onreadystatechange();
                    }
                    if (typeof originalXhr.onload === 'function') {
                        originalXhr.onload();
                    }
                    if (typeof originalXhr.onloadend === 'function') {
                        originalXhr.onloadend();
                    }
                    originalXhr.dispatchEvent(new Event('readystatechange'));
                    originalXhr.dispatchEvent(new Event('load'));
                    originalXhr.dispatchEvent(new Event('loadend'));
                }, 0);
            } else {
                console.error('TY Proxy hatası:', response ? response.error : 'Bilinmeyen hata');
                
                Object.defineProperty(originalXhr, 'readyState', {
                    configurable: true,
                    get: function() { return 4; }
                });
                
                Object.defineProperty(originalXhr, 'status', {
                    configurable: true,
                    get: function() { return 0; }
                });
                
                setTimeout(() => {
                    if (typeof originalXhr.onerror === 'function') {
                        originalXhr.onerror();
                    }
                    if (typeof originalXhr.onreadystatechange === 'function') {
                        originalXhr.onreadystatechange();
                    }
                    if (typeof originalXhr.onloadend === 'function') {
                        originalXhr.onloadend();
                    }
                    originalXhr.dispatchEvent(new Event('error'));
                    originalXhr.dispatchEvent(new Event('readystatechange'));
                    originalXhr.dispatchEvent(new Event('loadend'));
                }, 50);
            }
            delete window.migrosKupon.xhrCallbacks[requestId];
        };

        console.log('TY Proxy isteği gönderiliyor...');
        window.postMessage({
            source: 'MIGROS_KUPON_EXTENSION',
            action: 'tyProxyRequest',
            url: this._requestUrl,
            method: this._requestMethod || 'POST',
            headers: {},
            body: body,
            requestId: requestId
        }, '*');
        
        return;
    }

    // YEMEKSEPETI PROXY
    if (this._isYsProxyEndpoint) {
        console.log('Inject: Intercepting YS XHR request and proxying through background.js', this._requestUrl);
        const originalXhr = this;
        
        this.abort(); // Abort the original request

        // Eğer cart/checkout endpoint'i ise body'i manipüle et
        let finalBody = body;
        if (this._requestUrl.includes('cart/checkout') && body) {
            try {
                const requestBody = JSON.parse(body);
                
                // Manipulate the platform and source fields
                if (requestBody.platform && requestBody.platform === 'b2c') {
                    requestBody.platform = 'Android-app-25.50.5(255050434)';
                }
                
                if (requestBody.source) {
                    requestBody.source = 'android';
                } else {
                    requestBody.source = 'android';
                }
                
                finalBody = JSON.stringify(requestBody);
            } catch (error) {
                console.error('YS Proxy: Error manipulating request body:', error);
                finalBody = body; // Fallback to original body
            }
        }

        const requestId = Date.now() + Math.random().toString().substring(2, 8);
        window.migrosKupon.xhrCallbacks = window.migrosKupon.xhrCallbacks || {};
        
        window.migrosKupon.xhrCallbacks[requestId] = (response) => {
            if (response && response.success) {
                
                const mockResponse = {
                    status: response.status,
                    statusText: response.statusText || '',
                    response: response.data,
                    responseText: response.data,
                    headers: response.headers || {},
                    getAllResponseHeaders: function() {
                        if (!this.headers || typeof this.headers !== 'object') return '';
                        return Object.entries(this.headers).map(([key, value]) => `${key}: ${value}`).join('\r\n');
                    },
                    getResponseHeader: function(name) {
                        if (!this.headers || typeof this.headers !== 'object') return null;
                        return this.headers[name.toLowerCase()] || null;
                    }
                };

                try {
                  Object.defineProperty(originalXhr, 'readyState', { value: 4, configurable: true });
                  Object.defineProperty(originalXhr, 'status', { value: mockResponse.status, configurable: true });
                  Object.defineProperty(originalXhr, 'statusText', { value: mockResponse.statusText, configurable: true });
                  Object.defineProperty(originalXhr, 'response', { value: mockResponse.response, configurable: true });
                  Object.defineProperty(originalXhr, 'responseText', { value: mockResponse.responseText, configurable: true });

                  originalXhr.getAllResponseHeaders = mockResponse.getAllResponseHeaders;
                  originalXhr.getResponseHeader = mockResponse.getResponseHeader;

                  if (typeof originalXhr.onreadystatechange === 'function') originalXhr.onreadystatechange();
                  if (response.status >= 200 && response.status < 300) {
                      if (typeof originalXhr.onload === 'function') originalXhr.onload();
                      originalXhr.dispatchEvent(new Event('load'));
                  } else {
                      if (typeof originalXhr.onerror === 'function') originalXhr.onerror();
                      originalXhr.dispatchEvent(new Event('error'));
                  }
                  if (typeof originalXhr.onloadend === 'function') originalXhr.onloadend();
                  originalXhr.dispatchEvent(new Event('loadend'));
                } catch (e) {
                    console.error("Error mocking XHR response:", e);
                }

            } else {
                console.error('YS Proxy hatası:', response ? response.error : 'Bilinmeyen hata');
                try {
                  Object.defineProperty(originalXhr, 'readyState', { value: 4, configurable: true });
                  Object.defineProperty(originalXhr, 'status', { value: 0, configurable: true });
                  Object.defineProperty(originalXhr, 'statusText', { value: 'Proxy Error', configurable: true });
                  if (typeof originalXhr.onerror === 'function') originalXhr.onerror();
                  if (typeof originalXhr.onloadend === 'function') originalXhr.onloadend();
                  originalXhr.dispatchEvent(new Event('error'));
                  originalXhr.dispatchEvent(new Event('loadend'));
                } catch (e) {
                    console.error("Error mocking XHR error response:", e);
                }
            }
            delete window.migrosKupon.xhrCallbacks[requestId];
        };

        window.postMessage({
            source: 'MIGROS_KUPON_EXTENSION',
            action: 'ysProxyRequest',
            requestId: requestId,
            url: this._requestUrl,
            method: this._requestMethod,
            headers: this._requestHeaders,
            body: finalBody
        }, '*');

        return;
    }
    // Handle custom-texts API call
    if (this._interceptCustomTexts === true) {
        console.log('XMLHttpRequest: Returning custom response for custom-texts API');
        
        // Create the custom response
        const customResponse = JSON.stringify(generateCustomTextsResponse());
        
        // Set up the mock response
        const xhr = this;
        
        // Set readyState to DONE (4)
        Object.defineProperty(xhr, 'readyState', {
            configurable: true,
            get: function() { return 4; }
        });
        
        // Set status to 200 (OK)
        Object.defineProperty(xhr, 'status', {
            configurable: true,
            get: function() { return 200; }
        });
        
        // Set statusText to OK
        Object.defineProperty(xhr, 'statusText', {
            configurable: true,
            get: function() { return 'OK'; }
        });
        
        // Set responseText and response
        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: function() { return customResponse; }
        });
        
        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get: function() { return customResponse; }
        });
        
        // Trigger all the callbacks
        setTimeout(() => {
            if (typeof xhr.onreadystatechange === 'function') {
                xhr.onreadystatechange();
            }
            
            if (typeof xhr.onload === 'function') {
                xhr.onload();
            }
            
            if (typeof xhr.onloadend === 'function') {
                xhr.onloadend();
            }
            
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('load'));
            xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        
        return; // Stop processing
    }
    
    // Service Worker dosyasını engelle
    if (this._isServiceWorker === true) {
        console.log('XMLHttpRequest: Service Worker dosyası engellendi:', this._requestUrl);
        
        // XMLHttpRequest'i iptal et
        this.abort();
        
        // 404 Not Found yanıtı oluştur
        const xhr = this;
        
        // readyState = 4 (DONE) olarak ayarla
        Object.defineProperty(xhr, 'readyState', {
            configurable: true,
            get: function() { return 4; }
        });
        
        // status = 404 (Not Found) olarak ayarla
        Object.defineProperty(xhr, 'status', {
            configurable: true,
            get: function() { return 404; }
        });
        
        // statusText = Not Found olarak ayarla
        Object.defineProperty(xhr, 'statusText', {
            configurable: true,
            get: function() { return 'Not Found'; }
        });
        
        // responseText'i boş olarak ayarla
        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: function() { return ''; }
        });
        
        // response'u boş olarak ayarla
        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get: function() { return ''; }
        });
        
        // Hata olaylarını tetikle
        setTimeout(() => {
            // error event
            if (typeof xhr.onerror === 'function') {
                xhr.onerror();
            }
            
            // readystatechange event
            if (typeof xhr.onreadystatechange === 'function') {
                xhr.onreadystatechange();
            }
            
            // loadend event
            if (typeof xhr.onloadend === 'function') {
                xhr.onloadend();
            }
            
            // Event listeners
            xhr.dispatchEvent(new Event('error'));
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        
        // İşlem tamamlandı, orijinal send işlemini durdur
        return;
    }
    
    // PWA manifest dosyalarını engelle
    if (this._isPWAManifest === true) {
        console.log('XMLHttpRequest: PWA manifest dosyası engellendi:', this._requestUrl);
        
        // XMLHttpRequest'i iptal et
        this.abort();
        
        // 404 Not Found yanıtı oluştur
        const xhr = this;
        
        // readyState = 4 (DONE) olarak ayarla
        Object.defineProperty(xhr, 'readyState', {
            configurable: true,
            get: function() { return 4; }
        });
        
        // status = 404 (Not Found) olarak ayarla
        Object.defineProperty(xhr, 'status', {
            configurable: true,
            get: function() { return 404; }
        });
        
        // statusText = Not Found olarak ayarla
        Object.defineProperty(xhr, 'statusText', {
            configurable: true,
            get: function() { return 'Not Found'; }
        });
        
        // responseText'i boş olarak ayarla
        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: function() { return ''; }
        });
        
        // response'u boş olarak ayarla
        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get: function() { return ''; }
        });
        
        // Hata olaylarını tetikle
        setTimeout(() => {
            // error event
            if (typeof xhr.onerror === 'function') {
                xhr.onerror();
            }
            
            // readystatechange event
            if (typeof xhr.onreadystatechange === 'function') {
                xhr.onreadystatechange();
            }
            
            // loadend event
            if (typeof xhr.onloadend === 'function') {
                xhr.onloadend();
            }
            
            // Event listeners
            xhr.dispatchEvent(new Event('error'));
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        
        // İşlem tamamlandı, orijinal send işlemini durdur
        return;
    }
    
    // Profil ikonu dosyasını engelle
    if (this._isProfileIcon === true) {
        console.log('XMLHttpRequest: Profil ikonu dosyası engellendi:', this._requestUrl);
        
        // XMLHttpRequest'i iptal et
        this.abort();
        
        // 404 Not Found yanıtı oluştur
        const xhr = this;
        
        // readyState = 4 (DONE) olarak ayarla
        Object.defineProperty(xhr, 'readyState', {
            configurable: true,
            get: function() { return 4; }
        });
        
        // status = 404 (Not Found) olarak ayarla
        Object.defineProperty(xhr, 'status', {
            configurable: true,
            get: function() { return 404; }
        });
        
        // statusText = Not Found olarak ayarla
        Object.defineProperty(xhr, 'statusText', {
            configurable: true,
            get: function() { return 'Not Found'; }
        });
        
        // responseText'i boş olarak ayarla
        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: function() { return ''; }
        });
        
        // response'u boş olarak ayarla
        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get: function() { return ''; }
        });
        
        // Hata olaylarını tetikle
        setTimeout(() => {
            // error event
            if (typeof xhr.onerror === 'function') {
                xhr.onerror();
            }
            
            // readystatechange event
            if (typeof xhr.onreadystatechange === 'function') {
                xhr.onreadystatechange();
            }
            
            // loadend event
            if (typeof xhr.onloadend === 'function') {
                xhr.onloadend();
            }
            
            // Event listeners
            xhr.dispatchEvent(new Event('error'));
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        
        // İşlem tamamlandı, orijinal send işlemini durdur
        return;
    }
    
    // Handle Yemeksepeti cart/calculate request manipulation
    if ((isYemekSepetiCalculateEndpoint(this._requestUrl) || isYemekSepetiVouchersEndpoint(this._requestUrl)) && this._requestMethod === 'POST') {
        try {
            console.log('🌐 XMLHttpRequest: YS headers ekleniyor:', {
                url: this._requestUrl,
                method: this._requestMethod,
                bodyLength: body ? (typeof body === 'string' ? body.length : JSON.stringify(body).length) : 0
            });
            
            // Add YS headers with R-Sig
            const requestBody = typeof body === 'string' ? body : '';
            const ysHeaders = generateYSHeaders(this._requestUrl, this._requestMethod, requestBody);
            
            console.log('📋 XMLHttpRequest: Eklenecek Header\'lar:', {
                headerCount: Object.keys(ysHeaders).length,
                hasRSig: !!ysHeaders['R-Sig'],
                hasRts: !!ysHeaders['Rts'],
                hasRuid: !!ysHeaders['Ruid'],
                hasEks: !!ysHeaders['Eks']
            });
            
            for (const [key, value] of Object.entries(ysHeaders)) {
                this.setRequestHeader(key, value);
            }
            console.log('✅ XMLHttpRequest: YS headers (R-Sig dahil) başarıyla eklendi');
        } catch (error) {
            console.error('❌ XMLHttpRequest: YS headers eklenirken hata:', error);
        }
    }
    
    if (this._requestMethod === 'POST' &&
        this._requestUrl?.includes('/purchase/online/credit-card') && // URL null/undefined olabilir
        window.migrosKupon && window.migrosKupon.appliedCouponData) { // Kupon uygulanmışsa

        try {
            const requestBody = JSON.parse(body);

            // Uygulanmış kuponun ID'sini al (en güncel olanı kullan)
            const discountId = window.migrosKupon.validDiscountId || window.migrosKupon.originalCouponId;

            if (!discountId) {
                console.error('XHR - Kupon ID bulunamadı! İstek manipüle edilemiyor.');
                return originalXHRSend.call(this, body);
            }

            console.log('XHR - Ödeme isteğine eklenecek kupon ID:', discountId);
            console.log('XHR - Uygulanan kupon değeri:', window.migrosKupon.appliedCouponData.discountValue);


             // İsteğe kupon bilgilerini ekle
             // Not: Backend'in beklediği alan adları değişmiş olabilir.
             //      'balanceType', 'balanceValue', 'discount' yaygın isimler.
             //      Gerekiyorsa tarayıcı network loglarından kontrol edilmeli.
            requestBody.balanceType = 'COUPON'; // veya 'DISCOUNT' olabilir
            requestBody.balanceValue = String(discountId); // Genellikle string beklenir
            requestBody.discount = window.migrosKupon.appliedCouponData.discountValue; // İndirim miktarı (kuruş cinsinden)

            const modifiedBody = JSON.stringify(requestBody);
            console.log('XHR isteği manipüle edildi:', modifiedBody);

            return originalXHRSend.call(this, modifiedBody);
        } catch (error) {
            console.error('XHR isteği manipüle edilirken hata:', error);
        }
    }
    
    // Analytics ve tracking isteklerini engelle
    if (this._isAnalyticsBlocked === true) {
        console.log('🚫 XMLHttpRequest: Analytics/tracking isteği engellendi:', this._requestUrl);
        
        // XMLHttpRequest'i iptal et
        this.abort();
        
        // Network error olarak işaretle
        const xhr = this;
        
        Object.defineProperty(xhr, 'readyState', {
            configurable: true,
            get: function() { return 4; }
        });
        
        Object.defineProperty(xhr, 'status', {
            configurable: true,
            get: function() { return 0; }
        });
        
        Object.defineProperty(xhr, 'statusText', {
            configurable: true,
            get: function() { return ''; }
        });
        
        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: function() { return ''; }
        });
        
        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get: function() { return null; }
        });
        
        // Error event'leri tetikle
        setTimeout(() => {
            if (typeof xhr.onerror === 'function') {
                xhr.onerror();
            }
            if (typeof xhr.onreadystatechange === 'function') {
                xhr.onreadystatechange();
            }
            if (typeof xhr.onloadend === 'function') {
                xhr.onloadend();
            }
            xhr.dispatchEvent(new Event('error'));
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('loadend'));
        }, 0);
        
        return;
    }
    
    // Screen-views endpoint'ini yakala ve engelle
    if (isScreenViewsEndpoint(this._requestUrl)) {
        console.log('Screen-views isteği yakalandı ve engellendi:', this._requestUrl);
        
        // XMLHttpRequest'i iptal et
        this.abort();
        
        // Sahte başarılı yanıt oluştur
        const xhr = this;
        
        // readyState = 4 (DONE) olarak ayarla
        Object.defineProperty(xhr, 'readyState', {
            configurable: true,
            get: function() { return 4; }
        });
        
        // status = 200 (OK) olarak ayarla
        Object.defineProperty(xhr, 'status', {
            configurable: true,
            get: function() { return 200; }
        });
        
        // statusText = OK olarak ayarla
        Object.defineProperty(xhr, 'statusText', {
            configurable: true,
            get: function() { return 'OK'; }
        });
        
        // responseText'i boş olarak ayarla
        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: function() { return '{}'; }
        });
        
        // response'u boş olarak ayarla
        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get: function() { return '{}'; }
        });
        
        // Yanıt hazır olduğunda readystatechange olayını tetikle
        setTimeout(() => {
            // readystatechange event
            if (typeof xhr.onreadystatechange === 'function') {
                xhr.onreadystatechange();
            }
            
            // load event
            if (typeof xhr.onload === 'function') {
                xhr.onload();
            }
            
            // loadend event
            if (typeof xhr.onloadend === 'function') {
                xhr.onloadend();
            }
            
            // Event listeners
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('load'));
            xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        
        // İşlem tamamlandı, orijinal send işlemini durdur
        return;
    }
    
    // Perseus Analytics endpoint'ini yakala ve engelle
    if (isPerseusAnalyticsEndpoint(this._requestUrl)) {
        console.log('Perseus Analytics isteği yakalandı ve engellendi:', this._requestUrl);
        
        // XMLHttpRequest'i iptal et
        this.abort();
        
        // Sahte başarılı yanıt oluştur
        const xhr = this;
        
        // readyState = 4 (DONE) olarak ayarla
        Object.defineProperty(xhr, 'readyState', {
            configurable: true,
            get: function() { return 4; }
        });
        
        // status = 200 (OK) olarak ayarla
        Object.defineProperty(xhr, 'status', {
            configurable: true,
            get: function() { return 200; }
        });
        
        // statusText = OK olarak ayarla
        Object.defineProperty(xhr, 'statusText', {
            configurable: true,
            get: function() { return 'OK'; }
        });
        
        // responseText'i boş olarak ayarla
        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: function() { return '{}'; }
        });
        
        // response'u boş olarak ayarla
        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get: function() { return '{}'; }
        });
        
        // Yanıt hazır olduğunda readystatechange olayını tetikle
        setTimeout(() => {
            // readystatechange event
            if (typeof xhr.onreadystatechange === 'function') {
                xhr.onreadystatechange();
            }
            
            // load event
            if (typeof xhr.onload === 'function') {
                xhr.onload();
            }
            
            // loadend event
            if (typeof xhr.onloadend === 'function') {
                xhr.onloadend();
            }
            
            // Event listeners
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('load'));
            xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        
        // İşlem tamamlandı, orijinal send işlemini durdur
        return;
    }
    
    // Token endpoint'ini yakala ve sahte yanıt döndür
    if (isTokenEndpoint(this._requestUrl)) {
        console.log('Token isteği yakalandı ve engellendi:', this._requestUrl);
        
        // XMLHttpRequest'i iptal et
        this.abort();
        
        // UUID v4 token oluştur
        const token = generateUUIDv4();
        console.log('Sahte token oluşturuldu:', token);
        
        // Sahte yanıt oluştur
        const responseData = JSON.stringify({
            token: token
        });
        
        // readyState'i ayarla ve yanıtı hazırla
        const xhr = this;
        
        // readyState = 4 (DONE) olarak ayarla
        Object.defineProperty(xhr, 'readyState', {
            configurable: true,
            get: function() { return 4; }
        });
        
        // status = 200 (OK) olarak ayarla
        Object.defineProperty(xhr, 'status', {
            configurable: true,
            get: function() { return 200; }
        });
        
        // statusText = OK olarak ayarla
        Object.defineProperty(xhr, 'statusText', {
            configurable: true,
            get: function() { return 'OK'; }
        });
        
        // responseText'i ayarla
        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: function() { return responseData; }
        });
        
        // response'u ayarla
        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get: function() { return responseData; }
        });
        
        // Yanıt hazır olduğunda readystatechange olayını tetikle
        setTimeout(() => {
            // readystatechange event
            if (typeof xhr.onreadystatechange === 'function') {
                xhr.onreadystatechange();
            }
            
            // load event
            if (typeof xhr.onload === 'function') {
                xhr.onload();
            }
            
            // loadend event
            if (typeof xhr.onloadend === 'function') {
                xhr.onloadend();
            }
            
            // Event listeners
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('loadend'));
            xhr.dispatchEvent(new Event('load'));
        }, 50);
        
        // İşlem tamamlandı, orijinal send işlemini durdur
        return;
    }
    
    // Logout endpoint'ini yakala ve sahte yanıt döndür
    if (this._requestMethod === 'POST' && isLogoutEndpoint(this._requestUrl)) {
        console.log('Logout isteği yakalandı ve engellendi:', this._requestUrl);
        
        // XMLHttpRequest'i iptal et
        this.abort();
        
        // Tüm headerları tanımla
        const headers = {
            'date': 'Fri, 16 May 2025 12:16:05 GMT',
            'vary': 'Accept-Encoding',
            'x-bff-app-version': '30365eb',
            'x-bff-app-name': 'Migros-User-Bff-App',
            'set-cookie': [
                'CLIENT_SESSION_ID=; Path=/; Expires=Fri, 16 May 2025 00:00:00 GMT; Max-Age=1800; Secure; HttpOnly',
                'remember-me=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'remember-me=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'GTM_UID=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'app_uid=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'hmail=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'shmail=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'hphone=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'hmphone=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'l90c=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'seg=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'ch_pr=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'per=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'lftc=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'cm_id=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
                'shphone=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure'
            ],
            'expires': 'Thu, 01 Jan 1970 00:00:00 GMT',
            'x-content-type-options': 'nosniff',
            'x-xss-protection': '0',
            'strict-transport-security': 'max-age=15552000; includeSubDomains',
            'x-frame-options': 'SAMEORIGIN',
            'content-security-policy': "default-src * 'unsafe-inline' 'unsafe-eval'; script-src * 'unsafe-inline' 'unsafe-eval'; connect-src * 'unsafe-inline'; img-src * data: blob: 'unsafe-inline'; frame-src *; style-src * 'unsafe-inline';",
            'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
            'pragma': 'no-cache',
            'cf-cache-status': 'DYNAMIC',
            'server': 'cloudflare',
        };
        
        // readyState'i ayarla ve yanıtı hazırla
        const xhr = this;
        
        // readyState = 4 (DONE) olarak ayarla
        Object.defineProperty(xhr, 'readyState', {
            configurable: true,
            get: function() { return 4; }
        });
        
        // status = 204 (No Content) olarak ayarla
        Object.defineProperty(xhr, 'status', {
            configurable: true,
            get: function() { return 500; }
        });
        
        // statusText = No Content olarak ayarla
        Object.defineProperty(xhr, 'statusText', {
            configurable: true,
            get: function() { return 'Internal Server Error'; }
        });
        
        // responseText'i boş olarak ayarla
        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: function() { return ''; }
        });
        
        // response'u boş olarak ayarla
        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get: function() { return ''; }
        });
        
        // Header metodlarını override et
        xhr.getAllResponseHeaders = function() {
            let headerStr = '';
            Object.entries(headers).forEach(([key, value]) => {
                if (Array.isArray(value)) {
                    // Set-cookie gibi çoklu headerlar için
                    value.forEach(val => {
                        headerStr += `${key}: ${val}\r\n`;
                    });
                } else {
                    headerStr += `${key}: ${value}\r\n`;
                }
            });
            return headerStr;
        };
        
        xhr.getResponseHeader = function(name) {
            name = name.toLowerCase();
            if (headers[name]) {
                return Array.isArray(headers[name]) ? headers[name][0] : headers[name];
            }
            return null;
        };
        
        // Cookie'leri gerçekten ayarla
        if (headers['set-cookie'] && Array.isArray(headers['set-cookie'])) {
            headers['set-cookie'].forEach(cookieStr => {
                document.cookie = cookieStr.split(';')[0]; // Cookie'nin Ana kısmını al
            });
        }
        
        // Yanıt hazır olduğunda readystatechange olayını tetikle
        setTimeout(() => {
            // readystatechange event
            if (typeof xhr.onreadystatechange === 'function') {
                xhr.onreadystatechange();
            }
            
            // load event
            if (typeof xhr.onload === 'function') {
                xhr.onload();
            }
            
            // loadend event
            if (typeof xhr.onloadend === 'function') {
                xhr.onloadend();
            }
            
            // Event listeners
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('loadend'));
            xhr.dispatchEvent(new Event('load'));
        }, 50);
        
        // İşlem tamamlandı, orijinal send işlemini durdur
        return;
    }
    
    // Sepet ekranındaki checkout screens isteğini manipüle et - genişletilmiş
    // DEVRE DIŞI - Artık isMgProxyEndpoint kullanılıyor
    if (false && this._requestMethod === 'POST' && isCheckoutScreensEndpoint(this._requestUrl)) {
        
        try {
            console.log('Sepet ekranı checkout isteği yakalandı:', this._requestUrl);
            
            // Background script üzerinden istek yapılacak
            const originalXhr = this;
            const originalUrl = this._requestUrl;
            
            // XMLHttpRequest'i iptal et, kendi kontrol edeceğiz
            this.abort();
            
            // URL dönüşümü - servis yolunu koru
            let newUrl = originalUrl;
            
            // URL düzeltme - eğer HTTP protokolü yoksa ekle
            if (!newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
              newUrl = 'https://' + newUrl;
            }
            
            // URL'yi rest.migros.com.tr'ye dönüştür
            newUrl = newUrl.replace('www.migros.com.tr', 'rest.migros.com.tr');
            
            // URL'de /rest yoksa ve servis yolu (/hemen, /yemek) varsa düzeltme yap
            try {
              const parsedUrl = new URL(newUrl);
              if (!parsedUrl.pathname.startsWith('/rest')) {
                // Hangi servis olduğunu tespit et
                let servicePath = '';
                if (parsedUrl.pathname.includes('/hemen/')) {
                  servicePath = '/hemen';
                } else if (parsedUrl.pathname.includes('/yemek/')) {
                  servicePath = '/yemek';
                }
                
                // Path'i düzelt: /rest/{servis}/... formatına getir
                parsedUrl.pathname = `/rest${servicePath}${parsedUrl.pathname.replace(/^\/*(hemen|yemek)?\/*/, '/')}`;
                newUrl = parsedUrl.toString();
              }
            } catch (e) {
              console.warn('URL düzenleme hatası:', e);
            }
            
            console.log('Düzeltilmiş URL:', newUrl);
            
            // Mobil app headerları - tüm browser headerları kaldırmak için genişletildi
            const mobileHeaders = {
                'Host': 'rest.migros.com.tr',
                'X-Device-Platform': 'ANDROID',
                'X-Device-Platform-Version': '10',
                'X-Device-Type': 'MOBILE',
                'X-Device-App-Version': '12.0.0',
                'X-Device-Identifier': generateDeviceIdentifier(),
                'X-Device-Model': 'SAMSUNG',
                'X-Device-App-Screen': 'CART',
                'Accept-Language': 'tr-TR',
                'X-Ab-Tests': 'showNewServiceSelectionScreen%3Dtrue%2CopenNewCompanyDesign%3Dtrue%2CcategorySlider%3Dtrue%2CshowLiveChatInApp%3Dtrue%2CblacklistedMessagesForDatadog%3D%5B%22java.lang.NullPointerException%3A+The+mapper+function+returned+a+null+value.%22%2C%22Service+Selection+opened.%22%2C%22ServiceException%28message%3Dnull%2C+errorCode%3Dnull%29%22%5D%2CshowFoodFavouriteProductTooltip%3Dtrue%2CchangeKitchensAndQuickFilters%3Dfalse%2CdatadogRUMRate%3D1%2CshowRecommendationsAtHomePage%3Dtrue%2CdrinkRecommendationMigrosIcon%3Dtrue%2CshowNewPaymentView%3Dtrue%2CopenBasketOffersDirectlyForHemen%3Dtrue%2CshowAddressSkipButton%3Dfalse%2CdatadogInfoLoggingEnabled%3Dfalse%2ChemenBasketRecommendedProductsButton%3Dtrue%2CshowNewProductDetail%3Dtrue%2CshowNewSupportViews%3Dfalse%2CinstantCartNewIcon%3Dfalse%2CshowSFChatbot%3Dtrue%2CdatadogLoggingEnabled%3Dtrue%2CshowTripleGridiOS%3Dtrue%2CappSelectionSearchTopPosition%3Dfalse%2CopenBasketOffersDirectlyInCart%3Dfalse%2CshowNewServiceSelectionScreenTest%3Dtrue%2CshowFreeboxForFood%3Dtrue%2CshowTripleGrid%3Dtrue%2ChemenBasketRecommendationUIchange%3Dfalse%2CshowHemenCategoriesWithFourColumn%3Dtrue',
                'Content-Type': 'application/json; charset=UTF-8',
                'User-Agent': 'okhttp/4.12.0',
            };

            // Background script'e istek gönder
            console.log('Background script üzerinden istek gönderiliyor...');
            
            // window.postMessage kullanarak content script'e ileti gönder
            const requestId = Date.now() + Math.random().toString().substring(2, 8);
            
            // XHR sonuçları için global bir callback haritası oluştur
            window.migrosKupon.xhrCallbacks = window.migrosKupon.xhrCallbacks || {};
            
            // Bu istek için callback'i kaydet
            window.migrosKupon.xhrCallbacks[requestId] = (response) => {
                if (response && response.success) {
                    console.log('Proxy yanıtı alındı:', response.status);
                    
                    // XMLHttpRequest'in tüm özellik ve olaylarını taklit et
                    // NOT: Doğrudan özellik ataması yapmak yerine, mockResponse oluştur
                    const mockResponse = {
                        status: response.status,
                        statusText: response.statusText || '',
                        response: response.data,
                        responseText: response.data,
                        headers: response.headers || {},
                        getAllResponseHeaders: function() {
                            // Null check - boş veya undefined headers için güvenli değer döndür
                            if (!this.headers || typeof this.headers !== 'object') {
                                console.warn('Headers objesi bulunamadı veya geçersiz');
                                return '';
                            }
                            
                            try {
                                return Object.entries(this.headers)
                                    .map(([key, value]) => `${key}: ${value}`)
                                    .join('\r\n');
                            } catch (error) {
                                console.warn('Headers formatlanırken hata:', error);
                                return '';
                            }
                        },
                        getResponseHeader: function(name) {
                            // Null check - boş veya undefined headers için güvenli değer döndür
                            if (!this.headers || typeof this.headers !== 'object') {
                                return null;
                            }
                            
                            try {
                                return this.headers[name.toLowerCase()] || null;
                            } catch (error) {
                                console.warn(`'${name}' header'ı alınırken hata:`, error);
                                return null;
                            }
                        }
                    };
                    
                    // originalXhr'ye doğrudan statik değerler atamak yerine
                    // onun yapısını dinamik metodlarla kullanıyoruz
                    
                    // readyState değişimini ve uygun olayları tetikle
                    Object.defineProperty(originalXhr, 'readyState', { 
                        configurable: true,
                        get: function() { return 4; } // DONE
                    });
                    
                    // Yanıt değerlerini set et - defineProperty ile
                    // Sadece get olarak tanımlanmış özellikleri doğrudan değiştirmek yerine
                    // Tüm özellikleri try/catch içinde güvenli bir şekilde ayarla
                    try {
                        // status
                        try {
                            const statusDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'status');
                            if (statusDesc && !statusDesc.writable) {
                                Object.defineProperty(originalXhr, 'status', { 
                                    configurable: true,
                                    get: function() { return mockResponse.status; } 
                                });
                            } else {
                                originalXhr.status = mockResponse.status;
                            }
                        } catch (e) {
                            console.warn('Status özelliği ayarlanamadı:', e);
                            // Fallback
                            try {
                                Object.defineProperty(originalXhr, 'status', { 
                                    configurable: true,
                                    get: function() { return mockResponse.status; } 
                                });
                            } catch (e2) {
                                console.warn('Status için fallback da başarısız:', e2);
                            }
                        }
                        
                        // statusText
                        try {
                            const statusTextDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'statusText');
                            if (statusTextDesc && !statusTextDesc.writable) {
                                Object.defineProperty(originalXhr, 'statusText', { 
                                    configurable: true,
                                    get: function() { return mockResponse.statusText; } 
                                });
                            } else {
                                originalXhr.statusText = mockResponse.statusText;
                            }
                        } catch (e) {
                            console.warn('StatusText özelliği ayarlanamadı:', e);
                            try {
                                Object.defineProperty(originalXhr, 'statusText', { 
                                    configurable: true,
                                    get: function() { return mockResponse.statusText; } 
                                });
                            } catch (e2) {}
                        }
                        
                        // response
                        try {
                            const responseDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'response');
                            if (responseDesc && !responseDesc.writable) {
                                Object.defineProperty(originalXhr, 'response', { 
                                    configurable: true,
                                    get: function() { return mockResponse.response; } 
                                });
                            } else {
                                originalXhr.response = mockResponse.response;
                            }
                        } catch (e) {
                            console.warn('Response özelliği ayarlanamadı:', e);
                            try {
                                Object.defineProperty(originalXhr, 'response', { 
                                    configurable: true,
                                    get: function() { return mockResponse.response; } 
                                });
                            } catch (e2) {}
                        }
                        
                        // responseText
                        try {
                            const responseTextDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'responseText');
                            if (responseTextDesc && !responseTextDesc.writable) {
                                Object.defineProperty(originalXhr, 'responseText', { 
                                    configurable: true,
                                    get: function() { return mockResponse.responseText; } 
                                });
                            } else {
                                originalXhr.responseText = mockResponse.responseText;
                            }
                        } catch (e) {
                            console.warn('ResponseText özelliği ayarlanamadı:', e);
                            try {
                                Object.defineProperty(originalXhr, 'responseText', { 
                                    configurable: true,
                                    get: function() { return mockResponse.responseText; } 
                                });
                            } catch (e2) {}
                        }
                    
                    } catch (mainError) {
                        console.warn('Özellik ayarlama hatası:', mainError);
                        // Hiçbir şekilde özellik ataması yapılamazsa alternatif yaklaşım kullan
                        // Bu durumda olay tetiklemeye geç - çoğu zaman bu da yeterli olur
                    }
                    
                    // responseHeaders için metodları override et
                    try {
                        originalXhr.getAllResponseHeaders = mockResponse.getAllResponseHeaders;
                        originalXhr.getResponseHeader = mockResponse.getResponseHeader;
                    } catch (e) {
                        console.warn('Header metodları override edilemedi:', e);
                    }
                    
                    // Olayları tetikle - önce readystatechange
                    if (typeof originalXhr.onreadystatechange === 'function') {
                        originalXhr.onreadystatechange();
                    }
                    
                    // Başarılı yanıt ise load olayını tetikle
                    if (response.status >= 200 && response.status < 300) {
                        if (typeof originalXhr.onload === 'function') {
                            originalXhr.onload();
                        }
                        
                        // loadend olayını tetikle
                        if (typeof originalXhr.onloadend === 'function') {
                            originalXhr.onloadend();
                        }
                        
                        // Tüm dinleyicileri tetikle
                        const loadEvent = new Event('load');
                        originalXhr.dispatchEvent(loadEvent);
                        
                        const loadendEvent = new Event('loadend');
                        originalXhr.dispatchEvent(loadendEvent);
                    } else {
                        // Hata durumunda error olayını tetikle
                        if (typeof originalXhr.onerror === 'function') {
                            originalXhr.onerror();
                        }
                        
                        // Tüm dinleyicileri tetikle
                        const errorEvent = new Event('error');
                        originalXhr.dispatchEvent(errorEvent);
                        
                        const loadendEvent = new Event('loadend');
                        originalXhr.dispatchEvent(loadendEvent);
                    }
                } else {
                    console.error('Proxy hatası:', response ? response.error : 'Bilinmeyen hata');
                    
                    // Hata olaylarını tetikle
                    originalXhr.status = 0;
                    originalXhr.statusText = 'Error';
                    originalXhr.readyState = 4;
                    
                    if (typeof originalXhr.onerror === 'function') {
                        originalXhr.onerror();
                    }
                    
                    if (typeof originalXhr.onloadend === 'function') {
                        originalXhr.onloadend();
                    }
                    
                    const errorEvent = new Event('error');
                    originalXhr.dispatchEvent(errorEvent);
                    
                    const loadendEvent = new Event('loadend');
                    originalXhr.dispatchEvent(loadendEvent);
                }
                
                // Callback'i temizle
                delete window.migrosKupon.xhrCallbacks[requestId];
            };
            
            // window.postMessage ile istek gönder
            window.postMessage({
                source: 'MIGROS_KUPON_EXTENSION',
                action: 'proxyRequest',
                requestId: requestId,
                url: newUrl,
                method: 'POST',
                headers: mobileHeaders,
                body: body
            }, '*');
            
            // Bu XMLHttpRequest'in artık bizim kontrolümüzde olduğunu belirt
            // Asıl send() çağrılmamalı
            return;
        } catch (error) {
            console.error('Sepet isteği manipüle edilirken hata:', error);
            // Hata durumunda orijinal isteği gönder
            return originalXHRSend.call(this, body);
        }
    }

    return originalXHRSend.call(this, body);
};

// Fetch API'sini manipüle et (orijinal kod korunuyor)
const originalFetch = window.fetch;
window.fetch = async function(resource, init) {
    const urlString = resource instanceof Request ? resource.url : String(resource);
    
    // MIGROS PROXY (FETCH)
    if (isMgProxyEndpoint(urlString)) {
        console.log('Fetch: Intercepting MG request and proxying through background.js', urlString);
        
        try {
            const proxyResponse = await sendProxyRequest({
                action: 'mgProxyRequest',
                url: urlString,
                method: init?.method || 'POST',
                headers: init?.headers || {},
                body: init?.body || null
            });
            
            // Yanıttan yeni bir Response nesnesi oluştur
            return new Response(proxyResponse.data, {
                status: proxyResponse.status,
                statusText: proxyResponse.statusText,
                headers: proxyResponse.headers
            });
        } catch (error) {
            console.error('Fetch proxy error for MG endpoint:', error);
            // Hata durumunda boş veya hatalı bir yanıt döndür
            return new Response(null, { status: 503, statusText: 'Proxy Service Unavailable' });
        }
    }
    
    // YEMEKSEPETİ PROXY (FETCH)
    if (isYsProxyEndpoint(urlString)) {
        console.log('Fetch: Intercepting YS Fetch request and proxying through background.js', urlString);
        try {
            // Eğer cart/checkout endpoint'i ise body'i manipüle et
            let finalBody = init?.body || null;
            if (urlString.includes('cart/checkout') && init?.body) {
                try {
                    let requestBody;
                    if (typeof init.body === 'string') {
                        requestBody = JSON.parse(init.body);
                    } else {
                        requestBody = JSON.parse(String(init.body));
                    }
                    
                    // Manipulate the platform and source fields
                    if (requestBody.platform && requestBody.platform === 'b2c') {
                        requestBody.platform = 'Android-app-25.50.5(255050434)';
                    }
                    
                    if (requestBody.source) {
                        requestBody.source = 'android';
                    } else {
                        requestBody.source = 'android';
                    }
                    
                    finalBody = JSON.stringify(requestBody);
                } catch (error) {
                    console.error('YS Proxy (Fetch): Error manipulating request body:', error);
                    finalBody = init?.body || null; // Fallback to original body
                }
            }
            
            const proxyResponse = await sendProxyRequest({
                action: 'ysProxyRequest',
                url: urlString,
                method: init?.method || 'GET',
                headers: init?.headers || {},
                body: finalBody
            });
            
            // Yanıttan yeni bir Response nesnesi oluştur
            return new Response(proxyResponse.data, {
                status: proxyResponse.status,
                statusText: proxyResponse.statusText,
                headers: proxyResponse.headers
            });
        } catch (error) {
            console.error('Fetch proxy error for YS endpoint:', error);
            // Hata durumunda boş veya hatalı bir yanıt döndür
            return new Response(null, { status: 503, statusText: 'Proxy Service Unavailable' });
        }
    }

    // TRENDYOL PROXY (FETCH)
    if (isTyProxyEndpoint(urlString)) {
        console.log('Fetch: Intercepting TY Fetch request and proxying through background.js', urlString);
        try {
            // Cart items için özel action
            const action = urlString.includes('/carts/items') ? 'tyCartItemsRequest' : 'tyProxyRequest';
            
            const proxyResponse = await sendProxyRequest({
                action: action,
                url: urlString,
                method: init?.method || 'POST',
                headers: init?.headers || {},
                body: init?.body || null
            });
            
            // Yanıttan yeni bir Response nesnesi oluştur
            return new Response(proxyResponse.data, {
                status: proxyResponse.status,
                statusText: proxyResponse.statusText,
                headers: proxyResponse.headers
            });
        } catch (error) {
            console.error('Fetch proxy error for TY endpoint:', error);
            // Hata durumunda boş veya hatalı bir yanıt döndür
            return new Response(null, { status: 503, statusText: 'Proxy Service Unavailable' });
        }
    }
    
    // Analytics ve tracking isteklerini engelle
    if (isAnalyticsOrTrackingEndpoint(urlString)) {
        console.log('🚫 Fetch: Analytics/tracking isteği engellendi:', urlString);
        
        // Network error olarak reject et
        return Promise.reject(new TypeError('Failed to fetch'));
    }
    
    // Service Worker dosyasını engelle
    if (isServiceWorkerFile(urlString)) {
        console.log('Fetch: Service Worker dosyası yakalandı ve engellendi:', urlString);
        
        // 404 Not Found yanıtı döndür
        return new Response('', {
            status: 404,
            statusText: 'Not Found',
            headers: {
                'Content-Type': 'text/plain'
            }
        });
    }
    
    // PWA manifest dosyalarını engelle
    if (isPWAManifestFile(urlString)) {
        console.log('Fetch: PWA manifest dosyası yakalandı ve engellendi:', urlString);
        
        // 404 Not Found yanıtı döndür
        return new Response('', {
            status: 404,
            statusText: 'Not Found',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
    
    // Profil ikonu dosyasını engelle
    if (isProfileIconFile(urlString)) {
        console.log('Fetch: Profil ikonu dosyası yakalandı ve engellendi:', urlString);
        
        // 404 Not Found yanıtı döndür
        return new Response('', {
            status: 404,
            statusText: 'Not Found',
            headers: {
                'Content-Type': 'image/webp'
            }
        });
    }
    
    // Intercept custom-texts API and return custom response (both GET and POST)
    if (isCustomTextsEndpoint(urlString)) {
        console.log('Fetch: Intercepting custom-texts API to provide custom response:', urlString);
        
        // Create the custom response using the same format as XHR
        const customResponse = generateCustomTextsResponse();
        
        // Return a fake Response object with our custom data
        return new Response(
            JSON.stringify(customResponse),
            { 
                status: 200, 
                statusText: 'OK',
                headers: {
                    'Content-Type': 'application/json',
                    'Cache-Control': 'no-cache'
                }
            }
        );
    }
    
    // Handle Yemeksepeti cart/calculate and vouchers request manipulation
    if (init && init.method === 'POST' && (isYemekSepetiCalculateEndpoint(urlString) || isYemekSepetiVouchersEndpoint(urlString))) {
        try {
            console.log('🌐 Fetch: YS headers ekleniyor:', {
                url: urlString,
                method: init.method,
                bodyLength: init.body ? (typeof init.body === 'string' ? init.body.length : JSON.stringify(init.body).length) : 0
            });
            
            // Add YS headers with R-Sig
            const requestBody = typeof init.body === 'string' ? init.body : (init.body ? JSON.stringify(init.body) : '');
            const ysHeaders = generateYSHeaders(urlString, init.method, requestBody);
            
            console.log('📋 Fetch: Eklenecek Header\'lar:', {
                headerCount: Object.keys(ysHeaders).length,
                hasRSig: !!ysHeaders['R-Sig'],
                hasRts: !!ysHeaders['Rts'],
                hasRuid: !!ysHeaders['Ruid'],
                hasEks: !!ysHeaders['Eks']
            });
            
            const modifiedInit = {
                ...init,
                headers: {
                    ...init.headers,
                    ...ysHeaders
                }
            };
            console.log('✅ Fetch: YS headers (R-Sig dahil) başarıyla eklendi');
            
            // Send the modified request
            return originalFetch.call(this, resource, modifiedInit);
        } catch (error) {
            console.error('❌ Fetch: YS headers eklenirken hata:', error);
            // Fall back to original request on error
        }
    }

    // Screen-views endpoint'ini yakala ve engelle
    if (isScreenViewsEndpoint(urlString)) {
        console.log('Fetch: Screen-views isteği yakalandı ve engellendi:', urlString);
        
        // Sahte başarılı yanıt döndür
        return new Response('{}', {
            status: 200,
            statusText: 'OK',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
    
    // Perseus Analytics endpoint'ini yakala ve engelle
    if (isPerseusAnalyticsEndpoint(urlString)) {
        console.log('Fetch: Perseus Analytics isteği yakalandı ve engellendi:', urlString);
        
        // Sahte başarılı yanıt döndür
        return new Response('{}', {
            status: 200,
            statusText: 'OK',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
    
    // Token endpoint'ini yakala ve sahte yanıt döndür
    if (isTokenEndpoint(urlString)) {
        console.log('Fetch: Token isteği yakalandı ve engellendi:', urlString);
        
        // UUID v4 token oluştur
        const token = generateUUIDv4();
        console.log('Fetch: Sahte token oluşturuldu:', token);
        
        // Sahte yanıt oluştur
        const responseData = JSON.stringify({
            token: token
        });
        
        // Response nesnesini oluştur ve döndür
        return new Response(responseData, {
            status: 200,
            statusText: 'OK',
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
    
    // Logout endpoint'ini yakala ve sahte yanıt döndür
    if (init && init.method === 'POST' && isLogoutEndpoint(urlString)) {
        console.log('Fetch: Logout isteği yakalandı ve engellendi:', urlString);
        
        // Tüm headerları tanımla
        const headers = new Headers({
            'vary': 'Accept-Encoding',
            'x-bff-app-name': 'Migros-User-Bff-App',
            'expires': 'Thu, 01 Jan 1970 00:00:00 GMT',
            'x-content-type-options': 'nosniff',
            'x-xss-protection': '0',
            'strict-transport-security': 'max-age=15552000; includeSubDomains',
            'x-frame-options': 'SAMEORIGIN',
            'content-security-policy': "default-src * 'unsafe-inline' 'unsafe-eval'; script-src * 'unsafe-inline' 'unsafe-eval'; connect-src * 'unsafe-inline'; img-src * data: blob: 'unsafe-inline'; frame-src *; style-src * 'unsafe-inline';",
            'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
            'pragma': 'no-cache',
            'cf-cache-status': 'DYNAMIC',
            'server': 'cloudflare',
        });
        
        // Set-cookie headerları ekle
        const cookieHeaders = [
            'remember-me=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'remember-me=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'GTM_UID=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'app_uid=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'hmail=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'shmail=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'hphone=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'hmphone=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'l90c=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'seg=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'ch_pr=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'per=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'lftc=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'cm_id=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure',
            'shphone=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0; Secure'
        ];
        
        cookieHeaders.forEach(cookie => {
            headers.append('set-cookie', cookie);
            // Cookie'yi gerçekten ayarla
            document.cookie = cookie.split(';')[0]; // Cookie'nin Ana kısmını al
        });
        
        // Response nesnesini oluştur ve döndür (boş içerik, 204 status)
        return new Response('', {
            status: 500,
            statusText: 'Internal Server Error',
            headers: headers
        });
    }

    if (init && init.method === 'POST' &&
        urlString.includes('/purchase/online/credit-card') &&
        window.migrosKupon && window.migrosKupon.appliedCouponData) { // Kupon uygulanmışsa

        try {
            const modifiedInit = { ...init }; // Orijinal init objesini kopyala

            if (typeof modifiedInit.body === 'string') {
                const requestBody = JSON.parse(modifiedInit.body);

                // Uygulanmış kuponun ID'sini al
                const discountId = window.migrosKupon.validDiscountId || window.migrosKupon.originalCouponId;

                if (!discountId) {
                    console.error('Fetch - Kupon ID bulunamadı! İstek manipüle edilemiyor.');
                    return originalFetch.call(this, resource, init);
                }

                console.log('Fetch - Ödeme isteğine eklenecek kupon ID:', discountId);
                console.log('Fetch - Uygulanan kupon değeri:', window.migrosKupon.appliedCouponData.discountValue);

                 // İsteğe kupon bilgilerini ekle
                requestBody.balanceType = 'COUPON';
                requestBody.balanceValue = String(discountId);
                requestBody.discount = window.migrosKupon.appliedCouponData.discountValue;

                modifiedInit.body = JSON.stringify(requestBody);
                console.log('Fetch isteği manipüle edildi:', modifiedInit.body);

                return originalFetch.call(this, resource, modifiedInit); // Manipüle edilmiş isteği gönder
            } else {
                 console.warn('Fetch - İstek gövdesi string formatında değil, manipüle edilemedi.');
            }
        } catch (error) {
            console.error('Fetch isteği manipüle edilirken hata:', error);
        }
    }
    
    // Sepet ekranı checkout screens isteğini manipüle et
    // DEVRE DIŞI - Artık isMgProxyEndpoint kullanılıyor
    if (false && init && init.method === 'POST' && isCheckoutScreensEndpoint(urlString)) {
        try {
            console.log('Fetch: Sepet ekranı checkout isteği yakalandı:', urlString);
            
            // Yeni URL oluştur
            let newUrl = urlString;
            
            // URL düzeltme - eğer HTTP protokolü yoksa ekle
            if (!newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
              newUrl = 'https://' + newUrl;
            }
            
            // URL'yi rest.migros.com.tr'ye dönüştür
            newUrl = newUrl.replace('www.migros.com.tr', 'rest.migros.com.tr');
            
            // URL'de /rest yoksa ve servis yolu (/hemen, /yemek) varsa düzeltme yap
            try {
              const parsedUrl = new URL(newUrl);
              if (!parsedUrl.pathname.startsWith('/rest')) {
                // Hangi servis olduğunu tespit et
                let servicePath = '';
                if (parsedUrl.pathname.includes('/hemen/')) {
                  servicePath = '/hemen';
                } else if (parsedUrl.pathname.includes('/yemek/')) {
                  servicePath = '/yemek';
                }
                
                // Path'i düzelt: /rest/{servis}/... formatına getir
                parsedUrl.pathname = `/rest${servicePath}${parsedUrl.pathname.replace(/^\/*(hemen|yemek)?\/*/, '/')}`;
                newUrl = parsedUrl.toString();
              }
            } catch (e) {
              console.warn('URL düzenleme hatası:', e);
            }
            
            console.log('Fetch: Düzeltilmiş URL:', newUrl);
            
            // Request body'sini al
            let requestBody;
            if (init.body) {
                // Body string, FormData, vs. olabilir, string olarak elde et
                if (typeof init.body === 'string') {
                    requestBody = init.body;
                } else if (init.body instanceof FormData) {
                    // FormData'dan string oluşturmak karmaşık, burada 
                    // bu senaryoyu atla ve normal isteği gönder
                    console.warn('FormData body desteklenmiyor, orijinal istek gönderiliyor.');
                    return originalFetch.call(this, resource, init);
                } else {
                    // Diğer body tipleri için (Blob, ArrayBuffer vb.) 
                    // orijinal isteği gönder
                    console.warn('Karmaşık body tipi, orijinal istek gönderiliyor.');
                    return originalFetch.call(this, resource, init);
                }
            } else {
                requestBody = '';
            }
            
            // Mobil app headerları - tüm browser headerları kaldırmak için genişletildi
            const mobileHeaders = {
                'Host': 'rest.migros.com.tr',
                'X-Device-Platform': 'ANDROID',
                'X-Device-Platform-Version': '10',
                'X-Device-Type': 'MOBILE',
                'X-Device-App-Version': '12.0.0',
                'X-Device-Identifier': generateDeviceIdentifier(),
                'X-Device-Model': 'SAMSUNG',
                'X-Device-App-Screen': 'CART',
                'Accept-Language': 'tr-TR',
                'X-Ab-Tests': 'showNewServiceSelectionScreen%3Dtrue%2CopenNewCompanyDesign%3Dtrue%2CcategorySlider%3Dtrue%2CshowLiveChatInApp%3Dtrue%2CblacklistedMessagesForDatadog%3D%5B%22java.lang.NullPointerException%3A+The+mapper+function+returned+a+null+value.%22%2C%22Service+Selection+opened.%22%2C%22ServiceException%28message%3Dnull%2C+errorCode%3Dnull%29%22%5D%2CshowFoodFavouriteProductTooltip%3Dtrue%2CchangeKitchensAndQuickFilters%3Dfalse%2CdatadogRUMRate%3D1%2CshowRecommendationsAtHomePage%3Dtrue%2CdrinkRecommendationMigrosIcon%3Dtrue%2CshowNewPaymentView%3Dtrue%2CopenBasketOffersDirectlyForHemen%3Dtrue%2CshowAddressSkipButton%3Dfalse%2CdatadogInfoLoggingEnabled%3Dfalse%2ChemenBasketRecommendedProductsButton%3Dtrue%2CshowNewProductDetail%3Dtrue%2CshowNewSupportViews%3Dfalse%2CinstantCartNewIcon%3Dfalse%2CshowSFChatbot%3Dtrue%2CdatadogLoggingEnabled%3Dtrue%2CshowTripleGridiOS%3Dtrue%2CappSelectionSearchTopPosition%3Dfalse%2CopenBasketOffersDirectlyInCart%3Dfalse%2CshowNewServiceSelectionScreenTest%3Dtrue%2CshowFreeboxForFood%3Dtrue%2CshowTripleGrid%3Dtrue%2ChemenBasketRecommendationUIchange%3Dfalse%2CshowHemenCategoriesWithFourColumn%3Dtrue',
                'Content-Type': 'application/json; charset=UTF-8',
                'Accept-Encoding': 'gzip, deflate, br',
                'User-Agent': 'okhttp/4.12.0',
                
                // Browser headerlarını temizleme için explicit headers
                'sec-ch-ua': null,
                'sec-ch-ua-mobile': null,
                'sec-ch-ua-platform': null,
                'Sec-Fetch-Dest': null,
                'Sec-Fetch-Mode': null,
                'Sec-Fetch-Site': null, 
                'Sec-Fetch-User': null,
                'Sec-Fetch-Storage-Access': null,
                'x-forwarded-rest': null,
                'x-device-pwa': null,
                'x-pwa': null,
                'priority': null,
                'referer': null,
                'origin': null
            };
            
            console.log('Background script üzerinden fetch isteği gönderiliyor...');
            
            // window.postMessage kullanarak content script'e ileti gönder ve
            // Promise olarak dön
            return new Promise((resolve, reject) => {
                const requestId = Date.now() + Math.random().toString().substring(2, 8);
                
                // Fetch sonuçları için global bir callback haritası oluştur
                window.migrosKupon.fetchCallbacks = window.migrosKupon.fetchCallbacks || {};
                
                // Bu istek için callback'i kaydet
                window.migrosKupon.fetchCallbacks[requestId] = (response) => {
                    if (response && response.success) {
                        console.log('Fetch proxy yanıtı alındı:', response.status);
                        
                        // Yanıtı hata ayıklama için daha ayrıntılı logla
                        if (response && response.success) {
                            console.log(`Proxy yanıtı alındı: ${response.status}`, {
                                status: response.status,
                                headersCount: response.headers ? Object.keys(response.headers).length : 0,
                                dataSize: response.data ? response.data.length : 0
                            });
                        } else {
                            console.warn('Başarısız proxy yanıtı alındı:', response ? response.error : 'Yanıt yok');
                        }
                        
                        // Boş headers'ı düzelt
                        if (response && !response.headers) {
                            response.headers = {};
                        }
                        
                        // Response nesnesini oluştur
                        const responseInit = {
                            status: response.status,
                            statusText: response.statusText || '',
                            headers: response.headers || {}
                        };
                        
                        // Response nesnesini döndür
                        resolve(new Response(
                            response.data,
                            responseInit
                        ));
                    } else {
                        console.error('Fetch proxy hatası:', response ? response.error : 'Bilinmeyen hata');
                        reject(new Error(response ? response.error : 'Proxy request failed'));
                    }
                    
                    // Callback'i temizle
                    delete window.migrosKupon.fetchCallbacks[requestId];
                };
                
                // window.postMessage ile istek gönder
                window.postMessage({
                    source: 'MIGROS_KUPON_EXTENSION',
                    action: 'proxyRequest',
                    requestId: requestId,
                    url: newUrl,
                    method: 'POST',
                    headers: mobileHeaders,
                    body: requestBody
                }, '*');
            });
        } catch (error) {
            console.error('Fetch: Sepet isteği manipüle edilirken hata:', error);
            // Hata durumunda orijinal isteği gönder
            return originalFetch.call(this, resource, init);
        }
    }

    // Diğer tüm fetch istekleri için orijinal fetch'i çağır
    return originalFetch.call(this, resource, init);
};

