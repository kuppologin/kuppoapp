// Bu dosya, kupon uygulamasının kullanıcı arayüzü için gerekli olan
// tüm CSS stillerini içerir.

'use strict';

const couponUIStyles = `
    .top-slot, .allow-new-wallet-content, fe-masterpass-link-user, .activate-wallet-wrapper, fe-card-provision-info, sm-mobile-app-popup, .popover.ng-star-inserted, #ai-wrapper, sm-money-discount-banner, .smart-life-wrapper, sm-download-hemen-app, sm-download-yemek-app, sm-download-app, sm-business-request-section, sm-download-application, .quick-filters {
    display:none !important;
    }

    /* ===== Ana Kupon Container ===== */
    #migros-coupon-container {
        position: relative;
        background: linear-gradient(135deg, #ffffff 0%, #fafbfc 100%);
        border-radius: 16px;
        border: 1px solid rgba(0, 0, 0, 0.06);
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.06), 0 1px 2px rgba(0, 0, 0, 0.04);
        margin: 16px 0;
        padding: 20px;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        color: #1a1a2e;
        overflow: hidden;
    }
    #migros-coupon-container::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, #e32828 0%, #ff6b6b 50%, #e32828 100%);
        border-radius: 16px 16px 0 0;
    }
    @media (min-width: 992px) {
        #migros-coupon-container {
            margin-left: auto;
            width: calc(100% - 3rem);
        }
    }

    /* ===== Başlık ===== */
    #migros-coupon-container .coupon-title {
        font-size: 1rem;
        font-weight: 700;
        line-height: 1.5;
        margin-bottom: 16px;
        color: #1a1a2e;
        display: flex;
        align-items: center;
        gap: 10px;
        letter-spacing: -0.01em;
    }
    #migros-coupon-container .coupon-title .coupon-title-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 36px;
        height: 36px;
        border-radius: 10px;
        background: linear-gradient(135deg, #e32828 0%, #ff4757 100%);
        color: #fff;
        flex-shrink: 0;
    }
    #migros-coupon-container .coupon-title .coupon-title-icon svg {
        width: 18px;
        height: 18px;
    }

    /* ===== Kupon Giriş Formu ===== */
    #migros-coupon-container .coupon-form {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        align-items: stretch;
    }
    #migros-coupon-container #migros-coupon-input {
        flex-grow: 1;
        padding: 0 16px;
        border: 2px solid #e8ecf1;
        border-radius: 12px;
        font-size: 0.875rem;
        height: 46px;
        box-sizing: border-box;
        line-height: 1.5;
        background: #fff;
        color: #1a1a2e;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
        font-family: inherit;
    }
    #migros-coupon-container #migros-coupon-input::placeholder {
        color: #a0aec0;
    }
    #migros-coupon-container #migros-coupon-input:focus {
        border-color: #e32828;
        outline: none;
        box-shadow: 0 0 0 3px rgba(227, 40, 40, 0.1);
    }

    /* ===== Uygula Butonu ===== */
    #migros-coupon-container .apply-coupon-button {
        background: linear-gradient(135deg, #e32828 0%, #d42020 100%);
        color: #fff;
        border: none;
        border-radius: 12px;
        padding: 0 24px;
        font-weight: 600;
        font-size: 0.875rem;
        cursor: pointer;
        height: 46px;
        line-height: 46px;
        transition: all 0.2s ease;
        box-shadow: 0 2px 8px rgba(227, 40, 40, 0.25);
        white-space: nowrap;
        font-family: inherit;
        letter-spacing: 0.01em;
    }
    #migros-coupon-container .apply-coupon-button:hover {
        background: linear-gradient(135deg, #d42020 0%, #b91c1c 100%);
        box-shadow: 0 4px 12px rgba(227, 40, 40, 0.35);
        transform: translateY(-1px);
    }
    #migros-coupon-container .apply-coupon-button:active {
        transform: translateY(0);
        box-shadow: 0 1px 4px rgba(227, 40, 40, 0.2);
    }
    #migros-coupon-container .apply-coupon-button:disabled {
        background: #e8ecf1;
        color: #a0aec0;
        cursor: not-allowed;
        box-shadow: none;
        transform: none;
    }

    /* ===== Uygulanan Kupon Bilgisi ===== */
    #migros-coupon-container #migros-applied-coupon {
        display: none;
        background: linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 100%);
        border: 1px solid #bbf7d0;
        border-radius: 12px;
        padding: 14px 16px;
        margin-bottom: 20px;
        animation: kuppo-slideDown 0.3s ease;
    }
    @keyframes kuppo-slideDown {
        from { opacity: 0; transform: translateY(-8px); }
        to { opacity: 1; transform: translateY(0); }
    }
    #migros-coupon-container #migros-applied-coupon .applied-coupon-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
    }
    #migros-coupon-container #migros-applied-coupon .applied-coupon-info .applied-coupon-name {
        font-weight: 600;
        color: #16a34a;
        font-size: 0.875rem;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    #migros-coupon-container #migros-applied-coupon .applied-coupon-info .applied-coupon-name::before {
        content: '✓';
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: #16a34a;
        color: #fff;
        font-size: 11px;
        font-weight: 700;
        flex-shrink: 0;
    }
    #migros-coupon-container #migros-applied-coupon .applied-coupon-info .applied-coupon-code {
        font-size: 0.75rem;
        margin-top: 4px;
        color: #6b7280;
        padding-left: 24px;
    }
    #migros-coupon-container #migros-applied-coupon .applied-coupon-value {
        font-weight: 700;
        color: #16a34a;
        font-size: 1.05rem;
        white-space: nowrap;
    }
    #migros-coupon-container .remove-coupon-button {
        background: none;
        border: none;
        color: #ef4444;
        cursor: pointer;
        font-size: 1.1rem;
        padding: 4px 6px;
        line-height: 1;
        border-radius: 6px;
        transition: background 0.15s ease;
        margin-left: 4px;
    }
    #migros-coupon-container .remove-coupon-button:hover {
        background: rgba(239, 68, 68, 0.1);
    }

    /* ===== Kullanılabilir Kuponlar Başlığı ===== */
    #migros-coupon-container .available-coupons-title {
        font-size: 0.8rem;
        font-weight: 600;
        margin-bottom: 10px;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    /* ===== Kupon Listesi ===== */
    #migros-coupon-container .coupon-list {
        border: 1px solid #e8ecf1;
        border-radius: 12px;
        padding: 4px;
        background: #fff;
        max-height: 280px;
        overflow-y: auto;
    }
    #migros-coupon-container .coupon-list::-webkit-scrollbar {
        width: 5px;
    }
    #migros-coupon-container .coupon-list::-webkit-scrollbar-track {
        background: transparent;
    }
    #migros-coupon-container .coupon-list::-webkit-scrollbar-thumb {
        background: #d1d5db;
        border-radius: 10px;
    }
    #migros-coupon-container .coupon-list::-webkit-scrollbar-thumb:hover {
        background: #9ca3af;
    }

    /* ===== Kupon Liste Öğesi ===== */
    #migros-coupon-container .coupon-list-item {
        padding: 12px 14px;
        border-radius: 10px;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: all 0.2s ease;
        margin-bottom: 2px;
        border: 1px solid transparent;
    }
    #migros-coupon-container .coupon-list-item:last-child {
        margin-bottom: 0;
    }
    #migros-coupon-container .coupon-list-item:hover {
        background: linear-gradient(135deg, #fef2f2 0%, #fff5f5 100%);
        border-color: rgba(227, 40, 40, 0.1);
    }
    #migros-coupon-container .coupon-list-item:active {
        transform: scale(0.99);
    }
    #migros-coupon-container .coupon-list-item .coupon-item-info {
        flex-grow: 1;
        margin-right: 12px;
        min-width: 0;
    }
    #migros-coupon-container .coupon-list-item .coupon-item-name {
        font-weight: 600;
        font-size: 0.85rem;
        color: #1a1a2e;
        margin-bottom: 3px;
        line-height: 1.35;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    #migros-coupon-container .coupon-list-item .coupon-item-desc {
        font-size: 0.75rem;
        color: #9ca3af;
        line-height: 1.4;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    #migros-coupon-container .coupon-list-item .coupon-item-min {
        font-size: 0.7rem;
        color: #f59e0b;
        font-weight: 600;
        margin-top: 4px;
        display: inline-flex;
        align-items: center;
        gap: 3px;
        background: #fffbeb;
        border: 1px solid #fde68a;
        padding: 2px 7px;
        border-radius: 6px;
        line-height: 1.3;
    }
    #migros-coupon-container .coupon-list-item .coupon-item-value {
        font-weight: 700;
        color: #e32828;
        font-size: 0.875rem;
        white-space: nowrap;
        background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
        padding: 4px 10px;
        border-radius: 8px;
        letter-spacing: -0.01em;
    }

    /* ===== Kart Bilgisi Uyarı Banner'ı ===== */
    #migros-coupon-container #migros-card-warning {
        display: flex;
        align-items: center;
        gap: 10px;
        background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
        border: 1px solid #fde68a;
        border-radius: 12px;
        padding: 12px 16px;
        margin-bottom: 16px;
        color: #92400e;
        font-size: 0.82rem;
        font-weight: 500;
        line-height: 1.45;
        animation: kuppo-slideDown 0.3s ease;
    }
    #migros-coupon-container #migros-card-warning svg {
        flex-shrink: 0;
        color: #f59e0b;
    }

    /* ===== Devre Dışı Kupon Formu ===== */
    #migros-coupon-container .coupon-form.coupon-form-disabled {
        opacity: 0.5;
        pointer-events: none;
        user-select: none;
    }

    /* ===== Devre Dışı Kupon Listesi ===== */
    #migros-coupon-container .coupon-list.coupon-list-disabled {
        opacity: 0.5;
        pointer-events: none;
        user-select: none;
    }

    /* ===== Kupon Bulunamadı Mesajı ===== */
    #migros-coupon-container .no-coupons-message {
        padding: 24px 16px;
        text-align: center;
        color: #9ca3af;
        font-size: 0.85rem;
    }
    #migros-coupon-container .no-coupons-message::before {
        content: '🎫';
        display: block;
        font-size: 1.5rem;
        margin-bottom: 8px;
    }

    /* ===== Fiyat Özeti Kupon Satırı ===== */
    #migros-summary-coupon-discount p {
        margin: 0;
        font-size: 0.875rem;
        line-height: 1.5;
    }
    #migros-summary-coupon-discount p:first-child {
        color: #16a34a;
    }
    #migros-summary-coupon-discount p:last-child {
        color: #16a34a;
        font-weight: 600;
        text-align: right;
    }
    #migros-summary-coupon-discount {
        grid-column: 1 / 3;
        display: grid;
        grid-template-columns: 1fr auto;
        row-gap: 0.75rem;
        justify-content: space-between;
        margin-top: 0.75rem;
    }

    /* ===== Popup Stili ===== */
    #migros-popup-container {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(4px);
        -webkit-backdrop-filter: blur(4px);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.25s ease, visibility 0.25s ease;
    }
    #migros-popup-container.visible {
        opacity: 1;
        visibility: visible;
    }
    #migros-popup {
        background-color: #fff;
        border-radius: 20px;
        box-shadow: 0 25px 60px rgba(0, 0, 0, 0.15), 0 4px 12px rgba(0, 0, 0, 0.08);
        width: 90%;
        max-width: 440px;
        padding: 0;
        overflow: hidden;
        transform: translateY(24px) scale(0.96);
        transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    #migros-popup-container.visible #migros-popup {
        transform: translateY(0) scale(1);
    }
    #migros-popup-header {
        background: linear-gradient(135deg, #e32828 0%, #dc2626 100%);
        color: white;
        padding: 20px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    #migros-popup-header.success {
        background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
    }
    #migros-popup-header.warning {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    }
    #migros-popup-header h3 {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        letter-spacing: -0.01em;
    }
    #migros-popup-close {
        background: rgba(255, 255, 255, 0.2);
        border: none;
        color: white;
        font-size: 18px;
        cursor: pointer;
        padding: 0;
        line-height: 1;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.15s ease;
    }
    #migros-popup-close:hover {
        background: rgba(255, 255, 255, 0.35);
    }
    #migros-popup-content {
        padding: 24px;
        font-size: 14px;
        line-height: 1.6;
        color: #374151;
        max-height: 55vh;
        overflow-y: auto;
    }
    #migros-popup-content:not(:has(p, ul, ol, h1, h2, h3, h4, h5, h6)) {
        white-space: pre-line;
    }
    #migros-popup-content p {
        margin: 0 0 10px 0;
    }
    #migros-popup-content ul, #migros-popup-content ol {
        margin: 0 0 10px 0;
        padding-left: 20px;
    }
    #migros-popup-content ul li, #migros-popup-content ol li {
        margin-bottom: 4px;
    }
    #migros-popup-content b {
        color: #1a1a2e;
    }
    #migros-popup-buttons {
        padding: 0 24px 24px;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    #migros-popup-buttons button {
        padding: 10px 20px;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        border: none;
        transition: all 0.2s ease;
        font-family: inherit;
    }
    #migros-popup-buttons .primary {
        background: linear-gradient(135deg, #e32828 0%, #dc2626 100%);
        color: white;
        box-shadow: 0 2px 8px rgba(227, 40, 40, 0.25);
    }
    #migros-popup-buttons .primary:hover {
        box-shadow: 0 4px 12px rgba(227, 40, 40, 0.35);
        transform: translateY(-1px);
    }
    #migros-popup-buttons .secondary {
        background: #f3f4f6;
        color: #374151;
    }
    #migros-popup-buttons .secondary:hover {
        background: #e5e7eb;
    }

    /* ===== Responsive: Tablet ===== */
    @media (min-width: 577px) and (max-width: 768px) {
        #migros-coupon-container .apply-coupon-button {
            padding: 0 18px;
            min-width: 80px;
        }
    }

    /* ===== Responsive: Mobil ===== */
    @media (max-width: 576px) {
        #migros-coupon-container {
            padding: 16px;
            border-radius: 14px;
        }
        #migros-coupon-container .coupon-form {
            flex-wrap: wrap;
        }
        #migros-coupon-container #migros-coupon-input {
            flex: 1 1 100%;
            margin-bottom: 8px;
        }
        #migros-coupon-container .apply-coupon-button {
            flex: 1 1 100%;
            padding: 0 12px;
            width: 100%;
        }
    }

    /* ===== Responsive: Küçük Mobil ===== */
    @media (max-width: 480px) {
        #migros-coupon-container .coupon-form {
            flex-wrap: nowrap;
        }
        #migros-coupon-container #migros-coupon-input {
            flex: 1;
            margin-bottom: 0;
        }
        #migros-coupon-container .apply-coupon-button {
            flex: 0 0 auto;
            width: auto;
            padding: 0 14px;
            font-size: 0.8rem;
        }
    }

    /* ===== Responsive: Çok Küçük Mobil ===== */
    @media (max-width: 360px) {
        #migros-coupon-container .apply-coupon-button {
            padding: 0 10px;
            font-size: 0.75rem;
        }
        #migros-coupon-container #migros-coupon-input {
            padding: 0 10px;
        }
        #migros-coupon-container .coupon-form {
            gap: 6px;
        }
    }
`;

const ysProductListerStyles = `
    .ys-product-lister-container {
        margin-top: 4px;
        padding: 6px;
        background-color: rgba(250, 0, 80, 0.05);
        border-radius: 4px;
        font-family: var(--bdsTypographyTitleSmallFontFamily, Open Sans, arial, sans-serif);
        border-top: 1px dashed var(--colorInteractionSecondaryBorder, #dcdcdc);
    }
    .ys-product-lister-items {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin: 0;
        padding: 0;
    }
    .ys-product-lister-item {
        display: inline-flex;
        align-items: center;
        background-color: white;
        padding: 4px 8px;
        border-radius: 12px;
        border: 1px solid var(--colorInteractionSecondaryBorder, #dcdcdc);
        max-width: calc(50% - 3px);
    }
    .ys-product-lister-item-name {
        font-weight: 500;
        font-size: 11px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        color: var(--colorNeutralPrimary, #333);
        margin-right: 4px;
        max-width: 65%;
    }
    .ys-product-lister-item-price {
        font-weight: 600;
        font-size: 11px;
        color: var(--colorBrandPrimaryDark, #00C26A);
        margin-left: auto;
    }
`;
