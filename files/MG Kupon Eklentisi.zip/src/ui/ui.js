// Bu dosya, kupon uygulamasının kullanıcı arayüzünü (UI) oluşturan,
// güncelleyen ve yöneten tüm fonksiyonları içerir.

'use strict';

// Popup bileşeni
function createPopup() {
    try {
        // Daha önce oluşturulmuş mu kontrol et
        const existingPopup = document.getElementById('migros-popup-container');
        if (existingPopup) {
            return existingPopup;
        }
        
        // Document veya body yok mu kontrol et
        if (!document || !document.body) {
            console.error('Document veya body bulunamadı');
            return null;
        }
        
        // Container oluştur
        const popupContainer = document.createElement('div');
        popupContainer.id = 'migros-popup-container';
        
        // Popup içeriği
        popupContainer.innerHTML = `
            <div id="migros-popup">
                <div id="migros-popup-header">
                    <h3 id="migros-popup-title">Bilgi</h3>
                    <button id="migros-popup-close">×</button>
                </div>
                <div id="migros-popup-content"></div>
                <div id="migros-popup-buttons">
                    <button class="primary" id="migros-popup-ok">Tamam</button>
                </div>
            </div>
        `;
        
        // Kapatma işlevleri
        const closePopup = () => {
            popupContainer.classList.remove('visible');
            setTimeout(() => {
                if (popupContainer.parentNode) {
                    popupContainer.parentNode.removeChild(popupContainer);
                }
            }, 300); // Transition süresi kadar bekleyin
        };
        
        // Önce elementlerin varlığını kontrol et
        const closeButton = popupContainer.querySelector('#migros-popup-close');
        const okButton = popupContainer.querySelector('#migros-popup-ok');
        
        if (closeButton) {
            closeButton.addEventListener('click', closePopup);
        }
        
        if (okButton) {
            okButton.addEventListener('click', closePopup);
        }
        
        // Dışa tıklama ile kapatma
        popupContainer.addEventListener('click', function(e) {
            if (e.target === popupContainer) {
                closePopup();
            }
        });
        
        document.body.appendChild(popupContainer);
        
        // Animasyon için timeout
        setTimeout(() => {
            popupContainer.classList.add('visible');
        }, 10);
        
        return popupContainer;
    } catch (error) {
        console.error('Popup oluşturma hatası:', error);
        return null;
    }
}

// Mesaj gösterme fonksiyonu (alert yerine)
function showMessage(message, title = 'Bilgi', type = 'info') {
    try {
        const popupContainer = createPopup();
        
        // Popup container oluşturulamadıysa veya beklenen elementler yoksa hata loglayıp çık
        if (!popupContainer) {
            console.error('Popup container oluşturulamadı');
            return null;
        }
        
        // Başlık ve içerik elemanlarını kontrol et
        const popupTitle = popupContainer.querySelector('#migros-popup-title');
        const popupContent = popupContainer.querySelector('#migros-popup-content');
        
        if (!popupTitle || !popupContent) {
            console.error('Popup başlık veya içerik elemanları bulunamadı');
            // Popup'ı kapat ve null döndür
            if (popupContainer.parentNode) {
                popupContainer.parentNode.removeChild(popupContainer);
            }
            return null;
        }
        
        // Başlık ve içerik ayarla
        popupTitle.textContent = title;
        
        // İçerik HTML'mi yoksa düz metin mi kontrol et
        if (message.includes('<') && message.includes('>')) {
            // İçerikte HTML etiketleri var, güvenli şekilde innerHTML olarak ayarla
            try {
                // Önce HTML string'ini DOMParser ile parse edelim
                const parser = new DOMParser();
                const doc = parser.parseFromString(message, 'text/html');
                
                // XSS korumalı şekilde içeriği ayarla
                popupContent.innerHTML = '';
                
                // Body içeriğini kopyala
                Array.from(doc.body.childNodes).forEach(node => {
                    popupContent.appendChild(node.cloneNode(true));
                });
            } catch (e) {
                console.warn('HTML parsing hatası, textContent kullanılıyor:', e);
                popupContent.textContent = message;
            }
        } else {
            // Düz metin olarak ayarla, satır sonlarını korumak için white-space: pre-line CSS var
            popupContent.textContent = message;
        }
        
        // Tip türüne göre header rengini ayarla - önce header'ın var olduğunu kontrol et
        const header = popupContainer.querySelector('#migros-popup-header');
        if (header) {
            header.className = '';
            header.id = 'migros-popup-header';
            
            if (type === 'success') {
                header.classList.add('success');
            } else if (type === 'warning' || type === 'error') {
                header.classList.add('warning');
            }
        }
        
        return popupContainer;
    } catch (error) {
        console.error('showMessage fonksiyonunda hata:', error);
        // Hata durumunda alternatif olarak console.log kullan
        console.log(`${title}: ${message}`);
        return null;
    }
}

// Kart bilgilerinin girilip girilmediğini kontrol eden fonksiyon
function isCardInfoFilled() {
    try {
        // Migros checkout sayfasındaki kart bilgi alanlarını kontrol et
        // Farklı seçiciler ile kart alanlarını bulmaya çalış
        const cardNumberInput = document.querySelector('input[name="cardNumber"], input[data-testid="card-number"], input[placeholder*="Kart Numarası"], input[placeholder*="kart numarası"], input[formcontrolname="cardNumber"], .card-number input, input[id*="cardNumber"], input[name*="cardNo"], input[autocomplete="cc-number"]');
        const expiryInput = document.querySelector('input[name="expiry"], input[name="expiryDate"], input[data-testid="expiry-date"], input[placeholder*="AA/YY"], input[placeholder*="ay/yıl"], input[formcontrolname="expiryDate"], .expiry-date input, input[id*="expiry"], input[name*="expire"], input[autocomplete="cc-exp"]');
        const cvvInput = document.querySelector('input[name="cvv"], input[name="cvc"], input[data-testid="cvv"], input[placeholder*="CVV"], input[placeholder*="CVC"], input[formcontrolname="cvv"], .cvv input, input[id*="cvv"], input[id*="cvc"], input[autocomplete="cc-csc"]');

        // Eğer kart alanları bulunamadıysa, alternatif seçiciler dene
        // Migros'un Angular bileşenlerinde input'lar farklı yapıda olabilir
        const allInputs = document.querySelectorAll('fe-line-checkout-payment input, sm-delivery-payment input, .payment-method input, .credit-card-form input, .card-form input');
        
        let cardFilled = false;
        let expiryFilled = false;
        let cvvFilled = false;

        // Önce doğrudan seçicilerle kontrol et
        if (cardNumberInput && cardNumberInput.value && cardNumberInput.value.replace(/\s/g, '').length >= 15) {
            cardFilled = true;
        }
        if (expiryInput && expiryInput.value && expiryInput.value.length >= 4) {
            expiryFilled = true;
        }
        if (cvvInput && cvvInput.value && cvvInput.value.length >= 3) {
            cvvFilled = true;
        }

        // Eğer doğrudan bulunamadıysa, tüm input'ları tara
        if (!cardFilled || !expiryFilled || !cvvFilled) {
            allInputs.forEach(input => {
                const val = input.value || '';
                const placeholder = (input.placeholder || '').toLowerCase();
                const name = (input.name || '').toLowerCase();
                const id = (input.id || '').toLowerCase();
                const type = (input.type || '').toLowerCase();
                const autocomplete = (input.autocomplete || '').toLowerCase();

                // Kart numarası kontrolü
                if (!cardFilled && (name.includes('card') || id.includes('card') || placeholder.includes('kart') || placeholder.includes('card') || autocomplete.includes('cc-number'))) {
                    if (val.replace(/\s/g, '').length >= 15) cardFilled = true;
                }
                // Son kullanma tarihi kontrolü
                if (!expiryFilled && (name.includes('expir') || id.includes('expir') || placeholder.includes('aa') || placeholder.includes('ay') || placeholder.includes('mm') || autocomplete.includes('cc-exp'))) {
                    if (val.length >= 4) expiryFilled = true;
                }
                // CVV kontrolü
                if (!cvvFilled && (name.includes('cvv') || name.includes('cvc') || id.includes('cvv') || id.includes('cvc') || placeholder.includes('cvv') || placeholder.includes('cvc') || autocomplete.includes('cc-csc'))) {
                    if (val.length >= 3) cvvFilled = true;
                }
            });
        }

        console.log(`Kart bilgi durumu - Kart No: ${cardFilled}, SKT: ${expiryFilled}, CVV: ${cvvFilled}`);
        return cardFilled && expiryFilled && cvvFilled;
    } catch (error) {
        console.error('Kart bilgisi kontrol hatası:', error);
        return false;
    }
}

// Kupon UI'ının kart bilgisi durumuna göre kilit/açık durumunu güncelleyen fonksiyon
function updateCouponUICardState() {
    const cardWarning = document.getElementById('migros-card-warning');
    const couponForm = document.querySelector('#migros-coupon-container .coupon-form');
    const couponList = document.querySelector('#migros-coupon-container .coupon-list');
    const applyButton = document.querySelector('#migros-coupon-container .apply-coupon-button');
    const couponInput = document.getElementById('migros-coupon-input');

    const filled = isCardInfoFilled();

    if (cardWarning) {
        cardWarning.style.display = filled ? 'none' : 'flex';
    }
    if (couponForm) {
        couponForm.classList.toggle('coupon-form-disabled', !filled);
    }
    if (couponList) {
        couponList.classList.toggle('coupon-list-disabled', !filled);
    }
    if (applyButton) {
        applyButton.disabled = !filled;
    }
    if (couponInput) {
        couponInput.disabled = !filled;
    }
}

// Kart alanlarındaki değişiklikleri izleyen observer'ı başlatan fonksiyon
function startCardFieldObserver() {
    // Sayfa üzerindeki input değişikliklerini dinle
    const paymentSection = document.querySelector('fe-line-checkout-payment, sm-delivery-payment, .payment-method, .credit-card-form, .card-form');
    const observeTarget = paymentSection || document.body;

    // Input olaylarını dinle (kullanıcı yazarken)
    observeTarget.addEventListener('input', function(e) {
        if (e.target.tagName === 'INPUT') {
            // Küçük bir gecikme ile kontrol et (debounce)
            clearTimeout(window.migrosKupon._cardCheckTimeout);
            window.migrosKupon._cardCheckTimeout = setTimeout(updateCouponUICardState, 300);
        }
    }, true);

    // Change olaylarını da dinle (otomatik doldurma vb.)
    observeTarget.addEventListener('change', function(e) {
        if (e.target.tagName === 'INPUT') {
            clearTimeout(window.migrosKupon._cardCheckTimeout);
            window.migrosKupon._cardCheckTimeout = setTimeout(updateCouponUICardState, 300);
        }
    }, true);

    // MutationObserver ile DOM değişikliklerini izle (Angular bileşenleri geç yüklenebilir)
    const observer = new MutationObserver(function(mutations) {
        let shouldCheck = false;
        for (const mutation of mutations) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1 && (node.tagName === 'INPUT' || node.querySelector?.('input'))) {
                        shouldCheck = true;
                        break;
                    }
                }
            }
            if (shouldCheck) break;
        }
        if (shouldCheck) {
            clearTimeout(window.migrosKupon._cardCheckTimeout);
            window.migrosKupon._cardCheckTimeout = setTimeout(updateCouponUICardState, 500);
        }
    });

    observer.observe(observeTarget, { childList: true, subtree: true });

    // Periyodik kontrol (her 2 saniyede bir) - bazı framework'ler event'leri tetiklemeyebilir
    window.migrosKupon._cardCheckInterval = setInterval(updateCouponUICardState, 2000);
}

// Kupon UI oluşturma fonksiyonu
function createCouponUI(coupons) {
    // Mevcut UI'ı temizle
    if (window.migrosKupon.couponUIContainer) {
        window.migrosKupon.couponUIContainer.remove();
        window.migrosKupon.couponUIContainer = null;
    }

    // Yeni kupon container oluştur
    const couponContainer = document.createElement('div');
    couponContainer.id = 'migros-coupon-container';
    window.migrosKupon.couponUIContainer = couponContainer; // Referansı sakla

    // Başlık ekle
    const title = document.createElement('div');
    title.className = 'coupon-title';
    // SVG for the tag icon
    title.innerHTML = `<span class="coupon-title-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21.41 11.58L12.41 2.58C12.05 2.22 11.55 2 11 2H4C2.9 2 2 2.9 2 4V11C2 11.55 2.22 12.05 2.59 12.41L11.59 21.41C11.95 21.77 12.45 22 13 22C13.55 22 14.05 21.77 14.41 21.41L21.41 14.41C21.78 14.05 22 13.55 22 13C22 12.45 21.77 11.95 21.41 11.58ZM5.5 7C4.67 7 4 6.33 4 5.5C4 4.67 4.67 4 5.5 4C6.33 4 7 4.67 7 5.5C7 6.33 6.33 7 5.5 7Z" fill="currentColor"/></svg></span><span>Kupon Uygulama</span>`;
    couponContainer.appendChild(title);

    // Kupon giriş formu ekle
    const couponForm = document.createElement('div');
    couponForm.className = 'coupon-form';

    const couponInput = document.createElement('input');
    couponInput.type = 'text';
    couponInput.id = 'migros-coupon-input';
    couponInput.placeholder = 'Kupon kodunu girin';
    couponInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            applyButton.click();
        }
    });


    const applyButton = document.createElement('button');
    applyButton.textContent = 'Uygula';
    applyButton.className = 'apply-coupon-button'; // CSS sınıfı

    couponForm.appendChild(couponInput);
    couponForm.appendChild(applyButton);
    couponContainer.appendChild(couponForm);

    // Kart bilgisi uyarı banner'ı
    const cardWarning = document.createElement('div');
    cardWarning.id = 'migros-card-warning';
    cardWarning.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z" fill="currentColor"/></svg>
        <span>Kupon uygulayabilmek için önce kart bilgilerinizi eksiksiz girin.</span>
    `;
    couponContainer.appendChild(cardWarning);

    // Kullanılan kupon bilgisini göstermek için alan
    const appliedCouponInfo = document.createElement('div');
    appliedCouponInfo.id = 'migros-applied-coupon';
    // Stil CSS'den gelecek
    couponContainer.appendChild(appliedCouponInfo);

    // Mevcut kuponlar listesi başlığı
    const availableCouponsTitle = document.createElement('div');
    availableCouponsTitle.className = 'available-coupons-title';
    availableCouponsTitle.textContent = 'Kullanılabilir Kuponlar';
    couponContainer.appendChild(availableCouponsTitle);

    // Mevcut kuponlar bölümü
    const couponList = document.createElement('div');
    couponList.className = 'coupon-list';

    if (coupons && coupons.length > 0) {
        coupons.forEach(coupon => {
            const couponItem = document.createElement('div');
            couponItem.className = 'coupon-list-item'; // CSS sınıfı

            const couponInfo = document.createElement('div');
            couponInfo.className = 'coupon-item-info'; // CSS sınıfı

            const couponName = document.createElement('div');
            couponName.className = 'coupon-item-name'; // CSS sınıfı
            couponName.textContent = coupon.name;

            const couponDescription = document.createElement('div');
            couponDescription.className = 'coupon-item-desc'; // CSS sınıfı
            couponDescription.textContent = coupon.shortDescription || coupon.userDescription || coupon.description || ''; // Daha fazla olası alan

            couponInfo.appendChild(couponName);
            couponInfo.appendChild(couponDescription);

            if (coupon.cartMinimumRevenue) {
                const couponMin = document.createElement('div');
                couponMin.className = 'coupon-item-min';
                couponMin.textContent = `Min: ${coupon.cartMinimumRevenue}`;
                couponInfo.appendChild(couponMin);
            }

            const discountVal = coupon.discountValue || coupon.discountAmount;

            couponItem.appendChild(couponInfo);

            if (discountVal) {
                const couponValue = document.createElement('div');
                couponValue.className = 'coupon-item-value'; // CSS sınıfı
                couponValue.textContent = `${(discountVal / 100).toFixed(2)} TL`;
                couponItem.appendChild(couponValue);
            }

            // Kupon kodu veya ID'yi data attribute olarak ekle
            couponItem.setAttribute('data-coupon-id', coupon.id);
            const code = coupon.code || coupon.couponCode;
            if (code) {
                couponItem.setAttribute('data-coupon-code', code);
            }

             // Kupona tıklandığında otomatik uygula
            couponItem.addEventListener('click', async function() {
                // Kart bilgisi kontrolü
                if (!isCardInfoFilled()) {
                    showMessage('Kupon uygulayabilmek için önce kart bilgilerinizi eksiksiz girin.', 'Kart Bilgisi Gerekli', 'warning');
                    return;
                }

                const clickedCouponId = this.getAttribute('data-coupon-id');
                const clickedCouponCode = this.getAttribute('data-coupon-code'); // Kodu alalım

                // Kupon kodunu input alanına gösterelim (varsa)
                 couponInput.value = clickedCouponCode || '';

                console.log(`Selected coupon - ID: ${clickedCouponId}, Code: ${clickedCouponCode || 'N/A'}`);

                // Kuponu doğrudan uygula (önce ID ile dene)
                await applyCouponAction(clickedCouponCode, clickedCouponId);
            });


            couponList.appendChild(couponItem);
        });
    } else {
        const noCoupons = document.createElement('div');
        noCoupons.className = 'no-coupons-message'; // CSS sınıfı
        noCoupons.textContent = 'Kullanılabilir kupon bulunamadı.';
        couponList.appendChild(noCoupons);
    }

    couponContainer.appendChild(couponList);

     // Kupon uygulama butonuna event listener ekle
    applyButton.addEventListener('click', async function() {
        // Kart bilgisi kontrolü
        if (!isCardInfoFilled()) {
            showMessage('Kupon uygulayabilmek için önce kart bilgilerinizi eksiksiz girin.', 'Kart Bilgisi Gerekli', 'warning');
            return;
        }

        const couponCode = couponInput.value.trim();
        if (!couponCode) {
            alert('Lütfen bir kupon kodu girin');
            return;
        }
         // Sadece kod ile uygulama
        await applyCouponAction(couponCode, null);
    });

    // Başlangıçta kart bilgisi durumunu kontrol et ve UI'ı güncelle
    setTimeout(() => {
        updateCouponUICardState();
        startCardFieldObserver();
    }, 500);

    return couponContainer;
}

// Başarılı kupon uygulamasını işleyen fonksiyon
function handleSuccessfulCouponApplication(couponData) {
     if (!couponData) {
         console.error('handleSuccessfulCouponApplication: Geçersiz couponData alındı.');
         return;
     }

     // Global değişkene ata
     window.migrosKupon.appliedCouponData = couponData;

     console.log('Uygulanan kupon verileri (discountResult):', couponData);

     // En güvenilir kupon ID'sini global değişkene ata
     // Öncelik 1: Doğrudan couponData nesnesindeki ID değeri
     // Öncelik 2: discountResult içindeki ID değeri
     // Öncelik 3: Daha önceden çakışma çözümünden kaydettiğimiz ID
     // Öncelik 4: Orijinal kupon ID'si
     const finalDiscountId = 
         couponData.id || 
         couponData.discountId || 
         (couponData.discountResult && (couponData.discountResult.id || couponData.discountResult.discountId)) || 
         window.migrosKupon.validDiscountId || 
         window.migrosKupon.originalCouponId;
         
     if (finalDiscountId) {
         window.migrosKupon.validDiscountId = finalDiscountId;
         console.log('handleSuccessfulCouponApplication: `validDiscountId` güncellendi:', finalDiscountId);
     } else {
         // Hata durumunda bir fallback değer atayalım
         if (couponData.discountValue) {
             // Geçici bir ID oluştur - bu en azından hiç değer olmamasından iyidir
             const tempId = "temp_" + Date.now();
             window.migrosKupon.validDiscountId = tempId;
             console.warn('handleSuccessfulCouponApplication: ID bulunamadı, geçici ID atandı:', tempId);
         } else {
             console.error('handleSuccessfulCouponApplication: Geçerli bir kupon ID bulunamadı!');
         }
     }


    // Uygulanan kuponu UI'da göster
    const appliedCouponInfo = document.getElementById('migros-applied-coupon');
    if (appliedCouponInfo) {
        appliedCouponInfo.style.display = 'block';
        // Kupon kaldırma butonu ekle
        const removeButton = document.createElement('button');
        removeButton.innerHTML = '×'; // Çarpı işareti
        removeButton.title = 'Kuponu Kaldır';
        removeButton.className = 'remove-coupon-button'; // CSS sınıfı
        removeButton.onclick = () => {
             clearAppliedCouponUI(true); // UI'ı temizle ve global değişkenleri sıfırla
        };


        appliedCouponInfo.innerHTML = `
            <div class="applied-coupon-content">
                <div class="applied-coupon-info">
                    <div class="applied-coupon-name">Kupon Uygulandı: ${couponData.name || 'İsimsiz Kupon'}</div>
                    <div class="applied-coupon-code">${couponData.code || 'ID: ' + finalDiscountId || 'Kod/ID Yok'}</div>
                </div>
                <div class="applied-coupon-value">
                    -${(couponData.discountValue / 100).toFixed(2)} TL
                </div>
            </div>
        `;
         // Kaldırma butonunu sona ekle
         appliedCouponInfo.querySelector('.applied-coupon-content').appendChild(removeButton);
    }

    // Fiyat özetini güncelle
    updatePriceSummaryUI(couponData.discountValue);

    // Kullanıcıya bilgi ver (opsiyonel, UI yeterli olabilir)
    // alert(`${couponData.name || 'Kupon'} başarıyla uygulandı! İndirim: ${(couponData.discountValue / 100).toFixed(2)} TL`);
}

// Fiyat özetini güncelleyen yardımcı fonksiyon
function updatePriceSummaryUI(discountValue) {
    const priceSummaryContent = document.querySelector('fe-line-checkout-price-summary .summary-content');
    const mobileSummaryContent = document.querySelector('.checkout-summary-mobile__content');
    const totalPriceElements = document.querySelectorAll('fe-line-checkout-price-summary .summary > .subtitle-1.text-align-right, .checkout-summary-mobile__content .revenue');
    
    if (!priceSummaryContent && !mobileSummaryContent) {
        console.warn('Fiyat özeti elemanları bulunamadı, UI güncellenemiyor.');
        return;
    }

    // Temizleme işlemleri - tüm mevcut kupon indirim satırlarını kaldır
    // Mevcut kupon indirimi satırını kaldır (varsa)
    const existingDiscountRows = document.querySelectorAll('#migros-summary-coupon-discount');
    existingDiscountRows.forEach(row => row.remove());
    
    // Mobil görünümdeki mevcut indirim satırını kaldır (varsa)
    const existingMobileDiscountRow = document.getElementById('migros-mobile-coupon-discount');
    if (existingMobileDiscountRow) {
        existingMobileDiscountRow.remove();
    }
    
    // Web ve mobil görünümdeki tüm kupon indirimi satırlarını temizle
    const allDiscountSections = document.querySelectorAll('.discounts');
    allDiscountSections.forEach(section => {
        const webDiscountRows = section.querySelectorAll('.discount');
        webDiscountRows.forEach(row => {
            if (row.textContent.includes('Kupon İndirimi')) {
                row.remove();
            }
        });
    });
    
    // Özel oluşturduğumuz discounts containeri temizle
    const customDiscountsContainer = document.getElementById('migros-custom-discounts');
    if (customDiscountsContainer) {
        customDiscountsContainer.remove();
    }

    // Hangi görünümdeyiz: Mobil mi Masaüstü mü?
    const isMobile = !!document.querySelector('fe-line-checkout-price-summary.mobile-only');
    const isDesktop = !!document.querySelector('.desktop-only fe-line-checkout-price-summary') || 
                      !!document.querySelector('fe-line-checkout-summary-desktop');
    
    console.log('Görünüm tipi:', isMobile ? 'Mobil' : (isDesktop ? 'Masaüstü' : 'Bilinmiyor'));
    
    // Masaüstü görünüm için indirim satırı
    if (priceSummaryContent && !isMobile) {
        // Ana özet içinde kupon indirimi satırı (sadece desktop'ta ekle)
        const discountRow = document.createElement('div');
        discountRow.id = 'migros-summary-coupon-discount';
        discountRow.innerHTML = `
            <p>Kupon İndirimi</p>
            <p>-${(discountValue / 100).toFixed(2)} TL</p>
        `;

        // İndirimi "Teslimat Tutarı" (varsa) veya "Toplam Tutar"dan sonraya ekle
        const deliveryPriceRow = priceSummaryContent.querySelector('#checkout-price-summary-delivery-price');
        if (deliveryPriceRow && deliveryPriceRow.nextSibling) {
             priceSummaryContent.insertBefore(discountRow, deliveryPriceRow.nextSibling);
        } else if (deliveryPriceRow) {
             priceSummaryContent.appendChild(discountRow); // Teslimat son elemansa sona ekle
        } else {
            // Teslimat yoksa, Toplam Tutar'dan sonra ekle
             const totalAmountRow = Array.from(priceSummaryContent.querySelectorAll('p')).find(p => p.textContent.includes('Toplam Tutar'));
             if (totalAmountRow && totalAmountRow.nextElementSibling) {
                 priceSummaryContent.insertBefore(discountRow, totalAmountRow.nextElementSibling.nextSibling);
             } else {
                  priceSummaryContent.appendChild(discountRow); // En sona ekle
             }
        }
    }
    
    // Web görünümünde discounts alanına ekleme yap - birden fazla yöntem dene
    // YENİ: Doğrudan mevcut discounts elementini kullan ve içeriğini düzenle
    let webDiscountsAdded = false;
    
    // Masaüstü görünümde doğrudan .discounts sınıfına sahip elemente ekleme yap
    if (isDesktop) {
        try {
            // 1. Doğrudan discounts sınıfına sahip elementleri bul (birden fazla olabilir)
            const discountsSections = document.querySelectorAll('.discounts');
            if (discountsSections.length > 0) {
                discountsSections.forEach(discountsSection => {
                    // Mevcut discounts içeriğini koru ama kupon indirimi ekle
                    const discountRow = document.createElement('div');
                    discountRow.className = 'discount';
                    discountRow.style.display = 'flex';
                    discountRow.style.justifyContent = 'space-between';
                    discountRow.style.alignItems = 'center';
                    discountRow.style.padding = '4px 0';
                    
                    // Kupon indirimi satırının içeriği
                    discountRow.innerHTML = `
                        <p style="color: #228B22; margin: 0; font-weight: 500;">Kupon İndirimi</p>
                        <p style="color: #228B22; margin: 0; text-align: right; font-weight: 500;">-${(discountValue / 100).toFixed(2)} TL</p>
                    `;
                    
                    // Discounts elementine ekle ve göster
                    discountsSection.appendChild(discountRow);
                    discountsSection.style.display = 'block';
                    
                    webDiscountsAdded = true;
                    console.log('Mevcut discounts elementine kupon indirimi eklendi');
                });
            }
            
            // 2. Eğer .discounts bulunamadıysa veya indirim eklenemezse, discounts oluştur
            if (!webDiscountsAdded) {
                // Ödenecek Tutar başlığının hemen önüne eklemek için hedef eleman bul
                const summaryElement = document.querySelector('.desktop-only fe-line-checkout-price-summary .summary') || 
                                      document.querySelector('fe-line-checkout-summary-desktop fe-line-checkout-price-summary .summary') ||
                                      document.querySelector('fe-line-checkout-price-summary .summary');
                                      
                const paymentTitle = summaryElement?.querySelector('.subtitle-1:nth-last-child(2)');
                
                if (summaryElement && paymentTitle) {
                    // Yeni discounts containeri oluştur
                    const discountsContainer = document.createElement('div');
                    discountsContainer.id = 'migros-custom-discounts';
                    discountsContainer.className = 'discounts';
                    discountsContainer.style.display = 'block';
                    discountsContainer.style.margin = '10px 0';
                    
                    // İndirim satırı ekle
                    const discountHTML = `
                        <div class="discount" style="display: flex; justify-content: space-between; padding: 4px 0;">
                            <p style="color: #228B22; margin: 0; font-weight: 500;">Kupon İndirimi</p>
                            <p style="color: #228B22; margin: 0; text-align: right; font-weight: 500;">-${(discountValue / 100).toFixed(2)} TL</p>
                        </div>
                    `;
                    
                    discountsContainer.innerHTML = discountHTML;
                    
                    // Ödenecek Tutar başlığı öncesine ekle
                    summaryElement.insertBefore(discountsContainer, paymentTitle);
                    
                    webDiscountsAdded = true;
                    console.log('Özel discounts container oluşturuldu ve eklendi');
                }
            }
            
            // 3. Son çare: Doğrudan summary-content içine ekle
            if (!webDiscountsAdded && priceSummaryContent) {
                const discountRow = document.createElement('div');
                discountRow.id = 'migros-summary-coupon-discount-direct';
                discountRow.style.display = 'flex';
                discountRow.style.justifyContent = 'space-between';
                discountRow.style.padding = '8px 0';
                discountRow.style.margin = '8px 0';
                discountRow.style.borderTop = '1px dashed #eee';
                discountRow.style.borderBottom = '1px dashed #eee';
                
                discountRow.innerHTML = `
                    <p style="color: #228B22; margin: 0; font-weight: 500;">Kupon İndirimi</p>
                    <p style="color: #228B22; margin: 0; text-align: right; font-weight: 500;">-${(discountValue / 100).toFixed(2)} TL</p>
                `;
                
                // summary-content sonuna ekle
                priceSummaryContent.appendChild(discountRow);
                
                webDiscountsAdded = true;
                console.log('Doğrudan summary-content içine indirim satırı eklendi');
            }
        } catch (e) {
            console.error('Web görünümüne indirim eklenirken hata:', e);
        }
    }
    
    // Mobil görünüm için indirim satırı
    if (mobileSummaryContent) {
        const mobileDiscountRow = document.createElement('div');
        mobileDiscountRow.id = 'migros-mobile-coupon-discount';
        mobileDiscountRow.className = 'revenue-container coupon-discount';
        mobileDiscountRow.style.marginBottom = '0.5rem';
        mobileDiscountRow.style.color = '#228B22'; // Yeşil renk
        mobileDiscountRow.innerHTML = `
            <div class="mat-caption-normal">Kupon İndirimi</div>
            <h3 class="revenue">-${(discountValue / 100).toFixed(2)} TL</h3>
        `;
        
        // İndirimi "Ödenecek Tutar" göstergesinin üstüne ekle
        const revenueContainer = mobileSummaryContent.querySelector('.revenue-container');
        if (revenueContainer) {
            mobileSummaryContent.insertBefore(mobileDiscountRow, revenueContainer);
        } else {
            mobileSummaryContent.insertBefore(mobileDiscountRow, mobileSummaryContent.firstChild);
        }
    }

    // Ödenecek Tutar'ı güncelle - hem masaüstü hem de mobil görünüm
    try {
        // Ödenecek tutarı al (doğrudan)
        let currentTotal = 0;
        
        // ÇAKIŞMA KONTROLÜ - Eğer bu bir kupon çakışması çözümü ise (resolve-conflict)
        // ve removableDiscountAmountLabel varsa, bu durumda
        // orijinal fiyatı doğrudan hesaplamaya çalışacağız
        // Kupon çakışması olduğunu nasıl anlarız? window.migrosKupon.conflictResolution 
        // flag'i ile kontrol ederiz, bu flag applyCouponAction içinde ayarlanacak
        
        if (window.migrosKupon.conflictResolution && window.migrosKupon.removableDiscountAmount) {
            // Çakışma çözümündeyiz ve kaldırılan indirim miktarını biliyoruz
            // Mevcut fiyata kaldırılan indirimi ekleyerek gerçek orijinal fiyatı bulalım
            
            // Mevcut gösterilen fiyatı al
            if (totalPriceElements && totalPriceElements.length > 0) {
                const priceText = totalPriceElements[0].textContent.trim();
                const currentShownPrice = parseFloat(priceText.replace(/[^0-9,-]+/g, "").replace(",", "."));
                
                if (!isNaN(currentShownPrice)) {
                    // Gerçek orijinal fiyat = mevcut fiyat + kaldırılan indirim
                    // removableDiscountAmount kuruş cinsinden, TL'ye çevirmeliyiz
                    const removableAmount = window.migrosKupon.removableDiscountAmount / 100;
                    window.migrosKupon.originalPrice = currentShownPrice + removableAmount;
                    
                    console.log(`Çakışma çözümü: Mevcut fiyat (${currentShownPrice}) + Kaldırılan indirim (${removableAmount}) = Gerçek orijinal fiyat (${window.migrosKupon.originalPrice})`);
                    currentTotal = window.migrosKupon.originalPrice;
                }
            }
            
            // temizle
            window.migrosKupon.conflictResolution = false;
            window.migrosKupon.removableDiscountAmount = null;
        }
        // Eğer orijinal fiyat henüz kaydedilmediyse kaydet
        else if (window.migrosKupon.originalPrice === null) {
            // İlk önce mevcut "Ödenecek Tutar" değerini al
            if (totalPriceElements && totalPriceElements.length > 0) {
                const priceText = totalPriceElements[0].textContent.trim();
                window.migrosKupon.originalPrice = parseFloat(priceText.replace(/[^0-9,-]+/g, "").replace(",", "."));
                currentTotal = window.migrosKupon.originalPrice;
                console.log('Orijinal fiyat kaydedildi:', currentTotal);
            }
            
            if (isNaN(window.migrosKupon.originalPrice) || window.migrosKupon.originalPrice === 0) {
                console.warn('Mevcut ödenecek tutar alınamadı, alternatif yöntem deneniyor...');
                // Alternatif: Ödenecek tutar başlık elemanını bul
                const paymentTitleElem = document.querySelector('.summary .subtitle-1:nth-last-child(2)');
                if (paymentTitleElem && paymentTitleElem.textContent.includes('Ödenecek Tutar')) {
                    const paymentValueElem = paymentTitleElem.nextElementSibling;
                    if (paymentValueElem) {
                        window.migrosKupon.originalPrice = parseFloat(paymentValueElem.textContent.replace(/[^0-9,-]+/g, "").replace(",", "."));
                        currentTotal = window.migrosKupon.originalPrice;
                    }
                }
            }
        } else {
            currentTotal = window.migrosKupon.originalPrice;
        }
        
        if (!isNaN(currentTotal) && currentTotal > 0) {
            // Ödenecek tutardan direkt indirimi çıkar
            const newTotal = (currentTotal - (discountValue / 100)).toFixed(2).replace('.', ',');
            
            // Tüm "Ödenecek Tutar" değerlerini güncelle
            totalPriceElements.forEach(element => {
                element.textContent = `${newTotal} TL`;
            });
            
            console.log(`Ödenecek tutar güncellendi: ${newTotal} TL (İndirim: ${(discountValue / 100).toFixed(2)} TL)`);
        } else {
            console.error("Ödenecek tutar alınamadı, UI güncellenemedi:", currentTotal);
        }
    } catch(e) {
        console.error("Ödenecek tutar güncellenemedi:", e);
    }
}

// Uygulanmış kupon UI'ını ve global değişkenleri temizleyen fonksiyon
function clearAppliedCouponUI(resetGlobals = false) {
    const appliedCouponInfo = document.getElementById('migros-applied-coupon');
    if (appliedCouponInfo) {
        appliedCouponInfo.style.display = 'none';
        appliedCouponInfo.innerHTML = '';
    }

    // Fiyat özetindeki indirimi kaldır
    const existingDiscountRows = document.querySelectorAll('#migros-summary-coupon-discount, #migros-summary-coupon-discount-direct');
    existingDiscountRows.forEach(row => row.remove());
    
    // Mobil görünümdeki indirim satırını kaldır
    const existingMobileDiscountRow = document.getElementById('migros-mobile-coupon-discount');
    if (existingMobileDiscountRow) {
        existingMobileDiscountRow.remove();
    }
    
    // Özel discounts container'ı kaldır
    const customDiscountsContainer = document.getElementById('migros-custom-discounts');
    if (customDiscountsContainer) {
        customDiscountsContainer.remove();
    }
    
    // Web görünümündeki indirim satırlarını temizle
    try {
        // Normal discounts seçicisini temizle
        const discountsSections = document.querySelectorAll('.discounts');
        discountsSections.forEach(section => {
            const webDiscountRows = section.querySelectorAll('.discount');
            webDiscountRows.forEach(row => {
                if (row.textContent.includes('Kupon İndirimi')) {
                    row.remove();
                }
            });
        });
    } catch (e) {
        console.error('Web görünümündeki indirim satırları temizlenirken hata:', e);
    }
    
    // Ödenecek tutarı orijinal değerine geri döndür
    try {
        if (window.migrosKupon.originalPrice !== null) {
            const totalPriceElements = document.querySelectorAll('fe-line-checkout-price-summary .summary > .subtitle-1.text-align-right, .checkout-summary-mobile__content .revenue');
            
            const originalPriceFormatted = window.migrosKupon.originalPrice.toFixed(2).replace('.', ',');
            
            // Tüm "Ödenecek Tutar" değerlerini güncelle
            totalPriceElements.forEach(element => {
                element.textContent = `${originalPriceFormatted} TL`;
            });
            
            console.log(`Ödenecek tutar orijinal değerine geri döndürüldü: ${originalPriceFormatted} TL`);
        }
    } catch(e) {
        console.error("Orijinal fiyata geri döndürülemedi:", e);
    }

     if (resetGlobals) {
         console.log('Uygulanan kupon bilgileri sıfırlanıyor.');
         window.migrosKupon.appliedCouponData = null;
         window.migrosKupon.validDiscountId = null;
         window.migrosKupon.originalCouponId = null;
         window.migrosKupon.originalPrice = null; // Orijinal fiyatı da sıfırla
         const couponInput = document.getElementById('migros-coupon-input');
         if (couponInput) couponInput.value = ''; // Input'u temizle
     }
}

// Sayfa yüklendiğinde UI'ı ekle
function addCouponUI() {
    // Sayfada ödeme özeti bölümü var mı kontrol et
    // Hem mobil hem de masaüstü görünümü hedefle
    const targetSelector = 'sm-delivery-payment .side-container fe-line-checkout-summary-desktop, sm-delivery-payment .checkout-container fe-line-checkout-price-summary.mobile-only';
    const paymentSummaryContainer = document.querySelector(targetSelector);

    if (!paymentSummaryContainer) {
        console.log('Ödeme özeti bölümü bulunamadı, UI eklenmiyor.');
        return; // Hedef element yoksa UI ekleme
    }

     // Zaten eklenmiş mi kontrol et
     if (document.getElementById('migros-coupon-container')) {
         console.log('Kupon UI zaten ekli.');
         return;
     }


    window.migrosKupon.currentService = detectService();
    if (!window.migrosKupon.currentService) {
        console.error('Servis tipi tespit edilemedi.');
        return;
    }

    console.log('Migros servis tipi:', window.migrosKupon.currentService);

    // Kuponları getir ve UI'ı oluştur
    fetchCoupons(window.migrosKupon.currentService).then(coupons => {
        const couponUI = createCouponUI(coupons);

        // UI'ı ödeme bölümünün *üstüne* ekle
        // Desktop: fe-line-checkout-summary-desktop'ın üstüne
        // Mobile: fe-line-checkout-price-summary.mobile-only'nin üstüne
         const desktopTarget = document.querySelector('sm-delivery-payment .side-container fe-line-checkout-summary-desktop');
         const mobileTarget = document.querySelector('sm-delivery-payment .checkout-container fe-line-checkout-price-summary.mobile-only');


         if (mobileTarget) {
             // Mobil görünümde price summary'nin hemen üstüne ekle
             mobileTarget.parentNode.insertBefore(couponUI, mobileTarget);
             console.log('Kupon UI mobil görünüme eklendi.');
         }

          // UI eklendikten sonra, eğer önceden uygulanmış bir kupon varsa onu göster
          if (window.migrosKupon.appliedCouponData) {
               handleSuccessfulCouponApplication(window.migrosKupon.appliedCouponData);
          }

    }).catch(error => {
        console.error("UI eklenirken kuponlar getirilemedi:", error);
    });
}

function addStyles() {
    const styleElement = document.createElement('style');
    styleElement.textContent = ysProductListerStyles;
    document.head.appendChild(styleElement);
}
