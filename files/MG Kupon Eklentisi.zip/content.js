// Load browser compatibility layer
(function() {
  const api = typeof chrome !== 'undefined' ? chrome : (typeof browser !== 'undefined' ? browser : null);
  if (api && !window.chrome) {
    window.chrome = api;
  }
})();

// Promise tabanlı script enjeksiyonu, yükleme sırasını garanti eder.
function injectScript(file) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.setAttribute('type', 'text/javascript');
    const api = typeof chrome !== 'undefined' ? chrome : (typeof browser !== 'undefined' ? browser : null);
    script.setAttribute('src', api.runtime.getURL(file));
    script.onload = () => {
      // Script başarıyla yüklendiğinde, bir sonraki adıma geçmek için resolve et.
      // Script'i DOM'dan kaldırmak, global scope'ta tanımlanan fonksiyonları etkilemez.
      script.remove(); 
      resolve();
    };
    script.onerror = (e) => {
      // Yükleme hatası durumunda reject et.
      reject(new Error(`Script yüklenemedi: ${file}`));
    };
    (document.head || document.documentElement).appendChild(script);
  });
}

function injectStyles() {
  const styleContent = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');

    #ys-process-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(16px) saturate(1.2);
      -webkit-backdrop-filter: blur(16px) saturate(1.2);
      z-index: 2147483647;
      display: flex;
      justify-content: center;
      align-items: center;
      opacity: 0;
      visibility: hidden;
      transition: opacity 0.35s cubic-bezier(0.4, 0, 0.2, 1), visibility 0.35s;
      pointer-events: none;
      padding: 20px;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }

    #ys-process-overlay.active {
      opacity: 1;
      visibility: visible;
      pointer-events: all;
    }

    .ys-process-container {
      background: #18181b;
      border-radius: 20px;
      padding: 28px;
      width: 100%;
      max-width: 440px;
      box-shadow: 0 0 0 1px rgba(255,255,255,0.08), 0 20px 50px -12px rgba(0,0,0,0.6);
      transform: translateY(16px) scale(0.97);
      transition: transform 0.35s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }

    .ys-process-container::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: linear-gradient(90deg, #6366f1, #8b5cf6, #a78bfa, #6366f1);
      background-size: 200% 100%;
      animation: ysShimmer 2s linear infinite;
    }

    #ys-process-overlay.active .ys-process-container {
      transform: translateY(0) scale(1);
    }

    .ys-process-header {
      margin-bottom: 20px;
      padding-right: 44px;
    }

    .ys-header-content {
      display: flex;
      align-items: center;
      gap: 10px;
      color: #f4f4f5;
      font-size: 16px;
      font-weight: 600;
      letter-spacing: -0.2px;
    }

    .ys-status-dot {
      width: 8px;
      height: 8px;
      background: #22c55e;
      border-radius: 50%;
      animation: ysPulse 2s ease-in-out infinite;
      box-shadow: 0 0 8px rgba(34, 197, 94, 0.6);
      flex-shrink: 0;
    }

    .ys-close-button {
      background: transparent;
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.5);
      font-size: 18px;
      cursor: pointer;
      padding: 0;
      border-radius: 10px;
      transition: all 0.2s ease;
      line-height: 1;
      position: absolute;
      right: 16px;
      top: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      height: 30px;
      z-index: 1;
    }

    .ys-close-button:hover {
      color: #fff;
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.2);
    }

    #ys-process-logs {
      max-height: min(65vh, 360px);
      overflow-y: auto;
      padding: 14px;
      background: rgba(255, 255, 255, 0.03);
      border-radius: 14px;
      font-family: 'SF Mono', 'Cascadia Code', 'Fira Code', 'Roboto Mono', monospace;
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.15) transparent;
      border: 1px solid rgba(255, 255, 255, 0.06);
    }

    #ys-process-logs::-webkit-scrollbar {
      width: 5px;
    }

    #ys-process-logs::-webkit-scrollbar-track {
      background: transparent;
    }

    #ys-process-logs::-webkit-scrollbar-thumb {
      background-color: rgba(255, 255, 255, 0.15);
      border-radius: 3px;
    }

    #ys-process-logs:empty::after {
      content: 'İşlem başlatılıyor...';
      display: block;
      text-align: center;
      color: rgba(255,255,255,0.3);
      font-size: 13px;
      padding: 24px 0;
    }

    .ys-log-entry {
      padding: 10px 14px;
      margin: 6px 0;
      border-radius: 10px;
      font-size: 12.5px;
      line-height: 1.5;
      letter-spacing: 0.1px;
      border: 1px solid transparent;
      animation: ysSlideIn 0.25s ease forwards;
      opacity: 0;
      transform: translateY(6px);
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .ys-log-entry::before {
      content: '';
      display: inline-block;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .ys-log-entry.info {
      background: rgba(99, 102, 241, 0.1);
      color: #a5b4fc;
      border-color: rgba(99, 102, 241, 0.15);
    }

    .ys-log-entry.info::before {
      background: #818cf8;
    }

    .ys-log-entry.success {
      background: rgba(34, 197, 94, 0.1);
      color: #86efac;
      border-color: rgba(34, 197, 94, 0.15);
    }

    .ys-log-entry.success::before {
      background: #4ade80;
    }

    .ys-log-entry.error {
      background: rgba(239, 68, 68, 0.1);
      color: #fca5a5;
      border-color: rgba(239, 68, 68, 0.15);
    }

    .ys-log-entry.error::before {
      background: #f87171;
    }

    .ys-log-entry.warning {
      background: rgba(245, 158, 11, 0.1);
      color: #fcd34d;
      border-color: rgba(245, 158, 11, 0.15);
    }

    .ys-log-entry.warning::before {
      background: #fbbf24;
    }

    @keyframes ysSlideIn {
      from {
        opacity: 0;
        transform: translateY(6px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes ysPulse {
      0%, 100% {
        opacity: 1;
        box-shadow: 0 0 8px rgba(34, 197, 94, 0.6);
      }
      50% {
        opacity: 0.6;
        box-shadow: 0 0 4px rgba(34, 197, 94, 0.3);
      }
    }

    @keyframes ysShimmer {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }

    @media (max-width: 480px) {
      #ys-process-overlay {
        padding: 12px;
      }

      .ys-process-container {
        border-radius: 16px;
        padding: 22px;
      }

      .ys-header-content {
        font-size: 15px;
      }

      #ys-process-logs {
        padding: 12px;
        max-height: 55vh;
      }

      .ys-log-entry {
        padding: 8px 12px;
        font-size: 12px;
      }

      .ys-close-button {
        right: 12px;
        top: 16px;
        width: 28px;
        height: 28px;
        font-size: 16px;
      }
    }
  `;

  const style = document.createElement('style');
  style.textContent = styleContent;
  
  if (document.head) {
    document.head.appendChild(style);
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      document.head.appendChild(style);
    });
  }
}

// Harici sitelerden gelen mesajları dinle
window.addEventListener('message', async function(event) {
  // Güvenlik kontrolü - sadece güvenilir domainlerden gelen mesajları kabul et
  const trustedDomains = ['kuppo.net', 'localhost']; // Güvenilir domainleri buraya ekleyin
  const eventOrigin = new URL(event.origin).hostname;
  if (!trustedDomains.some(domain => eventOrigin.endsWith(domain))) {
    return;
  }

  if (event.data.type === 'startTokenProcess') {
    // Önce güncelleme kontrolü yap
    const updateCheck = await checkForExtensionUpdates();
    
    if (updateCheck.needsUpdate) {
      // Güncelleme gerekiyorsa popup göster
      showUpdatePopupOverlay(updateCheck.updateData);
      // Eğer zorunlu değilse, laterButton'a tıklandığında işlem başlayacak
      // Bu durumda token işlemesini başlatmak için proceedWithYsProcessOverlay fonksiyonunu çağıracağız
      if (!updateCheck.updateData.is_mandatory) {
        const laterButton = document.querySelector('#update-later-button');
        if (laterButton) {
          laterButton.addEventListener('click', () => {
            proceedWithYsProcessOverlay(event.data.token);
          });
        }
      }
    } else {
      // Güncelleme gerekmiyorsa token işlemini başlat
      proceedWithYsProcessOverlay(event.data.token);
    }
  }
});

// YS Process Overlay ile token işlemini başlat
function proceedWithYsProcessOverlay(token) {
  // Zaten bir overlay varsa tekrar oluşturma
  if (document.getElementById('ys-process-overlay')) {
    return;
  }

  // MG token kontrolü - son part'ı kontrol et
  const tokenParts = token.split('-');
  let actualToken = token;
  let mgServiceType = null;
  
  if (tokenParts.length === 5) {
    const lastPart = tokenParts[4];
    
    // Son part 13 hane ise özel işlem
    if (lastPart.length === 13) {
      const lastChar = lastPart.charAt(12).toLowerCase();
      
      // Son harfe göre servis tipini belirle
      if (lastChar === 'i') {
        mgServiceType = 'hemen';
        console.log('Site içi giriş: Migros Hemen servisi seçildi');
      } else if (lastChar === 'l') {
        mgServiceType = 'yemek';
        console.log('Site içi giriş: Migros Yemek servisi seçildi');
      } else if (lastChar === 'h') {
        mgServiceType = 'sanalmarket';
        console.log('Site içi giriş: Migros Sanal Market servisi seçildi');
      }
      
      // Son harfi çıkart
      tokenParts[4] = lastPart.substring(0, 12);
      actualToken = tokenParts.join('-');
      
      console.log(`Site içi giriş: Token işleniyor (${mgServiceType})...`);
    }
  }
  
  // Overlay'i ekle ve aktifleştir
  const overlay = document.createElement('div');
  overlay.id = 'ys-process-overlay';
  overlay.innerHTML = `
    <div class="ys-process-container">
      <button class="ys-close-button">&times;</button>
      <div class="ys-process-header">
        <div class="ys-header-content">
          <div class="ys-status-dot"></div>
          <span>İşlem Durumu</span>
        </div>
      </div>
      <div id="ys-process-logs"></div>
    </div>
  `;
  document.body.appendChild(overlay);
  
  // Overlay'i görünür yap - çift rAF ile tarayıcının DOM'u renderlamasını garanti et
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      overlay.classList.add('active');
    });
  });
  
  // Kapatma butonuna tıklama olayı ekle
  const closeButton = overlay.querySelector('.ys-close-button');
  closeButton.addEventListener('click', () => {
    overlay.classList.remove('active');
    setTimeout(() => {
      if (overlay.parentNode) overlay.remove();
    }, 350);
  });

  // Background script'e token işlemini başlatma mesajı gönder
  chrome.runtime.sendMessage({
    action: 'startExternalTokenProcess',
    token: actualToken,
    originalToken: token,
    mgServiceType: mgServiceType
  });
}

// Background script'ten gelen log mesajlarını dinle (tek merkezi listener)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'updateLog') {
    // Önce ys-process-overlay log alanını kontrol et
    const ysLogsContainer = document.getElementById('ys-process-logs');
    if (ysLogsContainer) {
      const logEntry = document.createElement('div');
      logEntry.className = `ys-log-entry ${message.type}`;
      logEntry.textContent = message.message;
      ysLogsContainer.appendChild(logEntry);
      ysLogsContainer.scrollTop = ysLogsContainer.scrollHeight;
    }
    // Eski token-processing overlay log alanını da kontrol et
    const oldLogContainer = document.getElementById('log-container');
    if (oldLogContainer) {
      updateLogInOverlay(message.message, message.type);
    }
  } else if (message.action === 'closeOverlay') {
    // ys-process-overlay'i kapat
    const ysOverlay = document.getElementById('ys-process-overlay');
    if (ysOverlay) {
      ysOverlay.classList.remove('active');
      setTimeout(() => {
        if (ysOverlay.parentNode) ysOverlay.remove();
      }, 350);
    }
    // Eski token-processing overlay'i de kapat
    closeTokenProcessingOverlay();
  }
});

// İzin verilen domainlerde çalış
function isAllowedDomain() {
  const allowedDomains = [
    'yemeksepeti.com', 'www.yemeksepeti.com',
    'migros.com.tr', 'www.migros.com.tr', 
    'tgoyemek.com','www.tgoyemek.com',
    'kuppo.net', 'www.kuppo.net'
  ];
  const currentDomain = window.location.hostname;
  return allowedDomains.some(domain => currentDomain === domain || currentDomain.endsWith('.' + domain));
}

// Script'leri sıralı bir şekilde enjekte etmek için asenkron bir fonksiyon.
async function injectAllScripts() {
  if (isAllowedDomain()) {
    injectStyles();
    
    const scriptsToInject = [
      'crypto-js.min.js',
      'generate-rsig.js',
      'src/core/endpoints.js',
      'src/core/helpers.js',
      'src/ui/styles.js',
      'src/ui/ui.js',
      'src/api/migros.js',
      'src/core/interceptor.js',
      'inject.js' // Bu script, diğerleri yüklendikten sonra çalışmalı.
    ];

    try {
      console.log('Script enjeksiyonu başlıyor...');
      for (const scriptFile of scriptsToInject) {
        await injectScript(scriptFile);
        console.log(`${scriptFile} başarıyla enjekte edildi.`);
      }
      console.log('Tüm scriptler başarıyla enjekte edildi.');
    } catch (error) {
      console.error('Script enjeksiyonu sırasında hata oluştu:', error);
    }
  }
}

// Script enjeksiyonunu başlat.
injectAllScripts();

// İnjected script ile background.js arasında mesaj taşıyıcı olarak çalış
window.addEventListener('message', function(event) {

  if (event.data && event.data.type === 'payment_success') {
    // Başarılı ödeme - sayfa yönlendirme
    setTimeout(() => {
      window.location.href = '/hesabim/siparislerim';
    }, 3000);
  } else if (event.data && event.data.type === 'payment_error') {
      // Başarısız ödeme - hata mesajı göster
      // veya iframe'i kapat, başka sayfa yönlendir vs.
  }

  // Web sayfasından gelen adres isteğini dinle (YENİ EKLENDİ)
  if (event.data && event.data.type === 'GET_SAVED_ADDRESSES_REQUEST_FROM_PAGE') {
    console.log('Content.js: Web sayfasından adres isteği alındı.');
    // Background.js'e adresleri sor
    if (chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: 'GET_ADDRESS_LIST_FROM_CONTENT' }, (response) => {
            if (chrome.runtime.lastError) {
                console.error('Content.js: Background.js\'den adres alınırken hata:', chrome.runtime.lastError.message);
                window.postMessage({ type: 'SAVED_ADDRESSES_RESPONSE_FROM_EXTENSION', payload: [], error: chrome.runtime.lastError.message }, '*');
                return;
            }
            console.log('Content.js: Background.js\'den adresler alındı:', response);
            // Gelen adresleri web sayfasına gönder
            window.postMessage({ type: 'SAVED_ADDRESSES_RESPONSE_FROM_EXTENSION', payload: response && response.success ? response.addresses : [], error: response && !response.success ? response.error : null }, '*');
        });
    } else {
         window.postMessage({ type: 'SAVED_ADDRESSES_RESPONSE_FROM_EXTENSION', payload: [], error: "chrome.runtime.sendMessage not available" }, '*');
    }
    return; // Mesaj işlendi, diğer if bloklarına girmesini engelle
  }

  // İnjected script'ten gelen proxy isteklerini kontrol et (MG, YS, TY için)
  if (event.data && event.data.source === 'MIGROS_KUPON_EXTENSION' && (event.data.action === 'proxyRequest' || event.data.action === 'ysProxyRequest' || event.data.action === 'mgProxyRequest' || event.data.action === 'tyProxyRequest')) {
    const { requestId, url, method, headers, body, action } = event.data;

    if (!url) {
      console.error(`Content: URL eksik! Eylem: ${action}, RequestID: ${requestId}`);
      return;
    }

    console.log(`Content: Proxy isteği (${action}) background.js'e iletiliyor. RequestID: ${requestId}`);
    console.log('Content: chrome.runtime.sendMessage mevcut mu?', !!chrome.runtime.sendMessage);

    chrome.runtime.sendMessage({
      action: action, // 'proxyRequest', 'ysProxyRequest', 'mgProxyRequest' veya 'tyProxyRequest'
      url: url,
      method: method,
      headers: headers,
      body: body
    }, (response) => {
      // Background.js'den gelen yanıtı inject.js'ye ilet
      if (chrome.runtime.lastError) {
        console.error(`Content: Mesaj gönderilirken hata oluştu (${action}).`, chrome.runtime.lastError.message);
        response = { success: false, error: chrome.runtime.lastError.message, headers: {} };
      }
      
      if (!response) {
        console.error(`Content: Background'den boş yanıt alındı! Eylem: ${action}, RequestID: ${requestId}`);
        response = { success: false, error: 'Background scriptinden yanıt alınamadı.', headers: {} };
      }

      console.log(`Content: Yanıt (${action}) alındı, inject.js'e iletiliyor. RequestID: ${requestId}`);
      
      window.postMessage({
        source: 'MIGROS_KUPON_EXTENSION_CONTENT',
        action: 'proxyResponse',
        requestId: requestId,
        response: response
      }, '*');
    });
  }


});

// Güncelleme Kontrolleri
async function checkForExtensionUpdates() {
  try {
    const response = await fetch('https://sunucu.kuppo.net/extension.php');
    const data = await response.json();
    
    if (data.status === 'success') {
      const manifest = chrome.runtime.getManifest();
      const currentVersion = manifest.version;
      
      if (currentVersion !== data.data.version) {
        return {
          needsUpdate: true,
          updateData: data.data
        };
      }
    }
    return { needsUpdate: false };
  } catch (error) {
    console.error('Güncelleme kontrolü başarısız:', error);
    return { needsUpdate: false };
  }
}

// Güncelleme popup'ını göster
function showUpdatePopupOverlay(updateData) {
  // Daha önce oluşturulmuş overlayı kontrol et
  if (document.getElementById('update-overlay')) {
    return;
  }

  const overlay = document.createElement('div');
  overlay.id = 'update-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8);
    z-index: 9999999;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: white;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  `;

  // Overlay içeriği
  overlay.innerHTML = `
    <div style="background: linear-gradient(145deg, #1a1a1a, #2a2a2a); border-radius: 24px; padding: 24px; max-width: 80%; width: 500px; text-align: center; box-shadow: 0 24px 48px rgba(0, 0, 0, 0.4); border: 1px solid rgba(255, 255, 255, 0.1);">
      <h2 style="margin-top: 0; color: #ffffff; font-size: 24px; font-weight: 600;">Yeni Güncelleme Mevcut</h2>
      <p style="color: #93c5fd; font-size: 18px; margin: 10px 0;">Versiyon: ${updateData.version}</p>
      <p style="color: #ffffff; font-size: 16px; margin: 16px 0;">${updateData.description}</p>
      <div style="display: flex; justify-content: center; gap: 12px; margin-top: 24px;">
        ${updateData.update_url ? `
          <a href="${updateData.update_url}" style="background-color: #3b82f6; color: white; padding: 12px 20px; border-radius: 12px; text-decoration: none; font-weight: 500; display: flex; align-items: center; gap: 8px; transition: all 0.2s ease;">
            <span style="font-size: 20px;">⟳</span>
            Güncelle
          </a>
        ` : ''}
        ${!updateData.is_mandatory ? `
          <button id="update-later-button" style="background-color: rgba(255, 255, 255, 0.1); color: white; padding: 12px 20px; border-radius: 12px; border: none; cursor: pointer; font-weight: 500; display: flex; align-items: center; gap: 8px; transition: all 0.2s ease;">
            <span style="font-size: 20px;">⏱</span>
            Sonra
          </button>
        ` : ''}
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  // "Sonra" butonunu dinle
  if (!updateData.is_mandatory) {
    const laterButton = overlay.querySelector('#update-later-button');
    laterButton.addEventListener('click', () => {
      overlay.remove();
      // Token işlemine devam et
      proceedWithTokenProcessing();
    });
  }
}

// Token işlemine devam et
function proceedWithTokenProcessing() {
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('token');
  
  if (token && token.length > 5) {
    // Token bilgisini background.js'ye gönder
    chrome.runtime.sendMessage({
      action: 'startExternalTokenProcess',
      token: token
    });
    
    // Overlay ekranını göster
    showTokenProcessingOverlay();
  }
}

// Belirli bir token geçtiğinde, işlem yapmak için background.js'ye bilgi gönder
async function checkForTokenInUrl() {
  const url = window.location.href;
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('token');
  
  // İzin verilen domainleri kontrol et
  const allowedDomains = ['kuppo.net', 'localhost'];
  const currentDomain = window.location.hostname;
  const isDomainAllowed = allowedDomains.some(domain => currentDomain.endsWith(domain));
  
  if (token && token.length > 5 && isDomainAllowed) {
    // Önce güncelleme kontrolü yap
    const updateCheck = await checkForExtensionUpdates();
    
    if (updateCheck.needsUpdate) {
      // Güncelleme gerekiyorsa popup göster
      showUpdatePopupOverlay(updateCheck.updateData);
      // Eğer güncelleme zorunlu değilse, laterButton'a tıklandığında proceedWithTokenProcessing çağrılacak
      // Zorunluysa, güncelleme yapılana kadar token işlemini başlatma
    } else {
      // Güncelleme gerekmiyorsa token işlemini başlat
      proceedWithTokenProcessing();
    }
  }
}

// Overlay HTML'ini oluştur
function showTokenProcessingOverlay() {
  // Daha önce oluşturulmuş overlayı kontrol et
  if (document.getElementById('token-processing-overlay')) {
    return;
  }

  const overlay = document.createElement('div');
  overlay.id = 'token-processing-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8);
    z-index: 9999999;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: white;
    font-family: Arial, sans-serif;
  `;

  // Overlay içeriği
  overlay.innerHTML = `
    <div style="background-color: #2c3e50; border-radius: 10px; padding: 20px; max-width: 80%; width: 500px; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.3);">
      <h2 style="margin-top: 0; color: #ecf0f1;">Token İşleniyor</h2>
      <div style="margin: 20px 0;">
        <div style="width: 50px; height: 50px; border: 5px solid #3498db; border-top-color: transparent; border-radius: 50%; margin: 0 auto; animation: spin 1s linear infinite;"></div>
      </div>
      <div id="log-container" style="max-height: 200px; overflow-y: auto; margin-bottom: 15px; text-align: left; background: rgba(0,0,0,0.2); padding: 10px; border-radius: 5px; font-family: monospace;">
        <p style="margin: 5px 0; color: #3498db;">İşlem başlatılıyor...</p>
      </div>
    </div>
    <style>
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    </style>
  `;

  document.body.appendChild(overlay);
}

// Not: updateLog ve closeOverlay mesajları artık yukarıdaki tek merkezi listener tarafından yönetiliyor.

// Overlay'de log mesajını güncelle
function updateLogInOverlay(message, type = 'info') {
  const logContainer = document.getElementById('log-container');
  if (!logContainer) return;

  const logEntry = document.createElement('p');
  logEntry.style.margin = '5px 0';
  
  // Mesaj tipine göre renk belirle
  switch(type) {
    case 'success':
      logEntry.style.color = '#2ecc71';
      break;
    case 'error':
      logEntry.style.color = '#e74c3c';
      break;
    case 'warning':
      logEntry.style.color = '#f39c12';
      break;
    default:
      logEntry.style.color = '#3498db'; // info
  }
  
  logEntry.textContent = message;
  logContainer.appendChild(logEntry);
  
  // Scroll'u en alta getir
  logContainer.scrollTop = logContainer.scrollHeight;
}

// Overlay'i kapat
function closeTokenProcessingOverlay() {
  const overlay = document.getElementById('token-processing-overlay');
  if (overlay) {
    // Kısa bir bekleme sonrası kaldır (görsel olarak daha güzel olması için)
    setTimeout(() => {
      overlay.style.opacity = '0';
      overlay.style.transition = 'opacity 0.5s ease';
      
      setTimeout(() => {
        overlay.remove();
      }, 500);
    }, 1000);
  }
}

// Migros giriş sayfası uyarı popup'ını göster
function showMigrosLoginWarning() {
  // Daha önce oluşturulmuş popup'ı kontrol et
  if (document.getElementById('migros-login-warning-overlay')) {
    return;
  }

  const overlay = document.createElement('div');
  overlay.id = 'migros-login-warning-overlay';
  
  // Popup stilleri
  const warningStyles = `
    #migros-login-warning-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(17, 17, 17, 0.95);
      backdrop-filter: blur(15px);
      -webkit-backdrop-filter: blur(15px);
      z-index: 2147483647;
      display: flex;
      justify-content: center;
      align-items: center;
      opacity: 0;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      pointer-events: all;
      padding: 16px;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      animation: fadeIn 0.5s ease forwards;
    }

    .migros-warning-container {
      background: linear-gradient(145deg, #dc2626, #b91c1c);
      border-radius: 24px;
      padding: 32px;
      width: 100%;
      max-width: 600px;
      box-shadow: 0 24px 48px rgba(220, 38, 38, 0.4);
      transform: translateY(20px) scale(0.98);
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      border: 2px solid rgba(255, 255, 255, 0.2);
      position: relative;
      overflow: hidden;
      margin: 0 auto;
      text-align: center;
      animation: slideUp 0.6s ease forwards;
    }

    .migros-warning-icon {
      width: 80px;
      height: 80px;
      background: rgba(255, 255, 255, 0.2);
      border-radius: 50%;
      margin: 0 auto 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 40px;
      animation: pulse 2s infinite;
    }

    .migros-warning-title {
      color: #ffffff;
      font-size: 28px;
      font-weight: 700;
      margin-bottom: 20px;
      letter-spacing: -0.5px;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    }

    .migros-warning-message {
      color: #fee2e2;
      font-size: 18px;
      line-height: 1.6;
      margin-bottom: 24px;
      font-weight: 500;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }

         .migros-warning-note {
       background: rgba(255, 255, 255, 0.1);
       border-radius: 16px;
       padding: 20px;
       margin-top: 20px;
       border: 1px solid rgba(255, 255, 255, 0.2);
       backdrop-filter: blur(4px);
       -webkit-backdrop-filter: blur(4px);
       display: flex;
       align-items: center;
       justify-content: center;
     }

    .migros-warning-note-text {
      color: #fecaca;
      font-size: 16px;
      font-weight: 600;
      margin: 0;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes slideUp {
      from {
        transform: translateY(40px) scale(0.95);
        opacity: 0;
      }
      to {
        transform: translateY(0) scale(1);
        opacity: 1;
      }
    }

    @keyframes pulse {
      0% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.7);
      }
      70% {
        transform: scale(1);
        box-shadow: 0 0 0 10px rgba(255, 255, 255, 0);
      }
      100% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(255, 255, 255, 0);
      }
    }

    /* Mobil uyumluluk */
    @media (max-width: 768px) {
      #migros-login-warning-overlay {
        padding: 12px;
      }

      .migros-warning-container {
        border-radius: 20px;
        padding: 24px;
        max-width: 95%;
      }

      .migros-warning-icon {
        width: 60px;
        height: 60px;
        font-size: 30px;
        margin-bottom: 20px;
      }

      .migros-warning-title {
        font-size: 22px;
        margin-bottom: 16px;
      }

      .migros-warning-message {
        font-size: 16px;
        margin-bottom: 20px;
      }

      .migros-warning-note {
        padding: 16px;
        margin-top: 16px;
      }

      .migros-warning-note-text {
        font-size: 14px;
      }
    }

    @media (max-width: 480px) {
      .migros-warning-container {
        padding: 20px;
      }

      .migros-warning-title {
        font-size: 20px;
      }

      .migros-warning-message {
        font-size: 15px;
      }

      .migros-warning-note-text {
        font-size: 13px;
      }
    }
  `;

  // Stilleri head'e ekle
  const style = document.createElement('style');
  style.textContent = warningStyles;
  document.head.appendChild(style);

  overlay.innerHTML = `
    <div class="migros-warning-container">
      <div class="migros-warning-icon">⚠️</div>
      <h2 class="migros-warning-title">ÖNEMLİ UYARI</h2>
      <p class="migros-warning-message">
        Kendi hesabınıza girmek istiyorsanız eklentinin yüklü olmadığı bir tarayıcıdan giriniz veya gizli sekmeden eklenti aktif değilken giriniz, eklentinin yüklü olduğu tarayıcıdan girerseniz hesabınız kapanabilir.
      </p>
      <div class="migros-warning-note">
        <p class="migros-warning-note-text">
          Bu uyarı güvenliğiniz için gösterilmektedir
        </p>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
}

// Migros giriş sayfasını kontrol et
function checkMigrosLoginPage() {
  const currentUrl = window.location.href;
  const currentDomain = window.location.hostname;
  
  // Migros domaininde ve giriş sayfasında mıyız kontrol et
  if ((currentDomain === 'www.migros.com.tr' || currentDomain === 'migros.com.tr') && 
      currentUrl.includes('/giris')) {
    showMigrosLoginWarning();
  }
}

// Migros URL yönlendirme kontrolü
async function checkMigrosUrlRedirect() {
  const currentUrl = window.location.href;
  const currentDomain = window.location.hostname;
  
  // Sadece Migros domaininde çalış
  if (currentDomain !== 'www.migros.com.tr' && currentDomain !== 'migros.com.tr') {
    return;
  }
  
  // Storage'dan servis tipini al
  chrome.storage.local.get('mgServiceType', function(data) {
    const mgServiceType = data.mgServiceType;
    
    // Eğer servis tipi yoksa kontrol yapma
    if (!mgServiceType) {
      return;
    }
    
    // Mevcut path'i al
    const currentPath = window.location.pathname;
    
    console.log('MG URL Kontrolü - Servis:', mgServiceType, 'Path:', currentPath);
    
    // Kullanıcı hangi serviste?
    const isInHemen = currentPath.startsWith('/hemen');
    const isInYemek = currentPath.startsWith('/yemek');
    const isInSanalmarket = !isInHemen && !isInYemek;
    
    // Doğru serviste mi kontrol et
    let isInCorrectService = false;
    if (mgServiceType === 'hemen' && isInHemen) {
      isInCorrectService = true;
    } else if (mgServiceType === 'yemek' && isInYemek) {
      isInCorrectService = true;
    } else if (mgServiceType === 'sanalmarket' && isInSanalmarket) {
      isInCorrectService = true;
    }
    
    // Doğru servisteyse hiçbir şey yapma
    if (isInCorrectService) {
      console.log('Doğru serviste, yönlendirme yapılmıyor');
      return;
    }
    
    // Sanalmarket kullanıcısı yemek veya hemen'e girmeye çalışıyorsa hemen engelle
    if (mgServiceType === 'sanalmarket' && (isInYemek || isInHemen)) {
      console.log('Sanalmarket kullanıcısı yemek/hemen kısımlarına erişmeye çalışıyor, engelleniyor...');
      // Sayfayı hemen gizle ki içerik görünmesin
      document.documentElement.style.display = 'none';
    }
    
    // Yanlış serviste, doğru servise yönlendir
    let correctUrl = 'https://www.migros.com.tr/';
    if (mgServiceType === 'hemen') {
      correctUrl = 'https://www.migros.com.tr/hemen';
    } else if (mgServiceType === 'yemek') {
      correctUrl = 'https://www.migros.com.tr/yemek';
    }
    
    console.log('Yanlış serviste, yönlendiriliyor:', correctUrl);
    window.location.href = correctUrl;
  });
}

// Sayfa durumu değişikliklerini yönetmek için merkezi ve optimize edilmiş bir yapı
(function setupStateChangeMonitoring() {
  let debounceTimer;
  let lastUrl = window.location.href;

  // Kontrol fonksiyonlarını çağıran merkezi fonksiyon
  function performChecks() {
    checkForTokenInUrl();
    checkMigrosLoginPage();
    checkMigrosUrlRedirect();
    checkUberUpdateNamePage();
  }

  // Uber isim güncelleme sayfasını kontrol et ve işlemi başlat
  async function checkUberUpdateNamePage() {
    const currentUrl = window.location.href;
    if (currentUrl.includes('account.uber.com/update-display-name')) {
      console.log('Uber isim güncelleme sayfası algılandı.');
      
      // Background'dan kayıtlı adresi (ve dolayısıyla ismi) iste
      chrome.runtime.sendMessage({ action: 'GET_ADDRESS_LIST_FROM_CONTENT' }, async (response) => {
        if (chrome.runtime.lastError || !response || !response.success || !response.addresses || response.addresses.length === 0) {
          console.error('İsim bilgisi için kayıtlı adres alınamadı.');
          return;
        }

        const address = response.addresses.find(addr => addr.autoAddAddress === true) || response.addresses[0];
        if (!address || !address.fullname) {
          console.error('Adres listesinde isim bilgisi bulunamadı.');
          return;
        }

        const fullName = address.fullname.trim();
        const parts = fullName.split(' ');
        const firstName = parts[0];
        const lastName = parts.length > 1 ? parts.slice(1).join(' ') : '-';

        // Elementlerin yüklenmesini bekle
        const waitForElement = (selector, timeout = 10000) => {
          return new Promise((resolve, reject) => {
            const startTime = Date.now();
            const check = () => {
              const el = document.querySelector(selector);
              if (el) resolve(el);
              else if (Date.now() - startTime > timeout) reject(new Error('Timeout waiting for ' + selector));
              else setTimeout(check, 500);
            };
            check();
          });
        };

        try {
          const firstNameInput = await waitForElement('#update\\.display\\.name\\.firstname');
          const lastNameInput = await waitForElement('#update\\.display\\.name\\.lastname');
          const updateButton = await waitForElement('button._css-hQYYZS');

          // Değerleri setle
          firstNameInput.value = firstName;
          firstNameInput.dispatchEvent(new Event('input', { bubbles: true }));
          
          lastNameInput.value = lastName;
          lastNameInput.dispatchEvent(new Event('input', { bubbles: true }));

          console.log('Uber isimleri dolduruldu, güncelleniyor...');
          
          // Kısa bir bekleme ve tıkla
          setTimeout(() => {
            updateButton.click();
            setTimeout(() => {
                window.location.href = "https://www.uber.com/tr/tr/start-riding/";
            }, 2000);
          }, 1000);

        } catch (err) {
          console.error('Uber form elemanları bulunamadı:', err);
        }
      });
    }
  }

  // Değişiklikleri algılayan ve debounce ile kontrolü tetikleyen fonksiyon
  function handleStateChange() {
    // URL değiştiyse hemen kontrol et
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(performChecks, 100); // SPA geçişleri için kısa bir gecikme
    } else {
      // Sadece DOM değişikliği varsa daha uzun bir gecikme kullan
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(performChecks, 300);
    }
  }

  // Sayfa ilk yüklendiğinde kontrolleri yap
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', performChecks);
  } else {
    performChecks();
  }

  // Gerekli olay dinleyicilerini ayarla
  // Tarayıcı geçmişi (geri/ileri tuşları)
  window.addEventListener('popstate', handleStateChange);

  // History API'nin üzerine yazarak SPA geçişlerini yakala
  const originalPushState = history.pushState;
  history.pushState = function() {
    originalPushState.apply(history, arguments);
    handleStateChange();
  };

  const originalReplaceState = history.replaceState;
  history.replaceState = function() {
    originalReplaceState.apply(history, arguments);
    handleStateChange();
  };

  // DOM değişikliklerini izle
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver((mutations) => {
      // Sadece anlamlı DOM değişikliklerinde tetikle
      const hasMeaningfulChanges = mutations.some(m => m.type === 'childList' && m.addedNodes.length > 0);
      if (hasMeaningfulChanges) {
        handleStateChange();
      }
    });

    // Body'yi izle (sayfa yüklendikten sonra)
    const startObserving = () => {
      if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
      } else {
        // Body henüz yoksa, DOMContentLoaded'ı bekle
        document.addEventListener('DOMContentLoaded', () => {
           observer.observe(document.body, { childList: true, subtree: true });
        }, { once: true });
      }
    };
    startObserving();
  }

  console.log('Optimize edilmiş sayfa durumu izleyicisi başlatıldı.');
})();
