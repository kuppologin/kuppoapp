(function() {
  'use strict';

  // Script çalışmaya başladığında konsola bilgi verir
  console.log('Migros Kupon Uygulayıcı başlatıldı');

  // Global değişken olarak window nesnesine ekle
  window.migrosKupon = {
      appliedCouponData: null,
      currentService: null,
      validDiscountId: null,
      originalCouponId: null,
      couponUIContainer: null, // Referans için UI container
      originalPrice: null // Kupon uygulanmadan önceki fiyat
  };

  try {
    GM_addStyle(couponUIStyles);
  } catch (error) {
    console.error('CSS ekleme hatası:', error);
  }

  // Sayfa değişikliklerini izleyen fonksiyon
  function monitorPageChanges() {
      let lastUrl = location.href;
      let uiAddAttempted = false; // Tekrarlı eklemeyi önlemek için

      const observer = new MutationObserver((mutations) => {
          let paymentSummaryAppeared = false;
          // DOM değişikliklerini kontrol et
          for (const mutation of mutations) {
              if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                  for (const node of mutation.addedNodes) {
                      // Node'un kendisi veya alt elementleri hedef seçiciyi içeriyor mu?
                      if (node.nodeType === Node.ELEMENT_NODE) {
                           if (node.matches && (node.matches('fe-line-checkout-price-summary') || node.querySelector('fe-line-checkout-price-summary'))) {
                               paymentSummaryAppeared = true;
                               break; // Hedef bulundu
                           }
                           if (node.matches && (node.matches('fe-line-checkout-summary-desktop') || node.querySelector('fe-line-checkout-summary-desktop'))) {
                               paymentSummaryAppeared = true;
                               break; // Hedef bulundu
                           }
                      }
                  }
              }
              if (paymentSummaryAppeared) break;
          }


          // URL değişti mi veya ödeme özeti göründü mü kontrol et
          if (lastUrl !== location.href || paymentSummaryAppeared) {
              lastUrl = location.href;
              uiAddAttempted = false; // Yeni URL veya içerik için deneme hakkı ver
              console.log('URL değişti veya ödeme özeti göründü, UI kontrol ediliyor:', lastUrl);

              // Eğer yeni URL ödeme sayfası değilse, tüm kupon durumunu sıfırla.
              if (!location.href.includes('/odeme/')) {
                  console.log("Ödeme sayfasında değiliz, kupon bilgileri sıfırlanıyor.");
                  clearAppliedCouponUI(true); // `resetGlobals = true` ile tüm veriyi sıfırla
                  if (window.migrosKupon.couponUIContainer) {
                      window.migrosKupon.couponUIContainer.remove();
                      window.migrosKupon.couponUIContainer = null;
                  }
              }
          }

          // Ödeme sayfasında mıyız ve UI henüz eklenmedi mi?
          if (!uiAddAttempted && location.href.includes('/odeme/')) {
               const paymentSummaryAvailable = document.querySelector('fe-line-checkout-price-summary, fe-line-checkout-summary-desktop');
               if (paymentSummaryAvailable && !document.getElementById('migros-coupon-container')) {
                  console.log('Ödeme sayfası ve özet bulundu, UI ekleniyor...');
                  addCouponUI();
                  uiAddAttempted = true; // Bu yükleme için UI eklendi/denendi
              } else if (!paymentSummaryAvailable) {
                  //console.log('Ödeme sayfasındayız ama özet henüz yok, bekleniyor...');
               }
          }
      });

      observer.observe(document.body, { childList: true, subtree: true });

      // Sayfa ilk yüklendiğinde de kontrol et (timeout ile biraz gecikme ver)
      if (location.href.includes('/odeme/')) {
          console.log('İlk yükleme, ödeme sayfası, UI eklenmesi için bekleniyor...');
          setTimeout(() => {
               if (!document.getElementById('migros-coupon-container')) {
                    addCouponUI();
                    uiAddAttempted = true;
               }
          }, 2000); // Sayfanın tam yüklenmesi için 2 saniye bekle
      }
  }

  // Genel network request monitor - tüm request'leri logla
  function monitorAllRequests() {
      // Performance Observer ile tüm network isteklerini izle
      if (window.PerformanceObserver && window.PerformanceResourceTiming) {
          try {
              const observer = new PerformanceObserver((list) => {
                  for (const entry of list.getEntries()) {
                      if (entry.entryType === 'resource' && (entry.initiatorType === 'xmlhttprequest' || entry.initiatorType === 'fetch' || entry.initiatorType === 'script')) {
                          // Service Worker dosyasını kontrol et
                          if (isServiceWorkerFile(entry.name)) {
                              console.warn('⚠️ Service Worker dosyası tespit edildi (Performance Observer):', entry.name);
                              console.warn('Bu dosya engellenemedi - muhtemelen farklı bir yöntemle yükleniyor');
                          }
                          
                          // PWA manifest dosyalarını kontrol et
                          if (isPWAManifestFile(entry.name)) {
                              console.warn('⚠️ PWA manifest dosyası tespit edildi (Performance Observer):', entry.name);
                              console.warn('Bu dosya engellenemedi - muhtemelen farklı bir yöntemle yükleniyor');
                          }
                          
                          // Profil ikonu dosyasını kontrol et
                          if (isProfileIconFile(entry.name)) {
                              console.warn('⚠️ Profil ikonu dosyası tespit edildi (Performance Observer):', entry.name);
                              console.warn('Bu dosya engellenemedi - muhtemelen farklı bir yöntemle yükleniyor');
                          }
                          
                          // Custom texts endpoint'ini kontrol et
                          if (isCustomTextsEndpoint(entry.name)) {
                              console.warn('⚠️ Custom-texts isteği tespit edildi (Performance Observer):', entry.name);
                              console.warn('Bu istek engellenemedi - muhtemelen farklı bir API kullanılıyor');
                          }
                          
                          // Perseus Analytics endpoint'ini kontrol et
                          if (isPerseusAnalyticsEndpoint(entry.name)) {
                              console.warn('⚠️ Perseus Analytics isteği tespit edildi (Performance Observer):', entry.name);
                              console.warn('Bu istek engellenemedi - muhtemelen farklı bir yöntemle gönderiliyor');
                          }
                      }
                  }
              });
              
              observer.observe({ entryTypes: ['resource'] });
              console.log('Network request monitor başlatıldı');
          } catch (e) {
              console.warn('Performance Observer başlatılamadı:', e);
          }
      }
  }

  // Monitor'u başlat
  monitorAllRequests();

  // PWA manifest link tag'lerini kaldır
  function removePWAManifestLinks() {
      // Mevcut manifest link'lerini bul ve kaldır
      const manifestLinks = document.querySelectorAll('link[rel="manifest"], link[href*="manifest.json"], link[href*="ngsw.json"]');
      manifestLinks.forEach(link => {
          console.log('PWA manifest link kaldırılıyor:', link.href);
          link.remove();
      });
      
      // MutationObserver ile yeni eklenen manifest link'lerini izle
      const observer = new MutationObserver((mutations) => {
          mutations.forEach((mutation) => {
              mutation.addedNodes.forEach((node) => {
                  if (node.nodeType === Node.ELEMENT_NODE) {
                      // Doğrudan manifest link mi?
                      if (node.tagName === 'LINK' && 
                          (node.rel === 'manifest' || 
                           node.href.includes('manifest.json') || 
                           node.href.includes('ngsw.json'))) {
                          console.log('Yeni PWA manifest link engellendi:', node.href);
                          node.remove();
                      }
                      
                      // Alt elementlerde manifest link var mı?
                      const manifestLinks = node.querySelectorAll && node.querySelectorAll('link[rel="manifest"], link[href*="manifest.json"], link[href*="ngsw.json"]');
                      if (manifestLinks) {
                          manifestLinks.forEach(link => {
                              console.log('Alt element PWA manifest link engellendi:', link.href);
                              link.remove();
                          });
                      }
                  }
              });
          });
      });
      
      // Head ve body'yi izle
      if (document.head) {
          observer.observe(document.head, { childList: true, subtree: true });
      }
      if (document.body) {
          observer.observe(document.body, { childList: true, subtree: true });
      }
      
      console.log('PWA manifest link observer başlatıldı');
  }

  // PWA manifest link'lerini hemen kaldır ve izlemeyi başlat
  if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', removePWAManifestLinks);
  } else {
      removePWAManifestLinks();
  }

  // Sayfanın tamamen yüklenmesini bekle
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
      console.log('Document already loaded, starting monitoring.');
      monitorPageChanges();
  } else {
      window.addEventListener('load', function() {
          console.log('Window loaded, starting monitoring.');
          monitorPageChanges();
      });
  }

  // Content script'ten gelen mesajları dinle
  window.addEventListener('message', function(event) {
    // Kendi mesajlarımızı ve başka kaynakları filtrele
    if (event.source !== window || !event.data || event.data.source !== 'MIGROS_KUPON_EXTENSION_CONTENT') {
      return;
    }
    
    // Mesaj tipine göre işlem yap
    if (event.data.action === 'proxyResponse') {
      const { requestId, response } = event.data;
      
      // Yanıtı hata ayıklama için daha ayrıntılı logla
      if (response && response.success) {
          console.log(`Proxy yanıtı alındı: ${response.status}`, {
              status: response.status,
              headersCount: response.headers ? Object.keys(response.headers).length : 0,
              dataSize: response.data ? response.data.length : 0
          });
      } else {
          console.warn('Başarısız proxy yanıtı alındı:', response ? response.error : 'Yanıt yok');
      }
      
      // Boş headers'ı düzelt
      if (response && !response.headers) {
          response.headers = {};
      }
      
      // XHR callbacks için kontrol et
      if (window.migrosKupon.xhrCallbacks && window.migrosKupon.xhrCallbacks[requestId]) {
        window.migrosKupon.xhrCallbacks[requestId](response);
      }
      
      // Fetch callbacks için kontrol et
      if (window.migrosKupon.fetchCallbacks && window.migrosKupon.fetchCallbacks[requestId]) {
        window.migrosKupon.fetchCallbacks[requestId](response);
      }
    }
  });

  // Initialize Yemeksepeti scripts
  initYsProductLister();
  initYsCardCleaner();

})();
